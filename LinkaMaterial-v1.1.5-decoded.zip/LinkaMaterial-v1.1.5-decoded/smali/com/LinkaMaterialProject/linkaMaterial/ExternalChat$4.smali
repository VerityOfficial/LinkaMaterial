.class Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$4;
.super Ljava/lang/Object;
.source "ExternalChat.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;

    .line 93
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$4;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 96
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$4;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;

    const-class v2, Lcom/LinkaMaterialProject/linkaMaterial/profile;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 97
    .local v0, "intent":Landroid/content/Intent;
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$4;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->startActivity(Landroid/content/Intent;)V

    .line 98
    return-void
.end method
