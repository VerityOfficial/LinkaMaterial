.class Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$ViewHolder;
.super Ljava/lang/Object;
.source "FederationsAdapter.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "ViewHolder"
.end annotation


# instance fields
.field btnFederation:Landroid/widget/Button;

.field coverFederation:Landroid/widget/ImageView;


# direct methods
.method constructor <init>()V
    .locals 0

    .line 46
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
