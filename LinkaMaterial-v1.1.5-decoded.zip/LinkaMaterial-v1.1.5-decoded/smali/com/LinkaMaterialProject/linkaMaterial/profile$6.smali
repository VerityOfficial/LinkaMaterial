.class Lcom/LinkaMaterialProject/linkaMaterial/profile$6;
.super Ljava/lang/Object;
.source "profile.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/profile;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/profile;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/profile;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/profile;

    .line 115
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/profile;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 118
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/profile;

    const-class v2, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 119
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "type"

    const-string v2, "profile picture"

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 120
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/profile;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/profile;->-$$Nest$fgetusernameProfile(Lcom/LinkaMaterialProject/linkaMaterial/profile;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "username"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 121
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/profile;

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/profile;->startActivity(Landroid/content/Intent;)V

    .line 122
    return-void
.end method
