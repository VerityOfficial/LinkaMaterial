.class Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5$1;
.super Ljava/lang/Object;
.source "BanUserGroup.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;

.field final synthetic val$response:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$1"    # Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 134
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5$1;->val$response:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    .line 137
    const-string v0, "members"

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5$1;->val$response:Ljava/lang/String;

    const-string v2, "BanUserGroup"

    if-eqz v1, :cond_6

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5$1;->val$response:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    goto/16 :goto_6

    .line 143
    :cond_0
    const/4 v1, 0x0

    .line 146
    .local v1, "membersArray":Lorg/json/JSONArray;
    :try_start_0
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5$1;->val$response:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    const-string v4, "{"

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_1

    .line 147
    new-instance v3, Lorg/json/JSONObject;

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5$1;->val$response:Ljava/lang/String;

    invoke-direct {v3, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 148
    .local v3, "jsonObj":Lorg/json/JSONObject;
    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_2

    .line 149
    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    move-object v1, v0

    .end local v1    # "membersArray":Lorg/json/JSONArray;
    .local v0, "membersArray":Lorg/json/JSONArray;
    goto :goto_0

    .line 151
    .end local v0    # "membersArray":Lorg/json/JSONArray;
    .end local v3    # "jsonObj":Lorg/json/JSONObject;
    .restart local v1    # "membersArray":Lorg/json/JSONArray;
    :cond_1
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5$1;->val$response:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const-string v3, "["

    invoke-virtual {v0, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 152
    new-instance v0, Lorg/json/JSONArray;

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5$1;->val$response:Ljava/lang/String;

    invoke-direct {v0, v3}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v1, v0

    goto :goto_1

    .line 151
    :cond_2
    :goto_0
    nop

    .line 155
    :goto_1
    if-eqz v1, :cond_5

    .line 156
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;

    iget-object v0, v0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->-$$Nest$fgetfriendsList(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 157
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_2
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v3

    if-ge v0, v3, :cond_4

    .line 160
    invoke-virtual {v1, v0}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    if-eqz v3, :cond_3

    .line 161
    invoke-virtual {v1, v0}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    const-string v4, "username"

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .local v3, "memberName":Ljava/lang/String;
    goto :goto_3

    .line 163
    .end local v3    # "memberName":Ljava/lang/String;
    :cond_3
    invoke-virtual {v1, v0}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v3

    .line 165
    .restart local v3    # "memberName":Ljava/lang/String;
    :goto_3
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;

    iget-object v4, v4, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->-$$Nest$fgetfriendsList(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)Ljava/util/List;

    move-result-object v4

    new-instance v5, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;

    invoke-direct {v5, v3}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;-><init>(Ljava/lang/String;)V

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 157
    nop

    .end local v3    # "memberName":Ljava/lang/String;
    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    .line 167
    .end local v0    # "i":I
    :cond_4
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;

    iget-object v0, v0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->-$$Nest$fgetadapter(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;

    move-result-object v0

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;->notifyDataSetChanged()V

    .line 168
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Membros carregados com sucesso: "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;

    iget-object v3, v3, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->-$$Nest$fgetfriendsList(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_4

    .line 170
    :cond_5
    const-string v0, "Chave \'members\' nao encontrada na resposta."

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 176
    .end local v1    # "membersArray":Lorg/json/JSONArray;
    :goto_4
    goto :goto_5

    .line 173
    :catch_0
    move-exception v0

    .line 174
    .local v0, "e":Lorg/json/JSONException;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Erro ao fazer parse do JSON: "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v0}, Lorg/json/JSONException;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 175
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 177
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_5
    return-void

    .line 138
    :cond_6
    :goto_6
    const-string v0, "Resposta do servidor veio nula ou vazia"

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 139
    return-void
.end method
