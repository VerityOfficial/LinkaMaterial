.class public Lcom/LinkaMaterialProject/linkaMaterial/Message;
.super Ljava/lang/Object;
.source "Message.java"


# instance fields
.field private id:I

.field private message:Ljava/lang/String;

.field private sender:Ljava/lang/String;


# direct methods
.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "id"    # I
    .param p2, "message"    # Ljava/lang/String;
    .param p3, "sender"    # Ljava/lang/String;

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    iput p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/Message;->id:I

    .line 8
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/Message;->message:Ljava/lang/String;

    .line 9
    iput-object p3, p0, Lcom/LinkaMaterialProject/linkaMaterial/Message;->sender:Ljava/lang/String;

    .line 10
    return-void
.end method


# virtual methods
.method public getId()I
    .locals 1

    .line 11
    iget v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/Message;->id:I

    return v0
.end method

.method public getMessage()Ljava/lang/String;
    .locals 1

    .line 12
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/Message;->message:Ljava/lang/String;

    return-object v0
.end method

.method public getSender()Ljava/lang/String;
    .locals 1

    .line 13
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/Message;->sender:Ljava/lang/String;

    return-object v0
.end method
