.class public final Lcom/LinkaMaterialProject/linkaMaterial/R$color;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static app_background:I = 0x7f010000

.field public static app_divider:I = 0x7f010001

.field public static app_icon_tint:I = 0x7f010002

.field public static app_surface:I = 0x7f010003

.field public static app_surface_elevated:I = 0x7f010004

.field public static app_text_primary:I = 0x7f010005

.field public static app_text_secondary:I = 0x7f010006

.field public static black:I = 0x7f010007

.field public static chat_bubble_mine:I = 0x7f010008

.field public static chat_bubble_other:I = 0x7f010009

.field public static material_accent:I = 0x7f01000a

.field public static material_bg:I = 0x7f01000b

.field public static material_blue:I = 0x7f01000c

.field public static material_blue_pressed:I = 0x7f01000d

.field public static material_card:I = 0x7f01000e

.field public static material_primary:I = 0x7f01000f

.field public static material_primary_dark:I = 0x7f010010

.field public static purple_200:I = 0x7f010011

.field public static purple_500:I = 0x7f010012

.field public static purple_700:I = 0x7f010013

.field public static teal_200:I = 0x7f010014

.field public static teal_700:I = 0x7f010015

.field public static white:I = 0x7f010016


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
