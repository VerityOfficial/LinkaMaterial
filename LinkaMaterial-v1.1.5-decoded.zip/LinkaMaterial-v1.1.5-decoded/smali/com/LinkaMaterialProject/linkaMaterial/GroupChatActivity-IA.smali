.class public final synthetic Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
