.class Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName$1;
.super Ljava/lang/Object;
.source "ChangeGroupName.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;

    .line 41
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 45
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 46
    .local v0, "jsonRequest":Lorg/json/JSONObject;
    const-string v1, "username"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 47
    const-string v1, "group_id"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->-$$Nest$fgetgroupId(Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;)I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 48
    const-string v1, "new_name"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->-$$Nest$fgetedtName(Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;)Landroid/widget/EditText;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 50
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/rename-group"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "post"

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;

    invoke-static {v1, v2, v0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    .line 52
    new-instance v1, Landroid/content/Intent;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;

    const-class v3, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 53
    .local v1, "intentGroup":Landroid/content/Intent;
    const-string v2, "groupId"

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->-$$Nest$fgetgroupId(Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;)I

    move-result v3

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 54
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;

    invoke-virtual {v2, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->startActivity(Landroid/content/Intent;)V

    .line 55
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;

    invoke-virtual {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->finish()V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 58
    .end local v0    # "jsonRequest":Lorg/json/JSONObject;
    .end local v1    # "intentGroup":Landroid/content/Intent;
    goto :goto_0

    .line 56
    :catch_0
    move-exception v0

    .line 57
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 59
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    return-void
.end method
