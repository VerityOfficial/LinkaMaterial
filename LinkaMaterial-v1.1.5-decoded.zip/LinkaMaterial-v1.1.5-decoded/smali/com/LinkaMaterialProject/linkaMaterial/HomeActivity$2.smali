.class Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$2;
.super Ljava/lang/Object;
.source "HomeActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    .line 60
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    .line 64
    :try_start_0
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v0}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 65
    .local v0, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v1, Lorg/json/JSONObject;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    const-string v3, "config.cfg"

    invoke-virtual {v0, v2, v3}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 66
    .local v1, "jsonCfg":Lorg/json/JSONObject;
    const-string v2, "FAST_LOGIN"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    .line 67
    .local v2, "fastLogin":Lorg/json/JSONObject;
    const-string v3, "SERVER"

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    .line 68
    .local v3, "server":Lorg/json/JSONObject;
    const-string v4, "token_session"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 69
    .local v4, "token":Ljava/lang/String;
    const-string v5, "url"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 70
    .local v5, "url":Ljava/lang/String;
    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    invoke-static {v4, v5, v6}, Lcom/LinkaMaterialProject/linkaMaterial/tokenManager;->valideToken(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 73
    nop

    .end local v0    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v1    # "jsonCfg":Lorg/json/JSONObject;
    .end local v2    # "fastLogin":Lorg/json/JSONObject;
    .end local v3    # "server":Lorg/json/JSONObject;
    .end local v4    # "token":Ljava/lang/String;
    .end local v5    # "url":Ljava/lang/String;
    goto :goto_0

    .line 71
    :catch_0
    move-exception v0

    .line 72
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 74
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    return-void
.end method
