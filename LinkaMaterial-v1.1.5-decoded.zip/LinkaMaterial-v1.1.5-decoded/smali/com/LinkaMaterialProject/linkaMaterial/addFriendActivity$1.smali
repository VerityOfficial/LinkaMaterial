.class Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$1;
.super Ljava/lang/Object;
.source "addFriendActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;

    .line 57
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 6
    .param p1, "v"    # Landroid/view/View;

    .line 60
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->-$$Nest$fgetedtUsername(Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 61
    .local v0, "receiver":Ljava/lang/String;
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->-$$Nest$fgetedtMessage(Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;)Landroid/widget/EditText;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    .line 63
    .local v1, "message":Ljava/lang/String;
    :try_start_0
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 64
    .local v2, "jsonAdd":Lorg/json/JSONObject;
    const-string v3, "receiver"

    invoke-virtual {v2, v3, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 65
    const-string v3, "remittee"

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 66
    const-string v3, "message"

    invoke-virtual {v2, v3, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 67
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "/send-friend"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "post"

    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;

    invoke-static {v3, v4, v2, v5}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    .line 68
    new-instance v3, Landroid/content/Intent;

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;

    const-class v5, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;

    invoke-direct {v3, v4, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 69
    .local v3, "intent":Landroid/content/Intent;
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;

    invoke-virtual {v4, v3}, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 72
    .end local v2    # "jsonAdd":Lorg/json/JSONObject;
    .end local v3    # "intent":Landroid/content/Intent;
    goto :goto_0

    .line 70
    :catch_0
    move-exception v2

    .line 71
    .local v2, "e":Ljava/lang/Exception;
    invoke-virtual {v2}, Ljava/lang/Exception;->printStackTrace()V

    .line 73
    .end local v2    # "e":Ljava/lang/Exception;
    :goto_0
    return-void
.end method
