.class public Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;
.super Landroid/app/Activity;
.source "HomeActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;,
        Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$FetchFeedTask;
    }
.end annotation


# instance fields
.field private btnChat:Landroid/widget/ImageButton;

.field private btnFooterFederations:Landroid/widget/Button;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;

.field private federationButton:Landroid/widget/Button;

.field private footerContainer:Landroid/view/View;

.field private listViewPosts:Landroid/widget/ListView;

.field private newPost:Landroid/widget/Button;

.field private postAdapter:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;

.field private postsList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lorg/json/JSONObject;",
            ">;"
        }
    .end annotation
.end field

.field private scheduler:Ljava/util/concurrent/ScheduledExecutorService;

.field private schedulerNotifications:Ljava/util/concurrent/ScheduledExecutorService;


# direct methods
.method static bridge synthetic -$$Nest$fgetpostAdapter(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;)Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->postAdapter:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetpostsList(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;)Ljava/util/ArrayList;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->postsList:Ljava/util/ArrayList;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 0

    .line 28
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 10
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 47
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 48
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->activity_home:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->setContentView(I)V

    .line 50
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->schedulerNotifications:Ljava/util/concurrent/ScheduledExecutorService;

    .line 51
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->scheduler:Ljava/util/concurrent/ScheduledExecutorService;

    .line 53
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$1;

    invoke-direct {v0, p0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;)V

    move-object v2, v0

    .line 60
    .local v2, "notificationsTask":Ljava/lang/Runnable;
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$2;

    invoke-direct {v0, p0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;)V

    move-object v8, v0

    .line 77
    .local v8, "tokenTask":Ljava/lang/Runnable;
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->schedulerNotifications:Ljava/util/concurrent/ScheduledExecutorService;

    const-wide/16 v5, 0xf

    sget-object v7, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v3, 0x0

    invoke-interface/range {v1 .. v7}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleAtFixedRate(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    .line 78
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->scheduler:Ljava/util/concurrent/ScheduledExecutorService;

    move-object v4, v8

    .end local v8    # "tokenTask":Ljava/lang/Runnable;
    .local v4, "tokenTask":Ljava/lang/Runnable;
    const-wide/16 v7, 0x2

    sget-object v9, Ljava/util/concurrent/TimeUnit;->MINUTES:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v5, 0x0

    invoke-interface/range {v3 .. v9}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleAtFixedRate(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    .line 80
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v0}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    move-object v1, v0

    .line 82
    .local v1, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    :try_start_0
    const-string v0, "config.cfg"

    invoke-virtual {v1, p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 83
    .local v0, "rawJson":Ljava/lang/String;
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 84
    .local v3, "jsonCfg":Lorg/json/JSONObject;
    const-string v5, "FAST_LOGIN"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    .line 85
    .local v5, "fastLogin":Lorg/json/JSONObject;
    const-string v6, "SERVER"

    invoke-virtual {v3, v6}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v6

    .line 86
    .local v6, "server":Lorg/json/JSONObject;
    const-string v7, "url"

    const-string v8, "http://linkaProject.pythonanywhere.com"

    invoke-virtual {v6, v7, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 87
    .local v7, "url":Ljava/lang/String;
    const-string v8, "token_session"

    const-string v9, ""

    invoke-virtual {v5, v8, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 88
    .local v8, "token":Ljava/lang/String;
    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_0

    .line 89
    invoke-static {v8, v7, p0}, Lcom/LinkaMaterialProject/linkaMaterial/tokenManager;->valideToken(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 93
    .end local v0    # "rawJson":Ljava/lang/String;
    .end local v3    # "jsonCfg":Lorg/json/JSONObject;
    .end local v5    # "fastLogin":Lorg/json/JSONObject;
    .end local v6    # "server":Lorg/json/JSONObject;
    .end local v7    # "url":Ljava/lang/String;
    .end local v8    # "token":Ljava/lang/String;
    :cond_0
    goto :goto_0

    .line 91
    :catch_0
    move-exception v0

    .line 92
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 95
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->federationsButton:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->federationButton:Landroid/widget/Button;

    .line 96
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->newPost:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->newPost:Landroid/widget/Button;

    .line 97
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->btnHome:Landroid/widget/ImageButton;

    .line 98
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->btnChat:Landroid/widget/ImageButton;

    .line 99
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->btnProfile:Landroid/widget/ImageButton;

    .line 100
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->btnOptions:Landroid/widget/ImageButton;

    .line 102
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$3;

    invoke-direct {v0, p0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;)V

    .line 110
    .local v0, "goFederationsListener":Landroid/view/View$OnClickListener;
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->federationButton:Landroid/widget/Button;

    invoke-virtual {v3, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 112
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->btnChat:Landroid/widget/ImageButton;

    new-instance v5, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$4;

    invoke-direct {v5, p0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;)V

    invoke-virtual {v3, v5}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 120
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->btnOptions:Landroid/widget/ImageButton;

    new-instance v5, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$5;

    invoke-direct {v5, p0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$5;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;)V

    invoke-virtual {v3, v5}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 128
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->btnProfile:Landroid/widget/ImageButton;

    new-instance v5, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$6;

    invoke-direct {v5, p0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$6;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;)V

    invoke-virtual {v3, v5}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 136
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->newPost:Landroid/widget/Button;

    new-instance v5, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$7;

    invoke-direct {v5, p0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$7;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;)V

    invoke-virtual {v3, v5}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 144
    sget v3, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->listViewPosts:I

    invoke-virtual {p0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ListView;

    iput-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->listViewPosts:Landroid/widget/ListView;

    .line 147
    const-string v3, "layout_inflater"

    invoke-virtual {p0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/view/LayoutInflater;

    .line 148
    .local v3, "inflater":Landroid/view/LayoutInflater;
    sget v5, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->footer_federations:I

    const/4 v6, 0x0

    invoke-virtual {v3, v5, v6}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v5

    iput-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->footerContainer:Landroid/view/View;

    .line 149
    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->footerContainer:Landroid/view/View;

    sget v6, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnFooterFederations:I

    invoke-virtual {v5, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/Button;

    iput-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->btnFooterFederations:Landroid/widget/Button;

    .line 150
    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->btnFooterFederations:Landroid/widget/Button;

    invoke-virtual {v5, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 152
    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->listViewPosts:Landroid/widget/ListView;

    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->footerContainer:Landroid/view/View;

    invoke-virtual {v5, v6}, Landroid/widget/ListView;->addFooterView(Landroid/view/View;)V

    .line 154
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    iput-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->postsList:Ljava/util/ArrayList;

    .line 155
    new-instance v5, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;

    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->postsList:Ljava/util/ArrayList;

    invoke-direct {v5, p0, p0, v6}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;Landroid/content/Context;Ljava/util/ArrayList;)V

    iput-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->postAdapter:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;

    .line 156
    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->listViewPosts:Landroid/widget/ListView;

    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->postAdapter:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;

    invoke-virtual {v5, v6}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 157
    return-void
.end method

.method protected onDestroy()V
    .locals 1

    .line 323
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    .line 324
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->scheduler:Ljava/util/concurrent/ScheduledExecutorService;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->scheduler:Ljava/util/concurrent/ScheduledExecutorService;

    invoke-interface {v0}, Ljava/util/concurrent/ScheduledExecutorService;->isShutdown()Z

    move-result v0

    if-nez v0, :cond_0

    .line 325
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->scheduler:Ljava/util/concurrent/ScheduledExecutorService;

    invoke-interface {v0}, Ljava/util/concurrent/ScheduledExecutorService;->shutdownNow()Ljava/util/List;

    .line 327
    :cond_0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->schedulerNotifications:Ljava/util/concurrent/ScheduledExecutorService;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->schedulerNotifications:Ljava/util/concurrent/ScheduledExecutorService;

    invoke-interface {v0}, Ljava/util/concurrent/ScheduledExecutorService;->isShutdown()Z

    move-result v0

    if-nez v0, :cond_1

    .line 328
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->schedulerNotifications:Ljava/util/concurrent/ScheduledExecutorService;

    invoke-interface {v0}, Ljava/util/concurrent/ScheduledExecutorService;->shutdownNow()Ljava/util/List;

    .line 330
    :cond_1
    return-void
.end method

.method protected onResume()V
    .locals 5

    .line 161
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 162
    const-string v0, ""

    .line 164
    .local v0, "url":Ljava/lang/String;
    :try_start_0
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v1}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 165
    .local v1, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v2, Lorg/json/JSONObject;

    const-string v3, "config.cfg"

    invoke-virtual {v1, p0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 166
    .local v2, "jsonCfg":Lorg/json/JSONObject;
    const-string v3, "SERVER"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    .line 167
    .local v3, "server":Lorg/json/JSONObject;
    const-string v4, "url"

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    move-object v0, v4

    .line 170
    .end local v1    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v2    # "jsonCfg":Lorg/json/JSONObject;
    .end local v3    # "server":Lorg/json/JSONObject;
    goto :goto_0

    .line 168
    :catch_0
    move-exception v1

    .line 169
    .local v1, "e":Lorg/json/JSONException;
    invoke-virtual {v1}, Lorg/json/JSONException;->printStackTrace()V

    .line 171
    .end local v1    # "e":Lorg/json/JSONException;
    :goto_0
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$FetchFeedTask;

    const/4 v2, 0x0

    invoke-direct {v1, p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$FetchFeedTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity-IA;)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/feed"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/String;

    const/4 v4, 0x0

    aput-object v2, v3, v4

    invoke-virtual {v1, v3}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$FetchFeedTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 172
    return-void
.end method

.method public requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;
    .locals 1
    .param p1, "urlParam"    # Ljava/lang/String;
    .param p2, "method"    # Ljava/lang/String;
    .param p3, "json_body"    # Lorg/json/JSONObject;

    .line 318
    invoke-static {p1, p2, p3, p0}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
