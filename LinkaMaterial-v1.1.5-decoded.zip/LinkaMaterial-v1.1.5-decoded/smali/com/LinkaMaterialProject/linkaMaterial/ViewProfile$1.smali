.class Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile$1;
.super Ljava/lang/Object;
.source "ViewProfile.java"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile;

.field final synthetic val$usernameProfile:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 75
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile$1;->val$usernameProfile:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 4
    .param p1, "buttonView"    # Landroid/widget/CompoundButton;
    .param p2, "isChecked"    # Z

    .line 78
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 79
    .local v0, "jsonToggle":Lorg/json/JSONObject;
    const-string v1, "sender"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 80
    const-string v1, "receiver"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile$1;->val$usernameProfile:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 81
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/toggle-friend"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "post"

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile;

    invoke-static {v1, v2, v0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 84
    nop

    .end local v0    # "jsonToggle":Lorg/json/JSONObject;
    goto :goto_0

    .line 82
    :catch_0
    move-exception v0

    .line 83
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 85
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    return-void
.end method
