.class public Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;
.super Landroid/app/Activity;
.source "AddGroupChannel.java"


# instance fields
.field private btnSend:Landroid/widget/Button;

.field private edtName:Landroid/widget/EditText;

.field private url:Ljava/lang/String;

.field private username:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetedtName(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->edtName:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->url:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->username:Ljava/lang/String;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 1

    .line 16
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 19
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->username:Ljava/lang/String;

    .line 20
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->url:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 6
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 22
    const-string v0, ""

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 23
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->add_channel:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->setContentView(I)V

    .line 25
    :try_start_0
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v1}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 26
    .local v1, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v2, Lorg/json/JSONObject;

    const-string v3, "config.cfg"

    invoke-virtual {v1, p0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 27
    .local v2, "jsonCfg":Lorg/json/JSONObject;
    const-string v3, "SERVER"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    .line 28
    .local v3, "server":Lorg/json/JSONObject;
    const-string v4, "FAST_LOGIN"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    .line 29
    .local v4, "fastLogin":Lorg/json/JSONObject;
    const-string v5, "url"

    invoke-virtual {v3, v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->url:Ljava/lang/String;

    .line 30
    const-string v5, "username"

    invoke-virtual {v4, v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->username:Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 33
    .end local v1    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v2    # "jsonCfg":Lorg/json/JSONObject;
    .end local v3    # "server":Lorg/json/JSONObject;
    .end local v4    # "fastLogin":Lorg/json/JSONObject;
    goto :goto_0

    .line 31
    :catch_0
    move-exception v0

    .line 32
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 34
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnSend:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->btnSend:Landroid/widget/Button;

    .line 35
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtName:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->edtName:Landroid/widget/EditText;

    .line 36
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->btnSend:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel$1;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 56
    return-void
.end method
