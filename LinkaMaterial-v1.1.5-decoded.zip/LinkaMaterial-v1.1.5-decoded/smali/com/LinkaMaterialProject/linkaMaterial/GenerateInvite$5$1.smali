.class Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1;
.super Ljava/lang/Object;
.source "GenerateInvite.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;->onClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;)V
    .locals 0
    .param p1, "this$1"    # Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;

    .line 103
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    .line 107
    const-string v0, "status"

    const-string v1, ""

    :try_start_0
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 108
    .local v2, "jsonNew":Lorg/json/JSONObject;
    const-string v3, "username"

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;

    iget-object v4, v4, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 110
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;

    iget-object v4, v4, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "/create-invite"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "post"

    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;

    iget-object v5, v5, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    invoke-static {v3, v4, v2, v5}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    .line 112
    .local v3, "resp":Ljava/lang/String;
    if-eqz v3, :cond_1

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_1

    .line 113
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 114
    .local v4, "jsonResp":Lorg/json/JSONObject;
    invoke-virtual {v4, v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 116
    .local v1, "status":Ljava/lang/String;
    const-string v5, "invite created!"

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    .line 117
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;

    iget-object v0, v0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->-$$Nest$mcarregarConvites(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)V

    goto :goto_0

    .line 119
    :cond_0
    const-string v5, "Erro ao criar convite"

    invoke-virtual {v4, v0, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 120
    .local v0, "msg":Ljava/lang/String;
    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;

    iget-object v5, v5, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    invoke-static {v5}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->-$$Nest$fgethandler(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)Landroid/os/Handler;

    move-result-object v5

    new-instance v6, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1$1;

    invoke-direct {v6, p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1;Ljava/lang/String;)V

    invoke-virtual {v5, v6}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 130
    .end local v0    # "msg":Ljava/lang/String;
    .end local v1    # "status":Ljava/lang/String;
    .end local v2    # "jsonNew":Lorg/json/JSONObject;
    .end local v3    # "resp":Ljava/lang/String;
    .end local v4    # "jsonResp":Lorg/json/JSONObject;
    :cond_1
    :goto_0
    goto :goto_1

    .line 128
    :catch_0
    move-exception v0

    .line 129
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 131
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_1
    return-void
.end method
