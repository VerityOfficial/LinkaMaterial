.class public final synthetic Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
