.class public final synthetic Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
