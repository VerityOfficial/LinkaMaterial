.class Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;
.super Ljava/lang/Object;
.source "FederationsFeed.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "ViewHolder"
.end annotation


# instance fields
.field avatarPost:Landroid/widget/ImageView;

.field btnComments:Landroid/widget/Button;

.field imgPost:Landroid/widget/ImageView;

.field final synthetic this$1:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;

.field tvDate:Landroid/widget/TextView;

.field tvStarCount:Landroid/widget/TextView;

.field tvText:Landroid/widget/TextView;

.field tvUsername:Landroid/widget/TextView;


# direct methods
.method private constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;)V
    .locals 0

    .line 356
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;)V

    return-void
.end method
