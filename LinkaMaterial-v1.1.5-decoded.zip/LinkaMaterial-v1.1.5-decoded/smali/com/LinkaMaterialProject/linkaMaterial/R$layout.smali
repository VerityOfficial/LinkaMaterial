.class public final Lcom/LinkaMaterialProject/linkaMaterial/R$layout;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static activity_change_server:I = 0x7f050000

.field public static activity_channels:I = 0x7f050001

.field public static activity_chat:I = 0x7f050002

.field public static activity_enter_group:I = 0x7f050003

.field public static activity_federations:I = 0x7f050004

.field public static activity_feed_finder:I = 0x7f050005

.field public static activity_friends:I = 0x7f050006

.field public static activity_home:I = 0x7f050007

.field public static activity_inbox:I = 0x7f050008

.field public static activity_login:I = 0x7f050009

.field public static activity_new_chat:I = 0x7f05000a

.field public static activity_new_group:I = 0x7f05000b

.field public static activity_options:I = 0x7f05000c

.field public static activity_register:I = 0x7f05000d

.field public static add_channel:I = 0x7f05000e

.field public static add_group_member:I = 0x7f05000f

.field public static bg_profile_border:I = 0x7f050010

.field public static bubble_mine:I = 0x7f050011

.field public static bubble_other:I = 0x7f050012

.field public static card_member:I = 0x7f050013

.field public static change_biography:I = 0x7f050014

.field public static change_group_name:I = 0x7f050015

.field public static chat_bubble_item:I = 0x7f050016

.field public static comments_activity:I = 0x7f050017

.field public static config_group:I = 0x7f050018

.field public static dm_chat:I = 0x7f050019

.field public static edit_account_activity:I = 0x7f05001a

.field public static external_chat:I = 0x7f05001b

.field public static footer_federations:I = 0x7f05001c

.field public static generate_invite:I = 0x7f05001d

.field public static global_chat:I = 0x7f05001e

.field public static header_global_chat:I = 0x7f05001f

.field public static item_channel:I = 0x7f050020

.field public static item_chat:I = 0x7f050021

.field public static item_comment:I = 0x7f050022

.field public static item_federations:I = 0x7f050023

.field public static item_header:I = 0x7f050024

.field public static item_inbox:I = 0x7f050025

.field public static item_post:I = 0x7f050026

.field public static my_profile:I = 0x7f050027

.field public static new_post_activity:I = 0x7f050028

.field public static view_picture:I = 0x7f050029

.field public static view_profile:I = 0x7f05002a


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
