.class public Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;
.super Landroid/app/Activity;
.source "InboxActivity.java"


# instance fields
.field private adapter:Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;

.field private btnChat:Landroid/widget/ImageButton;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;

.field private itemList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;",
            ">;"
        }
    .end annotation
.end field

.field private lvInbox:Landroid/widget/ListView;

.field private url:Ljava/lang/String;

.field private username:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 13
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 17
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->url:Ljava/lang/String;

    .line 18
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->username:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 10
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 25
    const-string v0, "username"

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 26
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->activity_inbox:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->setContentView(I)V

    .line 27
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->lvInbox:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ListView;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->lvInbox:Landroid/widget/ListView;

    .line 28
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->itemList:Ljava/util/List;

    .line 29
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->btnHome:Landroid/widget/ImageButton;

    .line 30
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->btnChat:Landroid/widget/ImageButton;

    .line 31
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->btnOptions:Landroid/widget/ImageButton;

    .line 32
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->btnProfile:Landroid/widget/ImageButton;

    .line 34
    :try_start_0
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v1}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 35
    .local v1, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v2, Lorg/json/JSONObject;

    const-string v3, "config.cfg"

    invoke-virtual {v1, p0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 36
    .local v2, "jsonCfg":Lorg/json/JSONObject;
    const-string v3, "FAST_LOGIN"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    .line 37
    .local v3, "fastLogin":Lorg/json/JSONObject;
    const-string v4, "SERVER"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    .line 38
    .local v4, "server":Lorg/json/JSONObject;
    const-string v5, "url"

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->url:Ljava/lang/String;

    .line 39
    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->username:Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 42
    .end local v1    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v2    # "jsonCfg":Lorg/json/JSONObject;
    .end local v3    # "fastLogin":Lorg/json/JSONObject;
    .end local v4    # "server":Lorg/json/JSONObject;
    goto :goto_0

    .line 40
    :catch_0
    move-exception v1

    .line 41
    .local v1, "e":Lorg/json/JSONException;
    invoke-virtual {v1}, Lorg/json/JSONException;->printStackTrace()V

    .line 44
    .end local v1    # "e":Lorg/json/JSONException;
    :goto_0
    :try_start_1
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    .line 45
    .local v1, "jsonInbox":Lorg/json/JSONObject;
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->username:Ljava/lang/String;

    invoke-virtual {v1, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 46
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->url:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "/inbox"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "post"

    invoke-static {v0, v2, v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    .line 47
    .local v0, "responseStr":Ljava/lang/String;
    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    const-string v3, ""

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1

    .line 48
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 49
    .local v2, "rootObject":Lorg/json/JSONObject;
    const-string v3, "inbox"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    .line 50
    .local v3, "inboxArray":Lorg/json/JSONArray;
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_1
    invoke-virtual {v3}, Lorg/json/JSONArray;->length()I

    move-result v5

    if-ge v4, v5, :cond_1

    .line 51
    invoke-virtual {v3, v4}, Lorg/json/JSONArray;->getJSONArray(I)Lorg/json/JSONArray;

    move-result-object v5

    .line 52
    .local v5, "subArray":Lorg/json/JSONArray;
    invoke-virtual {v5}, Lorg/json/JSONArray;->length()I

    move-result v6

    const/4 v7, 0x3

    if-lt v6, v7, :cond_0

    .line 53
    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v6

    .line 54
    .local v6, "sender":Ljava/lang/String;
    const/4 v7, 0x2

    invoke-virtual {v5, v7}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v7

    .line 55
    .local v7, "message":Ljava/lang/String;
    new-instance v8, Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;

    invoke-direct {v8, v6, v7}, Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 56
    .local v8, "item":Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;
    iget-object v9, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->itemList:Ljava/util/List;

    invoke-interface {v9, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 50
    .end local v5    # "subArray":Lorg/json/JSONArray;
    .end local v6    # "sender":Ljava/lang/String;
    .end local v7    # "message":Ljava/lang/String;
    .end local v8    # "item":Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;
    :cond_0
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    .line 62
    .end local v0    # "responseStr":Ljava/lang/String;
    .end local v1    # "jsonInbox":Lorg/json/JSONObject;
    .end local v2    # "rootObject":Lorg/json/JSONObject;
    .end local v3    # "inboxArray":Lorg/json/JSONArray;
    .end local v4    # "i":I
    :cond_1
    goto :goto_2

    .line 60
    :catch_1
    move-exception v0

    .line 61
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 63
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_2
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->itemList:Ljava/util/List;

    invoke-direct {v0, p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;-><init>(Landroid/content/Context;Ljava/util/List;)V

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->adapter:Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;

    .line 64
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->lvInbox:Landroid/widget/ListView;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->adapter:Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 65
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->btnHome:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity$1;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 72
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->btnChat:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity$2;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 79
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->btnOptions:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity$3;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 86
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;->btnProfile:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity$4;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/InboxActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 93
    return-void
.end method
