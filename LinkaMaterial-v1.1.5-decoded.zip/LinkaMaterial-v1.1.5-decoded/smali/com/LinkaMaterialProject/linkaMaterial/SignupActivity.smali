.class public Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;
.super Landroid/app/Activity;
.source "SignupActivity.java"


# instance fields
.field private btnRegister:Landroid/widget/Button;

.field private edtEmail:Landroid/widget/EditText;

.field private edtInvite:Landroid/widget/EditText;

.field private edtPassword:Landroid/widget/EditText;

.field private edtRetypePassword:Landroid/widget/EditText;

.field private edtUsername:Landroid/widget/EditText;

.field private txtGoToSignin:Landroid/widget/TextView;

.field private url:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetedtEmail(Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->edtEmail:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetedtPassword(Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->edtPassword:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetedtRetypePassword(Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->edtRetypePassword:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetedtUsername(Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->edtUsername:Landroid/widget/EditText;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 1

    .line 20
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 28
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->url:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 6
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 76
    const-string v0, "config.cfg"

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 78
    :try_start_0
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v1}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 79
    .local v1, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v2, Lorg/json/JSONObject;

    invoke-virtual {v1, p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 80
    .local v2, "jsonCfg":Lorg/json/JSONObject;
    const-string v3, "SERVER"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    .line 81
    .local v3, "server":Lorg/json/JSONObject;
    const-string v4, "url"

    const-string v5, ""

    invoke-virtual {v3, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->url:Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 84
    .end local v1    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v2    # "jsonCfg":Lorg/json/JSONObject;
    .end local v3    # "server":Lorg/json/JSONObject;
    goto :goto_0

    .line 82
    :catch_0
    move-exception v1

    .line 83
    .local v1, "e":Lorg/json/JSONException;
    invoke-virtual {v1}, Lorg/json/JSONException;->printStackTrace()V

    .line 86
    .end local v1    # "e":Lorg/json/JSONException;
    :goto_0
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v1}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 87
    .local v1, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->url:Ljava/lang/String;

    .line 88
    .local v2, "baseUrl":Ljava/lang/String;
    invoke-virtual {v1, p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/config;->deleteFileMaterial(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    .line 89
    invoke-virtual {v1, p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/config;->createDefaultConfig(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    .line 91
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->activity_register:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->setContentView(I)V

    .line 93
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtUsername:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->edtUsername:Landroid/widget/EditText;

    .line 94
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtPassword:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->edtPassword:Landroid/widget/EditText;

    .line 95
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtRetypePassword:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->edtRetypePassword:Landroid/widget/EditText;

    .line 96
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtEmail:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->edtEmail:Landroid/widget/EditText;

    .line 97
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->txtGoToSignin:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->txtGoToSignin:Landroid/widget/TextView;

    .line 98
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnRegister:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->btnRegister:Landroid/widget/Button;

    .line 100
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->btnRegister:Landroid/widget/Button;

    new-instance v3, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;

    invoke-direct {v3, p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;Ljava/lang/String;)V

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 140
    return-void
.end method

.method public requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;
    .locals 8
    .param p1, "urlParam"    # Ljava/lang/String;
    .param p2, "method"    # Ljava/lang/String;
    .param p3, "json_body"    # Lorg/json/JSONObject;

    .line 31
    const/4 v0, 0x0

    .line 33
    .local v0, "connection":Ljava/net/HttpURLConnection;
    :try_start_0
    new-instance v1, Ljava/net/URL;

    invoke-direct {v1, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 34
    .local v1, "url":Ljava/net/URL;
    invoke-virtual {v1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v2

    check-cast v2, Ljava/net/HttpURLConnection;

    move-object v0, v2

    .line 36
    invoke-virtual {p2}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v2

    move-object p2, v2

    .line 37
    const-string v2, "post"

    invoke-virtual {p2, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 38
    const-string v2, "POST"

    invoke-virtual {v0, v2}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    goto :goto_0

    .line 39
    :cond_0
    const-string v2, "get"

    invoke-virtual {p2, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 40
    const-string v2, "GET"

    invoke-virtual {v0, v2}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 43
    :cond_1
    :goto_0
    const-string v2, "Content-Type"

    const-string v3, "application/json"

    invoke-virtual {v0, v2, v3}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 44
    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Ljava/net/HttpURLConnection;->setDoOutput(Z)V

    .line 46
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v2

    .line 47
    .local v2, "os":Ljava/io/OutputStream;
    invoke-virtual {p3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "UTF-8"

    invoke-virtual {v3, v4}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/io/OutputStream;->write([B)V

    .line 48
    invoke-virtual {v2}, Ljava/io/OutputStream;->flush()V

    .line 49
    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V

    .line 51
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v3

    .line 54
    .local v3, "responseCode":I
    const/16 v4, 0xc8

    if-lt v3, v4, :cond_4

    const/16 v4, 0x12c

    if-ge v3, v4, :cond_4

    .line 55
    new-instance v4, Ljava/io/BufferedReader;

    new-instance v5, Ljava/io/InputStreamReader;

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v4, v5}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 56
    .local v4, "in":Ljava/io/BufferedReader;
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 58
    .local v5, "response":Ljava/lang/StringBuilder;
    :goto_1
    invoke-virtual {v4}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v6

    move-object v7, v6

    .local v7, "line":Ljava/lang/String;
    if-eqz v6, :cond_2

    .line 59
    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    .line 61
    :cond_2
    invoke-virtual {v4}, Ljava/io/BufferedReader;->close()V

    .line 62
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 67
    if-eqz v0, :cond_3

    .line 68
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 62
    :cond_3
    return-object v6

    .line 67
    .end local v1    # "url":Ljava/net/URL;
    .end local v2    # "os":Ljava/io/OutputStream;
    .end local v3    # "responseCode":I
    .end local v4    # "in":Ljava/io/BufferedReader;
    .end local v5    # "response":Ljava/lang/StringBuilder;
    .end local v7    # "line":Ljava/lang/String;
    :cond_4
    if-eqz v0, :cond_5

    .line 68
    :goto_2
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    goto :goto_3

    .line 67
    :catchall_0
    move-exception v1

    goto :goto_4

    .line 64
    :catch_0
    move-exception v1

    .line 65
    .local v1, "e":Ljava/lang/Exception;
    :try_start_1
    invoke-virtual {v1}, Ljava/lang/Exception;->printStackTrace()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 67
    .end local v1    # "e":Ljava/lang/Exception;
    if-eqz v0, :cond_5

    .line 68
    goto :goto_2

    .line 71
    :cond_5
    :goto_3
    const-string v1, ""

    return-object v1

    .line 67
    :goto_4
    if-eqz v0, :cond_6

    .line 68
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 70
    :cond_6
    goto :goto_6

    :goto_5
    throw v1

    :goto_6
    goto :goto_5
.end method
