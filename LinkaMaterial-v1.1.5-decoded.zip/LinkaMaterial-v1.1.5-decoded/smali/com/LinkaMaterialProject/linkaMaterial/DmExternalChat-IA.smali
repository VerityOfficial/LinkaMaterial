.class public final synthetic Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
