.class Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$1;
.super Ljava/lang/Object;
.source "ChatGlobalActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    .line 54
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 57
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->-$$Nest$fgetedtInputMessage(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 58
    .local v0, "text_message":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_0

    .line 59
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->-$$Nest$fgetedtInputMessage(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)Landroid/widget/EditText;

    move-result-object v1

    const-string v2, ""

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 60
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$SendMessageTask;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    invoke-direct {v1, v2, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$SendMessageTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;Ljava/lang/String;)V

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Void;

    invoke-virtual {v1, v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$SendMessageTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 62
    :cond_0
    return-void
.end method
