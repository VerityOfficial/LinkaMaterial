.class public Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;
.super Landroid/app/Activity;
.source "addFriendActivity.java"


# instance fields
.field private btnChat:Landroid/widget/ImageButton;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;

.field private btnSend:Landroid/widget/Button;

.field private edtMessage:Landroid/widget/EditText;

.field private edtUsername:Landroid/widget/EditText;

.field private url:Ljava/lang/String;

.field private username:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetedtMessage(Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->edtMessage:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetedtUsername(Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->edtUsername:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->url:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->username:Ljava/lang/String;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 1

    .line 33
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 37
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->url:Ljava/lang/String;

    .line 38
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->username:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 3
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 45
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 46
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->activity_friends:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->setContentView(I)V

    .line 47
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtUsername:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->edtUsername:Landroid/widget/EditText;

    .line 48
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtMessage:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->edtMessage:Landroid/widget/EditText;

    .line 49
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnSend:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->btnSend:Landroid/widget/Button;

    .line 50
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->btnHome:Landroid/widget/ImageButton;

    .line 51
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->btnChat:Landroid/widget/ImageButton;

    .line 52
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->btnOptions:Landroid/widget/ImageButton;

    .line 53
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->btnProfile:Landroid/widget/ImageButton;

    .line 54
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/AppConfig;

    invoke-direct {v0, p0}, Lcom/LinkaMaterialProject/linkaMaterial/AppConfig;-><init>(Landroid/content/Context;)V

    .line 55
    .local v0, "config":Lcom/LinkaMaterialProject/linkaMaterial/AppConfig;
    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/AppConfig;->getUrl()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->url:Ljava/lang/String;

    .line 56
    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/AppConfig;->getUsername()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->username:Ljava/lang/String;

    .line 57
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->btnSend:Landroid/widget/Button;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$1;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 75
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->btnHome:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$2;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 82
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->btnOptions:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$3;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 89
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->btnProfile:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$4;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 96
    return-void
.end method
