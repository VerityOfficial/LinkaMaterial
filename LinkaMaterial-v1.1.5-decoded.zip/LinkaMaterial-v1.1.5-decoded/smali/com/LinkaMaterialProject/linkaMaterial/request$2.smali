.class Lcom/LinkaMaterialProject/linkaMaterial/request$2;
.super Ljava/lang/Object;
.source "request.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/request;->requestBytesAsync(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lcom/LinkaMaterialProject/linkaMaterial/request$RequestBytesCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$callback:Lcom/LinkaMaterialProject/linkaMaterial/request$RequestBytesCallback;

.field final synthetic val$context:Landroid/content/Context;

.field final synthetic val$method:Ljava/lang/String;

.field final synthetic val$urlParam:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lcom/LinkaMaterialProject/linkaMaterial/request$RequestBytesCallback;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 48
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$2;->val$urlParam:Ljava/lang/String;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$2;->val$method:Ljava/lang/String;

    iput-object p3, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$2;->val$context:Landroid/content/Context;

    iput-object p4, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$2;->val$callback:Lcom/LinkaMaterialProject/linkaMaterial/request$RequestBytesCallback;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 52
    :try_start_0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$2;->val$urlParam:Ljava/lang/String;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$2;->val$method:Ljava/lang/String;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$2;->val$context:Landroid/content/Context;

    invoke-static {v0, v1, v2}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestBytes(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)[B

    move-result-object v0

    .line 53
    .local v0, "result":[B
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$2;->val$callback:Lcom/LinkaMaterialProject/linkaMaterial/request$RequestBytesCallback;

    if-eqz v1, :cond_0

    .line 54
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/request$2$1;

    invoke-direct {v2, p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/request$2$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/request$2;[B)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 70
    .end local v0    # "result":[B
    :cond_0
    goto :goto_0

    .line 61
    :catch_0
    move-exception v0

    .line 62
    .local v0, "e":Ljava/lang/Exception;
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$2;->val$callback:Lcom/LinkaMaterialProject/linkaMaterial/request$RequestBytesCallback;

    if-eqz v1, :cond_1

    .line 63
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/request$2$2;

    invoke-direct {v2, p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/request$2$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/request$2;Ljava/lang/Exception;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 71
    .end local v0    # "e":Ljava/lang/Exception;
    :cond_1
    :goto_0
    return-void
.end method
