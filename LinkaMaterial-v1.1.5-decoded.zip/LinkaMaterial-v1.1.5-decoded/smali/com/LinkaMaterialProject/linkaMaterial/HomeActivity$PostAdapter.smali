.class Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;
.super Landroid/widget/BaseAdapter;
.source "HomeActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "PostAdapter"
.end annotation


# instance fields
.field private context:Landroid/content/Context;

.field private list:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lorg/json/JSONObject;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;


# direct methods
.method static bridge synthetic -$$Nest$fgetlist(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;)Ljava/util/ArrayList;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;->list:Ljava/util/ArrayList;

    return-object p0
.end method

.method public constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;Landroid/content/Context;Ljava/util/ArrayList;)V
    .locals 0
    .param p2, "context"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/ArrayList<",
            "Lorg/json/JSONObject;",
            ">;)V"
        }
    .end annotation

    .line 208
    .local p3, "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lorg/json/JSONObject;>;"
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 209
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;->context:Landroid/content/Context;

    .line 210
    iput-object p3, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;->list:Ljava/util/ArrayList;

    .line 211
    return-void
.end method


# virtual methods
.method public getCount()I
    .locals 1

    .line 215
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;->list:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .locals 1
    .param p1, "position"    # I

    .line 220
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;->list:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public getItemId(I)J
    .locals 2
    .param p1, "position"    # I

    .line 225
    int-to-long v0, p1

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 24
    .param p1, "position"    # I
    .param p2, "convertView"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 230
    move-object/from16 v1, p0

    move/from16 v2, p1

    const-string v0, "[IMAGE]"

    const-string v3, ""

    const/4 v4, 0x0

    if-nez p2, :cond_0

    .line 231
    iget-object v5, v1, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;->context:Landroid/content/Context;

    const-string v6, "layout_inflater"

    invoke-virtual {v5, v6}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/view/LayoutInflater;

    .line 232
    .local v5, "inflater":Landroid/view/LayoutInflater;
    sget v6, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->item_post:I

    invoke-virtual {v5, v6, v4}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v6

    .end local p2    # "convertView":Landroid/view/View;
    .local v6, "convertView":Landroid/view/View;
    goto :goto_0

    .line 230
    .end local v5    # "inflater":Landroid/view/LayoutInflater;
    .end local v6    # "convertView":Landroid/view/View;
    .restart local p2    # "convertView":Landroid/view/View;
    :cond_0
    move-object/from16 v6, p2

    .line 235
    .end local p2    # "convertView":Landroid/view/View;
    .restart local v6    # "convertView":Landroid/view/View;
    :goto_0
    sget v5, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->postAvatar:I

    invoke-virtual {v6, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/ImageView;

    .line 236
    .local v5, "avatarPost":Landroid/widget/ImageView;
    sget v7, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->imgPost:I

    invoke-virtual {v6, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    check-cast v7, Landroid/widget/ImageView;

    .line 237
    .local v7, "imgPost":Landroid/widget/ImageView;
    sget v8, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->postUsername:I

    invoke-virtual {v6, v8}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v8

    check-cast v8, Landroid/widget/TextView;

    .line 239
    .local v8, "tvUsername":Landroid/widget/TextView;
    new-instance v9, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$1;

    invoke-direct {v9, v1, v2}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;I)V

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 250
    sget v9, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->postText:I

    invoke-virtual {v6, v9}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v9

    check-cast v9, Landroid/widget/TextView;

    .line 251
    .local v9, "tvText":Landroid/widget/TextView;
    sget v10, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->postDate:I

    invoke-virtual {v6, v10}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/TextView;

    .line 252
    .local v10, "tvDate":Landroid/widget/TextView;
    sget v11, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->starCount:I

    invoke-virtual {v6, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v11

    check-cast v11, Landroid/widget/TextView;

    .line 253
    .local v11, "tvStarCount":Landroid/widget/TextView;
    sget v12, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnComments:I

    invoke-virtual {v6, v12}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v12

    check-cast v12, Landroid/widget/Button;

    .line 255
    .local v12, "btnComments":Landroid/widget/Button;
    invoke-virtual {v7, v4}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 256
    const/16 v4, 0x8

    invoke-virtual {v7, v4}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 259
    :try_start_0
    iget-object v4, v1, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;->list:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lorg/json/JSONObject;

    .line 260
    .local v4, "post":Lorg/json/JSONObject;
    const-string v13, "username"

    const-string v14, "user"

    const-string v15, "entity404"

    invoke-virtual {v4, v14, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v4, v13, v14}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 261
    .local v13, "username":Ljava/lang/String;
    const-string v14, "text_post"

    const-string v15, "text"

    invoke-virtual {v4, v15, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v4, v14, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    .line 262
    .local v14, "textPost":Ljava/lang/String;
    const-string v15, "datetime"

    const-string v2, "date"

    invoke-virtual {v4, v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v15, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 263
    .local v2, "datetime":Ljava/lang/String;
    const-string v15, "id"

    invoke-virtual {v4, v15, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_4

    .line 264
    .local v15, "id":Ljava/lang/String;
    move-object/from16 p2, v6

    .end local v6    # "convertView":Landroid/view/View;
    .restart local p2    # "convertView":Landroid/view/View;
    :try_start_1
    const-string v6, "stars"
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_3

    move-object/from16 v16, v9

    .end local v9    # "tvText":Landroid/widget/TextView;
    .local v16, "tvText":Landroid/widget/TextView;
    :try_start_2
    const-string v9, "0"

    invoke-virtual {v4, v6, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 266
    .local v6, "stars":Ljava/lang/String;
    new-instance v9, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$2;

    invoke-direct {v9, v1, v15}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;Ljava/lang/String;)V

    invoke-virtual {v12, v9}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 275
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v17, v4

    .end local v4    # "post":Lorg/json/JSONObject;
    .local v17, "post":Lorg/json/JSONObject;
    const-string v4, "@"

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v8, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 276
    invoke-virtual {v10, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 277
    invoke-virtual {v11, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 279
    new-instance v4, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;

    invoke-direct {v4}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;-><init>()V

    .line 280
    .local v4, "imageLoader":Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;
    iget-object v9, v1, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;->context:Landroid/content/Context;

    invoke-virtual {v4, v9, v13, v5}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;->viewProfilePicture(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 282
    invoke-virtual {v14, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    if-eqz v9, :cond_3

    .line 283
    :try_start_3
    const-string v9, "\n"

    invoke-virtual {v14, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v9

    .line 284
    .local v9, "lines":[Ljava/lang/String;
    move-object/from16 v18, v2

    .end local v2    # "datetime":Ljava/lang/String;
    .local v18, "datetime":Ljava/lang/String;
    array-length v2, v9

    move-object/from16 v19, v4

    .end local v4    # "imageLoader":Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;
    .local v19, "imageLoader":Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;
    const/4 v4, 0x0

    :goto_1
    if-ge v4, v2, :cond_4

    aget-object v21, v9, v4

    move-object/from16 v22, v21

    .line 285
    .local v22, "line":Ljava/lang/String;
    move/from16 v21, v2

    move-object/from16 v2, v22

    .end local v22    # "line":Ljava/lang/String;
    .local v2, "line":Ljava/lang/String;
    invoke-virtual {v2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v22

    if-eqz v22, :cond_2

    .line 286
    invoke-virtual {v2, v0, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v22

    move-object/from16 v23, v22

    .line 287
    .local v23, "newUrl":Ljava/lang/String;
    invoke-virtual/range {v23 .. v23}, Ljava/lang/String;->isEmpty()Z

    move-result v22

    if-nez v22, :cond_1

    .line 288
    const/4 v0, 0x0

    invoke-virtual {v7, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 289
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "http://linkaProject.pythonanywhere.com/lite-render?url="

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v4, v23

    .end local v23    # "newUrl":Ljava/lang/String;
    .local v4, "newUrl":Ljava/lang/String;
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 291
    .local v0, "urlProxy":Ljava/lang/String;
    move-object/from16 v20, v4

    .end local v4    # "newUrl":Ljava/lang/String;
    .local v20, "newUrl":Ljava/lang/String;
    new-instance v4, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$3;

    invoke-direct {v4, v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;Ljava/lang/String;)V

    invoke-virtual {v7, v4}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 301
    new-instance v4, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;

    invoke-direct {v4}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;-><init>()V

    invoke-virtual {v4, v0, v7}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;->LoadImageUrl(Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 302
    invoke-virtual {v14, v2, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    move-object v14, v3

    .line 303
    goto :goto_3

    .line 287
    .end local v0    # "urlProxy":Ljava/lang/String;
    .end local v20    # "newUrl":Ljava/lang/String;
    .restart local v23    # "newUrl":Ljava/lang/String;
    :cond_1
    move-object/from16 v20, v23

    const/16 v22, 0x0

    .end local v23    # "newUrl":Ljava/lang/String;
    .restart local v20    # "newUrl":Ljava/lang/String;
    goto :goto_2

    .line 285
    .end local v20    # "newUrl":Ljava/lang/String;
    :cond_2
    const/16 v22, 0x0

    .line 284
    .end local v2    # "line":Ljava/lang/String;
    :goto_2
    add-int/lit8 v4, v4, 0x1

    move/from16 v2, v21

    goto :goto_1

    .line 309
    .end local v6    # "stars":Ljava/lang/String;
    .end local v9    # "lines":[Ljava/lang/String;
    .end local v13    # "username":Ljava/lang/String;
    .end local v14    # "textPost":Ljava/lang/String;
    .end local v15    # "id":Ljava/lang/String;
    .end local v17    # "post":Lorg/json/JSONObject;
    .end local v18    # "datetime":Ljava/lang/String;
    .end local v19    # "imageLoader":Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;
    :catch_0
    move-exception v0

    move-object/from16 v2, v16

    goto :goto_4

    .line 282
    .local v2, "datetime":Ljava/lang/String;
    .local v4, "imageLoader":Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;
    .restart local v6    # "stars":Ljava/lang/String;
    .restart local v13    # "username":Ljava/lang/String;
    .restart local v14    # "textPost":Ljava/lang/String;
    .restart local v15    # "id":Ljava/lang/String;
    .restart local v17    # "post":Lorg/json/JSONObject;
    :cond_3
    move-object/from16 v18, v2

    move-object/from16 v19, v4

    .line 308
    .end local v2    # "datetime":Ljava/lang/String;
    .end local v4    # "imageLoader":Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;
    .restart local v18    # "datetime":Ljava/lang/String;
    .restart local v19    # "imageLoader":Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;
    :cond_4
    :goto_3
    move-object/from16 v2, v16

    .end local v16    # "tvText":Landroid/widget/TextView;
    .local v2, "tvText":Landroid/widget/TextView;
    :try_start_4
    invoke-virtual {v2, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1

    .line 311
    .end local v6    # "stars":Ljava/lang/String;
    .end local v13    # "username":Ljava/lang/String;
    .end local v14    # "textPost":Ljava/lang/String;
    .end local v15    # "id":Ljava/lang/String;
    .end local v17    # "post":Lorg/json/JSONObject;
    .end local v18    # "datetime":Ljava/lang/String;
    .end local v19    # "imageLoader":Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;
    goto :goto_5

    .line 309
    :catch_1
    move-exception v0

    goto :goto_4

    .end local v2    # "tvText":Landroid/widget/TextView;
    .restart local v16    # "tvText":Landroid/widget/TextView;
    :catch_2
    move-exception v0

    move-object/from16 v2, v16

    .end local v16    # "tvText":Landroid/widget/TextView;
    .restart local v2    # "tvText":Landroid/widget/TextView;
    goto :goto_4

    .end local v2    # "tvText":Landroid/widget/TextView;
    .local v9, "tvText":Landroid/widget/TextView;
    :catch_3
    move-exception v0

    move-object v2, v9

    .end local v9    # "tvText":Landroid/widget/TextView;
    .restart local v2    # "tvText":Landroid/widget/TextView;
    goto :goto_4

    .end local v2    # "tvText":Landroid/widget/TextView;
    .end local p2    # "convertView":Landroid/view/View;
    .local v6, "convertView":Landroid/view/View;
    .restart local v9    # "tvText":Landroid/widget/TextView;
    :catch_4
    move-exception v0

    move-object/from16 p2, v6

    move-object v2, v9

    .line 310
    .end local v6    # "convertView":Landroid/view/View;
    .end local v9    # "tvText":Landroid/widget/TextView;
    .local v0, "e":Ljava/lang/Exception;
    .restart local v2    # "tvText":Landroid/widget/TextView;
    .restart local p2    # "convertView":Landroid/view/View;
    :goto_4
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 313
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_5
    return-object p2
.end method
