.class public Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;
.super Landroid/app/Activity;
.source "optionActivity.java"


# instance fields
.field private btnChangeServer:Landroid/widget/Button;

.field private btnChat:Landroid/widget/ImageButton;

.field private btnFriends:Landroid/widget/Button;

.field private btnGenerateInvite:Landroid/widget/Button;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnInbox:Landroid/widget/Button;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 32
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 2
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 43
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 44
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->activity_options:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->setContentView(I)V

    .line 45
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnInbox:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->btnInbox:Landroid/widget/Button;

    .line 46
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnFriends:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->btnFriends:Landroid/widget/Button;

    .line 47
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChangeServer:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->btnChangeServer:Landroid/widget/Button;

    .line 48
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->btnHome:Landroid/widget/ImageButton;

    .line 49
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->btnChat:Landroid/widget/ImageButton;

    .line 50
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->btnOptions:Landroid/widget/ImageButton;

    .line 51
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->btnProfile:Landroid/widget/ImageButton;

    .line 52
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnGenerateInvite:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->btnGenerateInvite:Landroid/widget/Button;

    .line 53
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->btnGenerateInvite:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity$1;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 60
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->btnHome:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity$2;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 67
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->btnChat:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity$3;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 74
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->btnProfile:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity$4;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 81
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->btnFriends:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity$5;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity$5;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 88
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->btnInbox:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity$6;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity$6;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 95
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;->btnChangeServer:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity$7;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity$7;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 102
    return-void
.end method
