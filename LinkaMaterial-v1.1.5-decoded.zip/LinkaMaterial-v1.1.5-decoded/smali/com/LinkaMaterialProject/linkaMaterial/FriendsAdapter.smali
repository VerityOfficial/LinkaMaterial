.class public Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;
.super Landroid/widget/BaseAdapter;
.source "FriendsAdapter.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter$ViewHolder;
    }
.end annotation


# static fields
.field public static final TYPE_FRIEND:I = 0x0

.field public static final TYPE_GROUP:I = 0x1

.field public static final TYPE_HEADER:I = 0x2


# instance fields
.field private context:Landroid/content/Context;

.field private inflater:Landroid/view/LayoutInflater;

.field private items:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/util/List;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;",
            ">;)V"
        }
    .end annotation

    .line 16
    .local p2, "items":Ljava/util/List;, "Ljava/util/List<Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;>;"
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 17
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;->context:Landroid/content/Context;

    .line 18
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;->items:Ljava/util/List;

    .line 19
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;->inflater:Landroid/view/LayoutInflater;

    .line 20
    return-void
.end method


# virtual methods
.method public getCount()I
    .locals 1

    .line 23
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;->items:Ljava/util/List;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;->items:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .locals 1
    .param p1, "position"    # I

    .line 27
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;->items:Ljava/util/List;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;->items:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public getItemId(I)J
    .locals 2
    .param p1, "position"    # I

    .line 31
    int-to-long v0, p1

    return-wide v0
.end method

.method public getItemViewType(I)I
    .locals 1
    .param p1, "position"    # I

    .line 35
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;->items:Ljava/util/List;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;->items:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-ge p1, v0, :cond_0

    .line 36
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;->items:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->getType()I

    move-result v0

    return v0

    .line 38
    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 5
    .param p1, "position"    # I
    .param p2, "convertView"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 51
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;->items:Ljava/util/List;

    if-eqz v0, :cond_8

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;->items:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-lt p1, v0, :cond_0

    goto/16 :goto_5

    .line 54
    :cond_0
    if-nez p2, :cond_1

    .line 55
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;->inflater:Landroid/view/LayoutInflater;

    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->item_channel:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    .line 56
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter$ViewHolder;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter$ViewHolder;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter-IA;)V

    .line 57
    .local v0, "holder":Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter$ViewHolder;
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->txtChannelName:I

    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, v0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter$ViewHolder;->txtName:Landroid/widget/TextView;

    .line 58
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->txtChannelDescription:I

    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, v0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter$ViewHolder;->txtSubtitle:Landroid/widget/TextView;

    .line 59
    invoke-virtual {p2, v0}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    goto :goto_0

    .line 61
    .end local v0    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter$ViewHolder;
    :cond_1
    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter$ViewHolder;

    .line 63
    .restart local v0    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter$ViewHolder;
    :goto_0
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;->items:Ljava/util/List;

    invoke-interface {v1, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;

    .line 64
    .local v1, "item":Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;
    if-eqz v1, :cond_7

    .line 65
    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->getType()I

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_4

    .line 66
    iget-object v2, v0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter$ViewHolder;->txtName:Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "[Group] "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->getGroupName()Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_2

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->getGroupName()Ljava/lang/String;

    move-result-object v4

    goto :goto_1

    :cond_2
    const-string v4, "Sem Nome"

    :goto_1
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 67
    iget-object v2, v0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter$ViewHolder;->txtSubtitle:Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Permission: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->getPermissions()Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_3

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->getPermissions()Ljava/lang/String;

    move-result-object v4

    goto :goto_2

    :cond_3
    const-string v4, "membro"

    :goto_2
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_4

    .line 68
    :cond_4
    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->getType()I

    move-result v2

    const/4 v3, 0x2

    if-ne v2, v3, :cond_5

    .line 69
    iget-object v2, v0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter$ViewHolder;->txtName:Landroid/widget/TextView;

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->getGroupName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 70
    iget-object v2, v0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter$ViewHolder;->txtSubtitle:Landroid/widget/TextView;

    const-string v3, ""

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_4

    .line 72
    :cond_5
    iget-object v2, v0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter$ViewHolder;->txtName:Landroid/widget/TextView;

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->getUsername()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_6

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->getUsername()Ljava/lang/String;

    move-result-object v3

    goto :goto_3

    :cond_6
    const-string v3, "Usu\u00e1rio"

    :goto_3
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 73
    iget-object v2, v0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter$ViewHolder;->txtSubtitle:Landroid/widget/TextView;

    const-string v3, "DM"

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 76
    :cond_7
    :goto_4
    return-object p2

    .line 52
    .end local v0    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter$ViewHolder;
    .end local v1    # "item":Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;
    :cond_8
    :goto_5
    new-instance v0, Landroid/view/View;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;->context:Landroid/content/Context;

    invoke-direct {v0, v1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    return-object v0
.end method

.method public getViewTypeCount()I
    .locals 1

    .line 42
    const/4 v0, 0x3

    return v0
.end method
