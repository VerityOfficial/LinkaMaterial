.class public Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;
.super Landroid/app/Activity;
.source "ChangeGroupName.java"


# instance fields
.field private btnSend:Landroid/widget/Button;

.field private edtName:Landroid/widget/EditText;

.field private groupId:I

.field private url:Ljava/lang/String;

.field private username:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetedtName(Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->edtName:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetgroupId(Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;)I
    .locals 0

    iget p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->groupId:I

    return p0
.end method

.method static bridge synthetic -$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->url:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->username:Ljava/lang/String;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 1

    .line 12
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 15
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->username:Ljava/lang/String;

    .line 16
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->url:Ljava/lang/String;

    .line 17
    const/4 v0, -0x1

    iput v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->groupId:I

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 7
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 21
    const-string v0, ""

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 22
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->change_group_name:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->setContentView(I)V

    .line 24
    invoke-virtual {p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->getIntent()Landroid/content/Intent;

    move-result-object v1

    .line 25
    .local v1, "intent":Landroid/content/Intent;
    const-string v2, "groupId"

    const/4 v3, -0x1

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v2

    iput v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->groupId:I

    .line 28
    :try_start_0
    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v2}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 29
    .local v2, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v3, Lorg/json/JSONObject;

    const-string v4, "config.cfg"

    invoke-virtual {v2, p0, v4}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 30
    .local v3, "jsonCfg":Lorg/json/JSONObject;
    const-string v4, "FAST_LOGIN"

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    .line 31
    .local v4, "fastLogin":Lorg/json/JSONObject;
    const-string v5, "SERVER"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    .line 32
    .local v5, "server":Lorg/json/JSONObject;
    const-string v6, "url"

    invoke-virtual {v5, v6, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    iput-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->url:Ljava/lang/String;

    .line 33
    const-string v6, "username"

    invoke-virtual {v4, v6, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->username:Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 36
    .end local v2    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v3    # "jsonCfg":Lorg/json/JSONObject;
    .end local v4    # "fastLogin":Lorg/json/JSONObject;
    .end local v5    # "server":Lorg/json/JSONObject;
    goto :goto_0

    .line 34
    :catch_0
    move-exception v0

    .line 35
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 38
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtName:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->edtName:Landroid/widget/EditText;

    .line 39
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnSend:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->btnSend:Landroid/widget/Button;

    .line 41
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;->btnSend:Landroid/widget/Button;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName$1;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChangeGroupName;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 61
    return-void
.end method
