.class Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2;
.super Ljava/lang/Object;
.source "FederationsAdapter.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;->getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;

.field final synthetic val$imageSrc:Ljava/lang/String;

.field final synthetic val$targetImageView:Landroid/widget/ImageView;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;Ljava/lang/String;Landroid/widget/ImageView;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 91
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2;->val$imageSrc:Ljava/lang/String;

    iput-object p3, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2;->val$targetImageView:Landroid/widget/ImageView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 94
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2;->val$imageSrc:Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;->-$$Nest$mdownloadBitmap(Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    .line 95
    .local v0, "bitmap":Landroid/graphics/Bitmap;
    if-eqz v0, :cond_0

    .line 96
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2$1;

    invoke-direct {v2, p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2;Landroid/graphics/Bitmap;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 103
    :cond_0
    return-void
.end method
