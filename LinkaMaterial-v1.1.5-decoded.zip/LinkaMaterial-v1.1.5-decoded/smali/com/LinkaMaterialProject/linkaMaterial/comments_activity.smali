.class public Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;
.super Landroid/app/Activity;
.source "comments_activity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$FetchCommentsTask;,
        Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$SendCommentTask;
    }
.end annotation


# instance fields
.field private baseUrl:Ljava/lang/String;

.field private btnSend:Landroid/widget/Button;

.field private commentEdt:Landroid/widget/EditText;

.field private lvComments:Landroid/widget/ListView;

.field private postId:Ljava/lang/String;

.field private username:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetbaseUrl(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->baseUrl:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetcommentEdt(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->commentEdt:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetpostId(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->postId:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->username:Ljava/lang/String;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 1

    .line 15
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 17
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->postId:Ljava/lang/String;

    .line 20
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->username:Ljava/lang/String;

    .line 21
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->baseUrl:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 8
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 24
    const-string v0, ""

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 25
    invoke-virtual {p0}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v1

    .line 26
    .local v1, "extras":Landroid/os/Bundle;
    if-eqz v1, :cond_0

    .line 27
    const-string v2, "post_id"

    invoke-virtual {v1, v2}, Landroid/os/Bundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    .line 28
    .local v2, "idObj":Ljava/lang/Object;
    if-eqz v2, :cond_0

    .line 29
    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->postId:Ljava/lang/String;

    .line 33
    .end local v2    # "idObj":Ljava/lang/Object;
    :cond_0
    :try_start_0
    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v2}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 34
    .local v2, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    const-string v3, "config.cfg"

    invoke-virtual {v2, p0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 35
    .local v3, "cfgString":Ljava/lang/String;
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 36
    .local v4, "jsonCfg":Lorg/json/JSONObject;
    const-string v5, "SERVER"

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    .line 37
    .local v5, "server":Lorg/json/JSONObject;
    const-string v6, "FAST_LOGIN"

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v6

    .line 38
    .local v6, "fastLogin":Lorg/json/JSONObject;
    const-string v7, "username"

    invoke-virtual {v6, v7, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    iput-object v7, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->username:Ljava/lang/String;

    .line 39
    const-string v7, "url"

    invoke-virtual {v5, v7, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->baseUrl:Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 42
    .end local v2    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v3    # "cfgString":Ljava/lang/String;
    .end local v4    # "jsonCfg":Lorg/json/JSONObject;
    .end local v5    # "server":Lorg/json/JSONObject;
    .end local v6    # "fastLogin":Lorg/json/JSONObject;
    goto :goto_0

    .line 40
    :catch_0
    move-exception v0

    .line 41
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 43
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->comments_activity:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->setContentView(I)V

    .line 44
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->lvComments:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->lvComments:Landroid/widget/ListView;

    .line 45
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->commentEdt:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->commentEdt:Landroid/widget/EditText;

    .line 46
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnSend:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->btnSend:Landroid/widget/Button;

    .line 48
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->btnSend:Landroid/widget/Button;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$1;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 81
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->postId:Ljava/lang/String;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->postId:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    .line 82
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$FetchCommentsTask;

    const/4 v2, 0x0

    invoke-direct {v0, p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$FetchCommentsTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;Lcom/LinkaMaterialProject/linkaMaterial/comments_activity-IA;)V

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->postId:Ljava/lang/String;

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/String;

    const/4 v4, 0x0

    aput-object v2, v3, v4

    invoke-virtual {v0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$FetchCommentsTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 84
    :cond_1
    return-void
.end method

.method public parseCommentsResponse(Ljava/lang/String;)Ljava/util/List;
    .locals 10
    .param p1, "jsonResponse"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/Comment;",
            ">;"
        }
    .end annotation

    .line 115
    const-string v0, "comments"

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 117
    .local v1, "commentsList":Ljava/util/List;, "Ljava/util/List<Lcom/LinkaMaterialProject/linkaMaterial/Comment;>;"
    :try_start_0
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 118
    .local v2, "rootObject":Lorg/json/JSONObject;
    invoke-virtual {v2, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_0

    .line 119
    invoke-virtual {v2, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    .line 120
    .local v0, "commentsArray":Lorg/json/JSONArray;
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_0
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v4

    if-ge v3, v4, :cond_0

    .line 121
    invoke-virtual {v0, v3}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    .line 122
    .local v4, "commentObj":Lorg/json/JSONObject;
    const-string v5, "comment_id"

    const/4 v6, -0x1

    invoke-virtual {v4, v5, v6}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v5

    .line 123
    .local v5, "commentId":I
    const-string v7, "post_id"

    invoke-virtual {v4, v7, v6}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v6

    .line 124
    .local v6, "pId":I
    const-string v7, "username"

    const-string v8, "IdontKnowMyName;)"

    invoke-virtual {v4, v7, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 125
    .local v7, "commentUsername":Ljava/lang/String;
    const-string v8, "text_comment"

    const-string v9, ""

    invoke-virtual {v4, v8, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 126
    .local v8, "textComment":Ljava/lang/String;
    new-instance v9, Lcom/LinkaMaterialProject/linkaMaterial/Comment;

    invoke-direct {v9, v5, v6, v7, v8}, Lcom/LinkaMaterialProject/linkaMaterial/Comment;-><init>(IILjava/lang/String;Ljava/lang/String;)V

    .line 127
    .local v9, "comment":Lcom/LinkaMaterialProject/linkaMaterial/Comment;
    invoke-interface {v1, v9}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 120
    nop

    .end local v4    # "commentObj":Lorg/json/JSONObject;
    .end local v5    # "commentId":I
    .end local v6    # "pId":I
    .end local v7    # "commentUsername":Ljava/lang/String;
    .end local v8    # "textComment":Ljava/lang/String;
    .end local v9    # "comment":Lcom/LinkaMaterialProject/linkaMaterial/Comment;
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 132
    .end local v0    # "commentsArray":Lorg/json/JSONArray;
    .end local v2    # "rootObject":Lorg/json/JSONObject;
    .end local v3    # "i":I
    :cond_0
    goto :goto_1

    .line 130
    :catch_0
    move-exception v0

    .line 131
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 133
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_1
    return-object v1
.end method

.method public popularLista(Ljava/lang/String;)V
    .locals 3
    .param p1, "jsonResult"    # Ljava/lang/String;

    .line 136
    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->parseCommentsResponse(Ljava/lang/String;)Ljava/util/List;

    move-result-object v0

    .line 137
    .local v0, "comments":Ljava/util/List;, "Ljava/util/List<Lcom/LinkaMaterialProject/linkaMaterial/Comment;>;"
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter;

    invoke-direct {v1, p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter;-><init>(Landroid/content/Context;Ljava/util/List;)V

    .line 138
    .local v1, "adapter":Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter;
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->lvComments:Landroid/widget/ListView;

    invoke-virtual {v2, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 139
    return-void
.end method
