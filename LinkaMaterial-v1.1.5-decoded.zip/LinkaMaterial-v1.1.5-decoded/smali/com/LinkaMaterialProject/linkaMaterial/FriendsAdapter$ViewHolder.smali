.class Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter$ViewHolder;
.super Ljava/lang/Object;
.source "FriendsAdapter.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "ViewHolder"
.end annotation


# instance fields
.field txtName:Landroid/widget/TextView;

.field txtSubtitle:Landroid/widget/TextView;


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 44
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter-IA;)V
    .locals 0

    invoke-direct {p0}, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter$ViewHolder;-><init>()V

    return-void
.end method
