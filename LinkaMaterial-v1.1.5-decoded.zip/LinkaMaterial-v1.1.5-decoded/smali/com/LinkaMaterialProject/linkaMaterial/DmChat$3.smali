.class Lcom/LinkaMaterialProject/linkaMaterial/DmChat$3;
.super Ljava/lang/Object;
.source "DmChat.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    .line 90
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 93
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;Lcom/LinkaMaterialProject/linkaMaterial/DmChat-IA;)V

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Void;

    invoke-virtual {v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 94
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->-$$Nest$fgetautoUpdateHandler(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Landroid/os/Handler;

    move-result-object v0

    const-wide/16 v1, 0x7d0

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 95
    return-void
.end method
