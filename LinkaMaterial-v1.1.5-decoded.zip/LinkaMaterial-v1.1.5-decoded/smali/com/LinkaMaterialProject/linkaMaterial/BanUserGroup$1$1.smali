.class Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1$1;
.super Ljava/lang/Object;
.source "BanUserGroup.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;->onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;

.field final synthetic val$friendName:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$1"    # Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 69
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1$1;->val$friendName:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .line 73
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 74
    .local v0, "jsonRemove":Lorg/json/JSONObject;
    const-string v1, "username"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;

    iget-object v2, v2, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->-$$Nest$fgetmyUsername(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 75
    const-string v1, "group_id"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;

    iget-object v2, v2, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->-$$Nest$fgetgroupId(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 76
    const-string v1, "target_user"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1$1;->val$friendName:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 77
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;

    iget-object v2, v2, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/remove-user"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "post"

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;

    iget-object v3, v3, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    invoke-static {v1, v2, v0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 80
    nop

    .end local v0    # "jsonRemove":Lorg/json/JSONObject;
    goto :goto_0

    .line 78
    :catch_0
    move-exception v0

    .line 79
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 81
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    return-void
.end method
