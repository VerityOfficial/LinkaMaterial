.class public Lcom/LinkaMaterialProject/linkaMaterial/newChat;
.super Landroid/app/Activity;
.source "newChat.java"


# instance fields
.field private btnChat:Landroid/widget/ImageButton;

.field private btnEnterGroup:Landroid/widget/Button;

.field private btnExternalServer:Landroid/widget/Button;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnNewGroup:Landroid/widget/Button;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 20
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 2
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 29
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 30
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->activity_new_chat:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->setContentView(I)V

    .line 31
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnNewGroup:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->btnNewGroup:Landroid/widget/Button;

    .line 32
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnExternalServer:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->btnExternalServer:Landroid/widget/Button;

    .line 33
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->btnHome:Landroid/widget/ImageButton;

    .line 34
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->btnChat:Landroid/widget/ImageButton;

    .line 35
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->btnOptions:Landroid/widget/ImageButton;

    .line 36
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->btnProfile:Landroid/widget/ImageButton;

    .line 37
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnEnterGroup:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->btnEnterGroup:Landroid/widget/Button;

    .line 38
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->btnEnterGroup:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/newChat$1;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/newChat$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/newChat;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 45
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->btnNewGroup:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/newChat$2;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/newChat$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/newChat;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 52
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->btnExternalServer:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/newChat$3;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/newChat$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/newChat;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 59
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->btnHome:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/newChat$4;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/newChat$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/newChat;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 66
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->btnChat:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/newChat$5;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/newChat$5;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/newChat;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 73
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->btnOptions:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/newChat$6;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/newChat$6;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/newChat;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 80
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newChat;->btnProfile:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/newChat$7;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/newChat$7;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/newChat;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 87
    return-void
.end method
