.class public Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;
.super Landroid/app/Activity;
.source "GroupChatActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$SendMessageTask;,
        Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;
    }
.end annotation


# static fields
.field private static final TAG:Ljava/lang/String; = "MATERIAL_DEBUG"

.field private static final UPDATE_INTERVAL:I = 0x7d0


# instance fields
.field private autoUpdateHandler:Landroid/os/Handler;

.field private autoUpdateRunnable:Ljava/lang/Runnable;

.field private btnHeaderImage:Landroid/widget/ImageButton;

.field private btnSend:Landroid/widget/Button;

.field private chatContainer:Landroid/widget/LinearLayout;

.field private edtInputMessage:Landroid/widget/EditText;

.field private groupId:I

.field private txtHeaderTitle:Landroid/widget/TextView;

.field private url:Ljava/lang/String;

.field private username:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetautoUpdateHandler(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)Landroid/os/Handler;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->autoUpdateHandler:Landroid/os/Handler;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetchatContainer(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)Landroid/widget/LinearLayout;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->chatContainer:Landroid/widget/LinearLayout;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetedtInputMessage(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->edtInputMessage:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->url:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->username:Ljava/lang/String;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 1

    .line 21
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 28
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->username:Ljava/lang/String;

    .line 29
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->url:Ljava/lang/String;

    .line 30
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->autoUpdateHandler:Landroid/os/Handler;

    .line 32
    const/4 v0, -0x1

    iput v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->groupId:I

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 8
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 37
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 38
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->global_chat:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->setContentView(I)V

    .line 40
    const-string v0, "GroupChatActivity onCreate iniciado"

    const-string v1, "MATERIAL_DEBUG"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 43
    :try_start_0
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v0}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 44
    .local v0, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    const-string v2, "config.cfg"

    invoke-virtual {v0, p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 45
    .local v2, "rawCfg":Ljava/lang/String;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Config bruto lido: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 47
    if-eqz v2, :cond_1

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_1

    .line 48
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 49
    .local v3, "jsonCfg":Lorg/json/JSONObject;
    const-string v4, "FAST_LOGIN"

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    .line 50
    .local v4, "fastLogin":Lorg/json/JSONObject;
    const-string v5, "SERVER"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 52
    .local v5, "server":Lorg/json/JSONObject;
    const-string v6, ""

    if-eqz v4, :cond_0

    :try_start_1
    const-string v7, "username"

    invoke-virtual {v4, v7, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    iput-object v7, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->username:Ljava/lang/String;

    .line 53
    :cond_0
    if-eqz v5, :cond_1

    const-string v7, "url"

    invoke-virtual {v5, v7, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    iput-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->url:Ljava/lang/String;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 57
    .end local v0    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v2    # "rawCfg":Ljava/lang/String;
    .end local v3    # "jsonCfg":Lorg/json/JSONObject;
    .end local v4    # "fastLogin":Lorg/json/JSONObject;
    .end local v5    # "server":Lorg/json/JSONObject;
    :cond_1
    goto :goto_0

    .line 55
    :catch_0
    move-exception v0

    .line 56
    .local v0, "e":Ljava/lang/Exception;
    const-string v2, "Erro ao ler/processar config.cfg"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 59
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Config carregado -> Username: \'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->username:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "\' | URL: \'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->url:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 61
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHeaderImage:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->btnHeaderImage:Landroid/widget/ImageButton;

    .line 62
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->txtHeaderTitle:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->txtHeaderTitle:Landroid/widget/TextView;

    .line 63
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnSend:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->btnSend:Landroid/widget/Button;

    .line 64
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtInputMessage:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->edtInputMessage:Landroid/widget/EditText;

    .line 65
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->layoutMessagesContainer:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->chatContainer:Landroid/widget/LinearLayout;

    .line 67
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->btnSend:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$1;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 78
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->btnHeaderImage:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$2;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 86
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$3;

    invoke-direct {v0, p0}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)V

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->autoUpdateRunnable:Ljava/lang/Runnable;

    .line 93
    return-void
.end method

.method protected onPause()V
    .locals 2

    .line 104
    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    .line 105
    const-string v0, "MATERIAL_DEBUG"

    const-string v1, "onPause: parando polling de mensagens"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 106
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->autoUpdateHandler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->autoUpdateRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 107
    return-void
.end method

.method protected onResume()V
    .locals 2

    .line 97
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 98
    const-string v0, "MATERIAL_DEBUG"

    const-string v1, "onResume: iniciando polling de mensagens"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 99
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->autoUpdateHandler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->autoUpdateRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 100
    return-void
.end method
