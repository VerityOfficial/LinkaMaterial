.class public Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;
.super Landroid/app/Activity;
.source "EditAccount.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$UploadProfilePicTask;
    }
.end annotation


# static fields
.field private static final PICK_IMAGE_REQUEST:I = 0x3e9


# instance fields
.field private btnChangeBiography:Landroid/widget/Button;

.field private btnChangePicture:Landroid/widget/Button;

.field private btnChat:Landroid/widget/ImageButton;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;

.field private url:Ljava/lang/String;

.field private username:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->url:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mopenGallery(Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;)V
    .locals 0

    invoke-direct {p0}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->openGallery()V

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 14
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 22
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->url:Ljava/lang/String;

    .line 24
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->username:Ljava/lang/String;

    return-void
.end method

.method private openGallery()V
    .locals 3

    .line 93
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.GET_CONTENT"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 94
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "image/*"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 95
    const-string v1, "Select the profile picture"

    invoke-static {v0, v1}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    move-result-object v1

    const/16 v2, 0x3e9

    invoke-virtual {p0, v1, v2}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->startActivityForResult(Landroid/content/Intent;I)V

    .line 96
    return-void
.end method


# virtual methods
.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 4
    .param p1, "requestCode"    # I
    .param p2, "resultCode"    # I
    .param p3, "data"    # Landroid/content/Intent;

    .line 100
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    .line 102
    const/16 v0, 0x3e9

    if-ne p1, v0, :cond_0

    const/4 v0, -0x1

    if-ne p2, v0, :cond_0

    if-eqz p3, :cond_0

    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 103
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    .line 104
    .local v0, "selectedImageUri":Landroid/net/Uri;
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$UploadProfilePicTask;

    const/4 v2, 0x0

    invoke-direct {v1, p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$UploadProfilePicTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;Lcom/LinkaMaterialProject/linkaMaterial/EditAccount-IA;)V

    const/4 v2, 0x1

    new-array v2, v2, [Landroid/net/Uri;

    const/4 v3, 0x0

    aput-object v0, v2, v3

    invoke-virtual {v1, v2}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$UploadProfilePicTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 106
    .end local v0    # "selectedImageUri":Landroid/net/Uri;
    :cond_0
    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 6
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 27
    const-string v0, ""

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 28
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->edit_account_activity:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->setContentView(I)V

    .line 30
    :try_start_0
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v1}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 31
    .local v1, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v2, Lorg/json/JSONObject;

    const-string v3, "config.cfg"

    invoke-virtual {v1, p0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 32
    .local v2, "jsonCfg":Lorg/json/JSONObject;
    const-string v3, "FAST_LOGIN"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    .line 33
    .local v3, "fastLogin":Lorg/json/JSONObject;
    const-string v4, "SERVER"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    .line 34
    .local v4, "server":Lorg/json/JSONObject;
    const-string v5, "url"

    invoke-virtual {v4, v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->url:Ljava/lang/String;

    .line 35
    const-string v5, "username"

    invoke-virtual {v3, v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->username:Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 38
    .end local v1    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v2    # "jsonCfg":Lorg/json/JSONObject;
    .end local v3    # "fastLogin":Lorg/json/JSONObject;
    .end local v4    # "server":Lorg/json/JSONObject;
    goto :goto_0

    .line 36
    :catch_0
    move-exception v0

    .line 37
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 39
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChangeBiography:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->btnChangeBiography:Landroid/widget/Button;

    .line 40
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChangePicture:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->btnChangePicture:Landroid/widget/Button;

    .line 41
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->btnHome:Landroid/widget/ImageButton;

    .line 42
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->btnChat:Landroid/widget/ImageButton;

    .line 43
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->btnOptions:Landroid/widget/ImageButton;

    .line 44
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->btnProfile:Landroid/widget/ImageButton;

    .line 45
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->btnChangeBiography:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$1;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 52
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->btnChangePicture:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$2;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 59
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->btnHome:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$3;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 67
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->btnOptions:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$4;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 75
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->btnProfile:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$5;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$5;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 83
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->btnChat:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$6;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$6;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 90
    return-void
.end method
