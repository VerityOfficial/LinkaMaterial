.class public final synthetic Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
