.class Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$4;
.super Ljava/lang/Object;
.source "ChannelsGroupActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    .line 106
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$4;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 109
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$4;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    const-class v2, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 110
    .local v0, "intent":Landroid/content/Intent;
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$4;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->-$$Nest$fgetgroupId(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)I

    move-result v1

    const-string v2, "group_id"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 111
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$4;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->startActivity(Landroid/content/Intent;)V

    .line 112
    return-void
.end method
