.class public Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;
.super Landroid/app/Activity;
.source "NewGroupActivity.java"


# instance fields
.field private btnChat:Landroid/widget/ImageButton;

.field private btnCreate:Landroid/widget/Button;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;

.field private edtDescription:Landroid/widget/EditText;

.field private edtGroupName:Landroid/widget/EditText;

.field private url:Ljava/lang/String;

.field private username:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetedtDescription(Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->edtDescription:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetedtGroupName(Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->edtGroupName:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->url:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->username:Ljava/lang/String;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 1

    .line 21
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 29
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->username:Ljava/lang/String;

    .line 30
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->url:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 5
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 32
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 33
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->activity_new_group:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->setContentView(I)V

    .line 34
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->btnHome:Landroid/widget/ImageButton;

    .line 35
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->btnChat:Landroid/widget/ImageButton;

    .line 36
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->btnOptions:Landroid/widget/ImageButton;

    .line 37
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->btnProfile:Landroid/widget/ImageButton;

    .line 38
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtGroupName:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->edtGroupName:Landroid/widget/EditText;

    .line 39
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtDescription:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->edtDescription:Landroid/widget/EditText;

    .line 40
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnCreate:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->btnCreate:Landroid/widget/Button;

    .line 42
    :try_start_0
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v0}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 43
    .local v0, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v1, Lorg/json/JSONObject;

    const-string v2, "config.cfg"

    invoke-virtual {v0, p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 44
    .local v1, "jsonCfg":Lorg/json/JSONObject;
    const-string v2, "FAST_LOGIN"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    .line 45
    .local v2, "fastLogin":Lorg/json/JSONObject;
    const-string v3, "SERVER"

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    .line 46
    .local v3, "server":Lorg/json/JSONObject;
    const-string v4, "url"

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->url:Ljava/lang/String;

    .line 47
    const-string v4, "username"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->username:Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 50
    .end local v0    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v1    # "jsonCfg":Lorg/json/JSONObject;
    .end local v2    # "fastLogin":Lorg/json/JSONObject;
    .end local v3    # "server":Lorg/json/JSONObject;
    goto :goto_0

    .line 48
    :catch_0
    move-exception v0

    .line 49
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 51
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->btnCreate:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity$1;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 67
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->btnHome:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity$2;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 74
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->btnChat:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity$3;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 81
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->btnOptions:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity$4;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 88
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->btnProfile:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity$5;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity$5;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 95
    return-void
.end method
