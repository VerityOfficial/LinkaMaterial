.class public Lcom/LinkaMaterialProject/linkaMaterial/Member;
.super Ljava/lang/Object;
.source "Member.java"


# instance fields
.field private avatarImageView:Landroid/widget/ImageView;

.field private username:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Landroid/widget/ImageView;)V
    .locals 0
    .param p1, "username"    # Ljava/lang/String;
    .param p2, "avatarImageView"    # Landroid/widget/ImageView;

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/Member;->username:Ljava/lang/String;

    .line 11
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/Member;->avatarImageView:Landroid/widget/ImageView;

    .line 12
    return-void
.end method


# virtual methods
.method public getAvatarImageView()Landroid/widget/ImageView;
    .locals 1

    .line 23
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/Member;->avatarImageView:Landroid/widget/ImageView;

    return-object v0
.end method

.method public getUsername()Ljava/lang/String;
    .locals 1

    .line 15
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/Member;->username:Ljava/lang/String;

    return-object v0
.end method

.method public setAvatarImageView(Landroid/widget/ImageView;)V
    .locals 0
    .param p1, "avatarImageView"    # Landroid/widget/ImageView;

    .line 27
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/Member;->avatarImageView:Landroid/widget/ImageView;

    .line 28
    return-void
.end method

.method public setUsername(Ljava/lang/String;)V
    .locals 0
    .param p1, "username"    # Ljava/lang/String;

    .line 19
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/Member;->username:Ljava/lang/String;

    .line 20
    return-void
.end method
