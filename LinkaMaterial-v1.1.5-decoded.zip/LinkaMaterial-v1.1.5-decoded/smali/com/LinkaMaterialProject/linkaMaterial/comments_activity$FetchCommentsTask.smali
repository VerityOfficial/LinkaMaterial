.class Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$FetchCommentsTask;
.super Landroid/os/AsyncTask;
.source "comments_activity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "FetchCommentsTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/String;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;


# direct methods
.method private constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)V
    .locals 0

    .line 140
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$FetchCommentsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;Lcom/LinkaMaterialProject/linkaMaterial/comments_activity-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$FetchCommentsTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)V

    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 140
    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$FetchCommentsTask;->doInBackground([Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .param p1, "params"    # [Ljava/lang/String;

    .line 144
    const-string v0, "post_id"

    const/4 v1, 0x0

    :try_start_0
    aget-object v1, p1, v1

    .line 145
    .local v1, "targetPostId":Ljava/lang/String;
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 147
    .local v2, "jsonComment":Lorg/json/JSONObject;
    :try_start_1
    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 150
    goto :goto_0

    .line 148
    :catch_0
    move-exception v3

    .line 149
    .local v3, "e":Ljava/lang/NumberFormatException;
    :try_start_2
    invoke-virtual {v2, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 151
    .end local v3    # "e":Ljava/lang/NumberFormatException;
    :goto_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$FetchCommentsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->-$$Nest$fgetbaseUrl(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, "/view-comments"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v3, "post"

    invoke-static {v0, v3, v2}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    return-object v0

    .line 152
    .end local v1    # "targetPostId":Ljava/lang/String;
    .end local v2    # "jsonComment":Lorg/json/JSONObject;
    :catch_1
    move-exception v0

    .line 153
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 155
    .end local v0    # "e":Ljava/lang/Exception;
    const-string v0, ""

    return-object v0
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 140
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$FetchCommentsTask;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 3
    .param p1, "result"    # Ljava/lang/String;

    .line 159
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    .line 160
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$FetchCommentsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-virtual {v0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->popularLista(Ljava/lang/String;)V

    goto :goto_0

    .line 162
    :cond_0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$FetchCommentsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    const-string v1, "Erro ao carregar coment\u00e1rios"

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 164
    :goto_0
    return-void
.end method
