.class Lcom/LinkaMaterialProject/linkaMaterial/newPost$SendPostTask;
.super Landroid/os/AsyncTask;
.source "newPost.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/newPost;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "SendPostTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/String;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;


# direct methods
.method private constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/newPost;)V
    .locals 0

    .line 117
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$SendPostTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/newPost;Lcom/LinkaMaterialProject/linkaMaterial/newPost-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/newPost$SendPostTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/newPost;)V

    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 117
    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/newPost$SendPostTask;->doInBackground([Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/String;)Ljava/lang/String;
    .locals 13
    .param p1, "params"    # [Ljava/lang/String;

    .line 120
    const/4 v0, 0x0

    aget-object v1, p1, v0

    .line 122
    .local v1, "postTextValue":Ljava/lang/String;
    :try_start_0
    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v2}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 123
    .local v2, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$SendPostTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    const-string v4, "config.cfg"

    invoke-virtual {v2, v3, v4}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 124
    .local v3, "rawCfg":Ljava/lang/String;
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 125
    .local v4, "jsonCfg":Lorg/json/JSONObject;
    const-string v5, "FAST_LOGIN"

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    .line 126
    .local v5, "fastLogin":Lorg/json/JSONObject;
    const-string v6, "SERVER"

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v6
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 127
    .local v6, "server":Lorg/json/JSONObject;
    const-string v7, "http://linkaProject.pythonanywhere.com"

    if-eqz v6, :cond_0

    :try_start_1
    const-string v8, "url"

    invoke-virtual {v6, v8, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 128
    .local v7, "url":Ljava/lang/String;
    :cond_0
    const-string v8, "username"

    const-string v9, ""

    if-eqz v5, :cond_1

    :try_start_2
    invoke-virtual {v5, v8, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_0

    :cond_1
    move-object v10, v9

    .line 129
    .local v10, "username":Ljava/lang/String;
    :goto_0
    const-string v11, "token_session"

    if-eqz v5, :cond_2

    :try_start_3
    invoke-virtual {v5, v11, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 131
    .local v9, "token":Ljava/lang/String;
    :cond_2
    new-instance v12, Lorg/json/JSONObject;

    invoke-direct {v12}, Lorg/json/JSONObject;-><init>()V

    .line 132
    .local v12, "jsonResponse":Lorg/json/JSONObject;
    invoke-virtual {v12, v8, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 133
    invoke-virtual {v12, v11, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 134
    const-string v8, "text_post"

    invoke-virtual {v12, v8, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 135
    const-string v8, "datetime"

    invoke-static {}, Lcom/LinkaMaterialProject/linkaMaterial/TimeUtils;->getDateTime()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v12, v8, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 137
    const-string v8, "/"

    invoke-virtual {v7, v8}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_3

    .line 138
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    add-int/lit8 v8, v8, -0x1

    invoke-virtual {v7, v0, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    move-object v7, v0

    .line 140
    :cond_3
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v8, "/new"

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v8, "post"

    iget-object v11, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$SendPostTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    invoke-static {v0, v8, v12, v11}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    return-object v0

    .line 141
    .end local v2    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v3    # "rawCfg":Ljava/lang/String;
    .end local v4    # "jsonCfg":Lorg/json/JSONObject;
    .end local v5    # "fastLogin":Lorg/json/JSONObject;
    .end local v6    # "server":Lorg/json/JSONObject;
    .end local v7    # "url":Ljava/lang/String;
    .end local v9    # "token":Ljava/lang/String;
    .end local v10    # "username":Ljava/lang/String;
    .end local v12    # "jsonResponse":Lorg/json/JSONObject;
    :catch_0
    move-exception v0

    .line 142
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 144
    .end local v0    # "e":Ljava/lang/Exception;
    const/4 v0, 0x0

    return-object v0
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 117
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/newPost$SendPostTask;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 3
    .param p1, "result"    # Ljava/lang/String;

    .line 149
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$SendPostTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->-$$Nest$fgetbtnSend(Lcom/LinkaMaterialProject/linkaMaterial/newPost;)Landroid/widget/Button;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 150
    const/4 v0, 0x0

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_0

    .line 151
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$SendPostTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    const-string v2, "post was send!"

    invoke-static {v1, v2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 152
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$SendPostTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->finish()V

    goto :goto_0

    .line 154
    :cond_0
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$SendPostTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    const-string v2, "Error in post sending."

    invoke-static {v1, v2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 156
    :goto_0
    return-void
.end method
