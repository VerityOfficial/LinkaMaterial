.class Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1$1;
.super Ljava/lang/Object;
.source "LoginActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;

.field final synthetic val$finalPass:Ljava/lang/String;

.field final synthetic val$finalUser:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$1"    # Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 93
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1$1;->val$finalUser:Ljava/lang/String;

    iput-object p3, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1$1;->val$finalPass:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 96
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;

    iget-object v0, v0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1$1;->val$finalUser:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1$1;->val$finalPass:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    .line 97
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Executando Fast Login para: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1$1;->val$finalUser:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "LinkaMaterialLogin"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 98
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;

    iget-object v0, v0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1$1;->val$finalUser:Ljava/lang/String;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1$1;->val$finalPass:Ljava/lang/String;

    invoke-static {v0, v1, v2}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->-$$Nest$mexecuteLogin(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;Ljava/lang/String;Ljava/lang/String;)V

    .line 100
    :cond_0
    return-void
.end method
