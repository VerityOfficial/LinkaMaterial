.class Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$1;
.super Ljava/lang/Object;
.source "comments_activity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    .line 48
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 6
    .param p1, "v"    # Landroid/view/View;

    .line 51
    const-string v0, "post_id"

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->-$$Nest$fgetcommentEdt(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)Landroid/widget/EditText;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 53
    .local v1, "textComment":Ljava/lang/String;
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    if-eqz v2, :cond_4

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_0

    goto/16 :goto_3

    .line 57
    :cond_0
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->-$$Nest$fgetpostId(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_3

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->-$$Nest$fgetpostId(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_1

    goto :goto_2

    .line 61
    :cond_1
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_2

    .line 62
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    const-string v2, "Escreva um coment\u00e1rio!"

    invoke-static {v0, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 63
    return-void

    .line 66
    :cond_2
    :try_start_0
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 67
    .local v2, "commentJson":Lorg/json/JSONObject;
    const-string v4, "username"

    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-static {v5}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 68
    const-string v4, "text_comment"

    invoke-virtual {v2, v4, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_1

    .line 71
    :try_start_1
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->-$$Nest$fgetpostId(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v0, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_1

    .line 74
    goto :goto_0

    .line 72
    :catch_0
    move-exception v4

    .line 73
    .local v4, "e":Ljava/lang/NumberFormatException;
    :try_start_2
    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-static {v5}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->-$$Nest$fgetpostId(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v0, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 75
    .end local v4    # "e":Ljava/lang/NumberFormatException;
    :goto_0
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$SendCommentTask;

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    const/4 v5, 0x0

    invoke-direct {v0, v4, v5}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$SendCommentTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;Lcom/LinkaMaterialProject/linkaMaterial/comments_activity-IA;)V

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    new-array v5, v5, [Ljava/lang/String;

    aput-object v4, v5, v3

    invoke-virtual {v0, v5}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$SendCommentTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;
    :try_end_2
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_2} :catch_1

    .line 78
    nop

    .end local v2    # "commentJson":Lorg/json/JSONObject;
    goto :goto_1

    .line 76
    :catch_1
    move-exception v0

    .line 77
    .local v0, "e":Lorg/json/JSONException;
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    const-string v4, "Erro ao criar JSON"

    invoke-static {v2, v4, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 79
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_1
    return-void

    .line 58
    :cond_3
    :goto_2
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    const-string v2, "Erro: ID do Post inv\u00e1lido!"

    invoke-static {v0, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 59
    return-void

    .line 54
    :cond_4
    :goto_3
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    const-string v2, "Erro: Usu\u00e1rio n\u00e3o identificado!"

    invoke-static {v0, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 55
    return-void
.end method
