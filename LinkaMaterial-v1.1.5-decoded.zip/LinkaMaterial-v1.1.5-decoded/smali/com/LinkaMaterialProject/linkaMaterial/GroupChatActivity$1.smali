.class Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$1;
.super Ljava/lang/Object;
.source "GroupChatActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    .line 67
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 70
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->-$$Nest$fgetedtInputMessage(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 71
    .local v0, "textMessage":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_0

    .line 72
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->-$$Nest$fgetedtInputMessage(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)Landroid/widget/EditText;

    move-result-object v1

    const-string v2, ""

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 73
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$SendMessageTask;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-direct {v1, v2, v0}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$SendMessageTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;Ljava/lang/String;)V

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Void;

    invoke-virtual {v1, v2}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$SendMessageTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 75
    :cond_0
    return-void
.end method
