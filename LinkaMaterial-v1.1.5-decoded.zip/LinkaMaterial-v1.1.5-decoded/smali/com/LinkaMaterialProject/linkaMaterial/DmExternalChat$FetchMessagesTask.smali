.class Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;
.super Landroid/os/AsyncTask;
.source "DmExternalChat.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "FetchMessagesTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/Void;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;


# direct methods
.method private constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)V
    .locals 0

    .line 110
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)V

    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 110
    check-cast p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;->doInBackground([Ljava/lang/Void;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/Void;)Ljava/lang/String;
    .locals 11
    .param p1, "params"    # [Ljava/lang/Void;

    .line 114
    const-string v0, "post"

    :try_start_0
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->-$$Nest$fgetother_user(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "@"

    const-string v3, ""

    invoke-virtual {v1, v2, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 115
    .local v1, "cleanOtherUser":Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/send-request"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 116
    .local v2, "fullUrl":Ljava/lang/String;
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    .line 117
    .local v3, "jsonRequest":Lorg/json/JSONObject;
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4}, Lorg/json/JSONObject;-><init>()V

    .line 118
    .local v4, "json_chat":Lorg/json/JSONObject;
    const-string v5, "user1"

    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-static {v6}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 119
    const-string v5, "user2"

    invoke-virtual {v4, v5, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 120
    const-string v5, "id"

    const/4 v6, 0x0

    invoke-virtual {v4, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 121
    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-virtual {v5}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->getIntent()Landroid/content/Intent;

    move-result-object v5

    const-string v6, "urlDestiny"

    invoke-virtual {v5, v6}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 122
    .local v5, "urlDestiny":Ljava/lang/String;
    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-virtual {v6}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->getIntent()Landroid/content/Intent;

    move-result-object v6

    const-string v7, "destiny"

    invoke-virtual {v6, v7}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 123
    .local v6, "destiny":Ljava/lang/String;
    const-string v7, "url"

    invoke-virtual {v3, v7, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 124
    const-string v7, "route"

    const-string v8, "/send-message"

    invoke-virtual {v3, v7, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 125
    const-string v7, "method"

    invoke-virtual {v3, v7, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 126
    const-string v7, "payload"

    invoke-virtual {v3, v7, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 127
    new-instance v7, Lorg/json/JSONObject;

    invoke-direct {v7}, Lorg/json/JSONObject;-><init>()V

    .line 128
    .local v7, "jsonHeaders":Lorg/json/JSONObject;
    const-string v8, "Authorization"

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "Bearer "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    iget-object v10, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-static {v10}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->-$$Nest$fgettoken_session(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 129
    const-string v8, "headers"

    invoke-virtual {v3, v8, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 130
    iget-object v8, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-static {v2, v0, v3, v8}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    .line 131
    .local v0, "response":Ljava/lang/String;
    const-string v8, "MATERIAL_DEBUG"

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "[Fetch] Resposta do servidor: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v8, v9}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 132
    return-object v0

    .line 133
    .end local v0    # "response":Ljava/lang/String;
    .end local v1    # "cleanOtherUser":Ljava/lang/String;
    .end local v2    # "fullUrl":Ljava/lang/String;
    .end local v3    # "jsonRequest":Lorg/json/JSONObject;
    .end local v4    # "json_chat":Lorg/json/JSONObject;
    .end local v5    # "urlDestiny":Ljava/lang/String;
    .end local v6    # "destiny":Ljava/lang/String;
    .end local v7    # "jsonHeaders":Lorg/json/JSONObject;
    :catch_0
    move-exception v0

    .line 134
    .local v0, "e":Ljava/lang/Exception;
    const/4 v1, 0x0

    return-object v1
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 110
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 11
    .param p1, "response"    # Ljava/lang/String;

    .line 139
    const-string v0, ""

    const-string v1, "messages"

    if-eqz p1, :cond_4

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_4

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->-$$Nest$fgetchatContainer(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)Landroid/widget/LinearLayout;

    move-result-object v2

    if-nez v2, :cond_0

    goto/16 :goto_3

    .line 143
    :cond_0
    :try_start_0
    new-instance v2, Lorg/json/JSONObject;

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 144
    .local v2, "rootObject":Lorg/json/JSONObject;
    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_1

    .line 145
    return-void

    .line 147
    :cond_1
    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    .line 148
    .local v1, "messagesArray":Lorg/json/JSONArray;
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->-$$Nest$fgetchatContainer(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)Landroid/widget/LinearLayout;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 149
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_0
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v4

    if-ge v3, v4, :cond_3

    .line 150
    invoke-virtual {v1, v3}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    .line 151
    .local v4, "msgObj":Lorg/json/JSONObject;
    const-string v5, "message"

    invoke-virtual {v4, v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 152
    .local v5, "text":Ljava/lang/String;
    const-string v6, "sender"

    invoke-virtual {v4, v6, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 153
    .local v6, "sender":Ljava/lang/String;
    iget-object v7, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-static {v7}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v7

    .line 154
    .local v7, "isMe":Z
    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_2

    move-object v8, v5

    goto :goto_1

    :cond_2
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, ": "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    .line 155
    .local v8, "displayText":Ljava/lang/String;
    :goto_1
    new-instance v9, Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;

    iget-object v10, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-direct {v9, v10, v8, v7}, Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;-><init>(Landroid/content/Context;Ljava/lang/String;Z)V

    .line 156
    .local v9, "bubble":Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;
    iget-object v10, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-static {v10}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->-$$Nest$fgetchatContainer(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)Landroid/widget/LinearLayout;

    move-result-object v10

    invoke-virtual {v10, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 149
    .end local v4    # "msgObj":Lorg/json/JSONObject;
    .end local v5    # "text":Ljava/lang/String;
    .end local v6    # "sender":Ljava/lang/String;
    .end local v7    # "isMe":Z
    .end local v8    # "displayText":Ljava/lang/String;
    .end local v9    # "bubble":Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 160
    .end local v1    # "messagesArray":Lorg/json/JSONArray;
    .end local v2    # "rootObject":Lorg/json/JSONObject;
    .end local v3    # "i":I
    :cond_3
    goto :goto_2

    .line 158
    :catch_0
    move-exception v0

    .line 159
    .local v0, "e":Lorg/json/JSONException;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "[Fetch] Falha ao processar o JSON de resposta: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "MATERIAL_DEBUG"

    invoke-static {v2, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 161
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_2
    return-void

    .line 140
    :cond_4
    :goto_3
    return-void
.end method
