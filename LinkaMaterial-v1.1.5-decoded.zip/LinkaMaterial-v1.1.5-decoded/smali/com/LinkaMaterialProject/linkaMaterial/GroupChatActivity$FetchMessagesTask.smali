.class Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;
.super Landroid/os/AsyncTask;
.source "GroupChatActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "FetchMessagesTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/Void;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;


# direct methods
.method private constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)V
    .locals 0

    .line 109
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)V

    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 109
    check-cast p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;->doInBackground([Ljava/lang/Void;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/Void;)Ljava/lang/String;
    .locals 11
    .param p1, "params"    # [Ljava/lang/Void;

    .line 113
    const-string v0, "group_id"

    const-string v1, "channel"

    const-string v2, "MATERIAL_DEBUG"

    const/4 v3, 0x0

    :try_start_0
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_1

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_0

    goto/16 :goto_0

    .line 118
    :cond_0
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-static {v5}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "/view-group-message"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 119
    .local v4, "fullUrl":Ljava/lang/String;
    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-virtual {v5}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->getIntent()Landroid/content/Intent;

    move-result-object v5

    .line 120
    .local v5, "intent":Landroid/content/Intent;
    invoke-virtual {v5, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 121
    .local v6, "channel":Ljava/lang/String;
    const/4 v7, -0x1

    invoke-virtual {v5, v0, v7}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v7

    .line 123
    .local v7, "groupId":I
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "FetchMessagesTask -> URL: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, " | GroupID: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, " | Channel: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v2, v8}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 125
    new-instance v8, Lorg/json/JSONObject;

    invoke-direct {v8}, Lorg/json/JSONObject;-><init>()V

    .line 126
    .local v8, "jsonChat":Lorg/json/JSONObject;
    const-string v9, "id"

    const/4 v10, 0x0

    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 127
    invoke-virtual {v8, v1, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 128
    const-string v1, "username"

    iget-object v9, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-static {v9}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v1, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 129
    invoke-virtual {v8, v0, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 131
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "FetchMessagesTask enviando JSON: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v8}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 133
    const-string v0, "post"

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-static {v4, v0, v8, v1}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    .line 134
    .local v0, "response":Ljava/lang/String;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "FetchMessagesTask resposta bruta: "

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 135
    return-object v0

    .line 114
    .end local v0    # "response":Ljava/lang/String;
    .end local v4    # "fullUrl":Ljava/lang/String;
    .end local v5    # "intent":Landroid/content/Intent;
    .end local v6    # "channel":Ljava/lang/String;
    .end local v7    # "groupId":I
    .end local v8    # "jsonChat":Lorg/json/JSONObject;
    :cond_1
    :goto_0
    const-string v0, "FetchMessagesTask abortado: URL esta VAZIA ou NULA!"

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 115
    return-object v3

    .line 137
    :catch_0
    move-exception v0

    .line 138
    .local v0, "e":Ljava/lang/Exception;
    const-string v1, "Excecao dentro de FetchMessagesTask doInBackground"

    invoke-static {v2, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 139
    return-object v3
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 109
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 14
    .param p1, "response"    # Ljava/lang/String;

    .line 145
    const-string v0, ""

    const-string v1, "messages"

    const-string v2, "MATERIAL_DEBUG"

    if-eqz p1, :cond_4

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_0

    goto/16 :goto_4

    .line 151
    :cond_0
    :try_start_0
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 153
    .local v3, "rootJson":Lorg/json/JSONObject;
    invoke-virtual {v3, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_3

    .line 154
    invoke-virtual {v3, v1}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    .line 155
    .local v1, "jsonArray":Lorg/json/JSONArray;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Mensagens recebidas: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " item(ns)"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 157
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->-$$Nest$fgetchatContainer(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)Landroid/widget/LinearLayout;

    move-result-object v4

    invoke-virtual {v4}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 159
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_0
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v5

    if-ge v4, v5, :cond_2

    .line 160
    invoke-virtual {v1, v4}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v5

    .line 161
    .local v5, "obj":Lorg/json/JSONObject;
    const-string v6, "message"

    invoke-virtual {v5, v6, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 162
    .local v6, "text":Ljava/lang/String;
    const-string v7, "sender"

    invoke-virtual {v5, v7, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 164
    .local v7, "sender":Ljava/lang/String;
    iget-object v8, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-static {v8}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v8

    .line 165
    .local v8, "isMe":Z
    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_1

    move-object v9, v6

    goto :goto_1

    :cond_1
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, ": "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    .line 167
    .local v9, "displayText":Ljava/lang/String;
    :goto_1
    new-instance v10, Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;

    iget-object v11, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-direct {v10, v11, v9, v8}, Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;-><init>(Landroid/content/Context;Ljava/lang/String;Z)V

    .line 169
    .local v10, "bubble":Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v12, -0x1

    const/4 v13, -0x2

    invoke-direct {v11, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 173
    .local v11, "params":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v12, 0x6

    const/4 v13, 0x0

    invoke-virtual {v11, v13, v12, v13, v12}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 174
    invoke-virtual {v10, v11}, Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 176
    iget-object v12, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-static {v12}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->-$$Nest$fgetchatContainer(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)Landroid/widget/LinearLayout;

    move-result-object v12

    invoke-virtual {v12, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 159
    .end local v5    # "obj":Lorg/json/JSONObject;
    .end local v6    # "text":Ljava/lang/String;
    .end local v7    # "sender":Ljava/lang/String;
    .end local v8    # "isMe":Z
    .end local v9    # "displayText":Ljava/lang/String;
    .end local v10    # "bubble":Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;
    .end local v11    # "params":Landroid/widget/LinearLayout$LayoutParams;
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 178
    .end local v1    # "jsonArray":Lorg/json/JSONArray;
    .end local v4    # "i":I
    :cond_2
    goto :goto_2

    .line 179
    :cond_3
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "JSON do servidor nao contem a chave \'messages\'. Resposta: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 183
    .end local v3    # "rootJson":Lorg/json/JSONObject;
    :goto_2
    goto :goto_3

    .line 181
    :catch_0
    move-exception v0

    .line 182
    .local v0, "e":Lorg/json/JSONException;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Erro de JSON ao processar resposta do servidor. Resposta foi: "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 184
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_3
    return-void

    .line 146
    :cond_4
    :goto_4
    const-string v0, "FetchMessagesTask onPostExecute: Resposta veio NULA ou VAZIA do servidor."

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 147
    return-void
.end method
