.class Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$3;
.super Ljava/lang/Object;
.source "ConfigGroup.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;

    .line 73
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 77
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 78
    .local v0, "jsonExit":Lorg/json/JSONObject;
    const-string v1, "username"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 79
    const-string v1, "group_id"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->-$$Nest$fgetgroupId(Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;)I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 80
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/exit-group"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "post"

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;

    invoke-static {v1, v2, v0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    .line 81
    new-instance v1, Landroid/content/Intent;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;

    const-class v3, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 82
    .local v1, "intent":Landroid/content/Intent;
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;

    invoke-virtual {v2, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 85
    .end local v0    # "jsonExit":Lorg/json/JSONObject;
    .end local v1    # "intent":Landroid/content/Intent;
    goto :goto_0

    .line 83
    :catch_0
    move-exception v0

    .line 84
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 86
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    return-void
.end method
