.class public Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;
.super Landroid/app/Activity;
.source "AddGroupMember.java"


# instance fields
.field private adapter:Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;

.field private btnChat:Landroid/widget/ImageButton;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;

.field private friendsList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;",
            ">;"
        }
    .end annotation
.end field

.field private lvFriends:Landroid/widget/ListView;

.field private myUsername:Ljava/lang/String;

.field private url:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetfriendsList(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;)Ljava/util/List;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->friendsList:Ljava/util/List;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmyUsername(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->myUsername:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->url:Ljava/lang/String;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 1

    .line 15
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 23
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->url:Ljava/lang/String;

    .line 24
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->myUsername:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 9
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 27
    const-string v0, "friends"

    const-string v1, "username"

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 28
    sget v2, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->activity_chat:I

    invoke-virtual {p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->setContentView(I)V

    .line 29
    sget v2, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageButton;

    iput-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->btnHome:Landroid/widget/ImageButton;

    .line 30
    sget v2, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageButton;

    iput-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->btnChat:Landroid/widget/ImageButton;

    .line 31
    sget v2, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageButton;

    iput-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->btnOptions:Landroid/widget/ImageButton;

    .line 32
    sget v2, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageButton;

    iput-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->btnProfile:Landroid/widget/ImageButton;

    .line 33
    sget v2, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->lvFriends:I

    invoke-virtual {p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ListView;

    iput-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->lvFriends:Landroid/widget/ListView;

    .line 34
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->friendsList:Ljava/util/List;

    .line 36
    :try_start_0
    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v2}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 37
    .local v2, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v3, Lorg/json/JSONObject;

    const-string v4, "config.cfg"

    invoke-virtual {v2, p0, v4}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 38
    .local v3, "jsonCfg":Lorg/json/JSONObject;
    const-string v4, "FAST_LOGIN"

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    .line 39
    .local v4, "fastLogin":Lorg/json/JSONObject;
    const-string v5, "SERVER"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    .line 40
    .local v5, "server":Lorg/json/JSONObject;
    const-string v6, "url"

    invoke-virtual {v5, v6}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    iput-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->url:Ljava/lang/String;

    .line 41
    invoke-virtual {v4, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    iput-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->myUsername:Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 44
    .end local v2    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v3    # "jsonCfg":Lorg/json/JSONObject;
    .end local v4    # "fastLogin":Lorg/json/JSONObject;
    .end local v5    # "server":Lorg/json/JSONObject;
    goto :goto_0

    .line 42
    :catch_0
    move-exception v2

    .line 43
    .local v2, "e":Lorg/json/JSONException;
    invoke-virtual {v2}, Lorg/json/JSONException;->printStackTrace()V

    .line 46
    .end local v2    # "e":Lorg/json/JSONException;
    :goto_0
    :try_start_1
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 47
    .local v2, "jsonPayload":Lorg/json/JSONObject;
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->myUsername:Ljava/lang/String;

    invoke-virtual {v2, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 48
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->url:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, "/friends"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v3, "post"

    invoke-static {v1, v3, v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    .line 49
    .local v1, "response":Ljava/lang/String;
    if-eqz v1, :cond_1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    const-string v4, ""

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1

    .line 50
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 51
    .local v3, "jsonFriendsObj":Lorg/json/JSONObject;
    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1

    .line 52
    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    .line 53
    .local v0, "friends":Lorg/json/JSONArray;
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_1
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v5

    if-ge v4, v5, :cond_1

    .line 54
    invoke-virtual {v0, v4}, Lorg/json/JSONArray;->getJSONArray(I)Lorg/json/JSONArray;

    move-result-object v5

    .line 55
    .local v5, "pair":Lorg/json/JSONArray;
    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v7

    iget-object v8, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->myUsername:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_0

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v6

    goto :goto_2

    :cond_0
    invoke-virtual {v5, v6}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v6

    .line 56
    .local v6, "friend":Ljava/lang/String;
    :goto_2
    iget-object v7, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->friendsList:Ljava/util/List;

    new-instance v8, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;

    invoke-direct {v8, v6}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;-><init>(Ljava/lang/String;)V

    invoke-interface {v7, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_1

    .line 53
    nop

    .end local v5    # "pair":Lorg/json/JSONArray;
    .end local v6    # "friend":Ljava/lang/String;
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    .line 62
    .end local v0    # "friends":Lorg/json/JSONArray;
    .end local v1    # "response":Ljava/lang/String;
    .end local v2    # "jsonPayload":Lorg/json/JSONObject;
    .end local v3    # "jsonFriendsObj":Lorg/json/JSONObject;
    .end local v4    # "i":I
    :cond_1
    goto :goto_3

    .line 60
    :catch_1
    move-exception v0

    .line 61
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 63
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_3
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->friendsList:Ljava/util/List;

    invoke-direct {v0, p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;-><init>(Landroid/content/Context;Ljava/util/List;)V

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->adapter:Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;

    .line 64
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->lvFriends:Landroid/widget/ListView;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->adapter:Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 65
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->lvFriends:Landroid/widget/ListView;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$1;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 95
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->btnHome:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$2;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 102
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->btnOptions:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$3;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 109
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->btnProfile:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$4;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 116
    return-void
.end method
