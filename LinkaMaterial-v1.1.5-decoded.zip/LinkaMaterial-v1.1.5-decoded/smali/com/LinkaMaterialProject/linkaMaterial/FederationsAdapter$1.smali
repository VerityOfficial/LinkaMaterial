.class Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$1;
.super Ljava/lang/Object;
.source "FederationsAdapter.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;->getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;

.field final synthetic val$item:Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 64
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$1;->val$item:Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 67
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$1;->val$item:Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;->getUrl()Ljava/lang/String;

    move-result-object v0

    .line 68
    .local v0, "link":Ljava/lang/String;
    const-string v1, "http://"

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "https://"

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    .line 73
    :cond_0
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;->-$$Nest$fgetcontext(Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;)Landroid/content/Context;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "URL: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    invoke-static {v1, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    goto :goto_1

    .line 69
    :cond_1
    :goto_0
    new-instance v1, Landroid/content/Intent;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const-class v3, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 70
    .local v1, "intent":Landroid/content/Intent;
    const-string v2, "url"

    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 71
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 72
    .end local v1    # "intent":Landroid/content/Intent;
    nop

    .line 75
    :goto_1
    return-void
.end method
