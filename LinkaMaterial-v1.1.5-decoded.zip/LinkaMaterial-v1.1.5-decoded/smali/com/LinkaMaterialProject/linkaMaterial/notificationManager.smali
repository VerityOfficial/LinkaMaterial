.class public Lcom/LinkaMaterialProject/linkaMaterial/notificationManager;
.super Ljava/lang/Object;
.source "notificationManager.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static createNotification(Landroid/content/Context;)V
    .locals 36
    .param p0, "context"    # Landroid/content/Context;

    .line 13
    move-object/from16 v1, p0

    const-string v2, "post"

    const-string v0, "username"

    const-string v3, ""

    .line 14
    .local v3, "url":Ljava/lang/String;
    const-string v4, ""

    .line 16
    .local v4, "username":Ljava/lang/String;
    :try_start_0
    new-instance v5, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v5}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 17
    .local v5, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v6, Lorg/json/JSONObject;

    const-string v7, "config.cfg"

    invoke-virtual {v5, v1, v7}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 18
    .local v6, "jsonCfg":Lorg/json/JSONObject;
    const-string v7, "SERVER"

    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v7

    .line 19
    .local v7, "server":Lorg/json/JSONObject;
    const-string v8, "FAST_LOGIN"

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v8

    .line 20
    .local v8, "fastLogin":Lorg/json/JSONObject;
    const-string v9, "url"

    invoke-virtual {v7, v9}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_c
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_b

    move-object v3, v9

    .line 21
    :try_start_1
    invoke-virtual {v8, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_a
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_9

    move-object v4, v9

    .line 22
    :try_start_2
    new-instance v9, Lorg/json/JSONObject;

    invoke-direct {v9}, Lorg/json/JSONObject;-><init>()V

    .line 23
    .local v9, "jsonNotifications":Lorg/json/JSONObject;
    invoke-virtual {v9, v0, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 24
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v10, "/notifications"

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2, v9, v1}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    move-object v10, v0

    .line 26
    .local v10, "responseRaw":Ljava/lang/String;
    invoke-static {v10}, Lcom/LinkaMaterialProject/linkaMaterial/notificationsParser;->parseJson(Ljava/lang/String;)Ljava/util/List;

    move-result-object v0

    move-object v11, v0

    .line 27
    .local v11, "notifications":Ljava/util/List;, "Ljava/util/List<Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;>;"
    const-string v0, "notification"

    move-object v12, v0

    .line 28
    .local v12, "ns":Ljava/lang/String;
    invoke-virtual {v1, v12}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    move-object v13, v0

    .line 29
    .local v13, "navManager":Landroid/app/NotificationManager;
    invoke-interface {v11}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v14

    :goto_0
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;

    move-object v15, v0

    .line 30
    .local v15, "msg":Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;
    invoke-virtual {v15}, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;->getId()I

    move-result v0

    move/from16 v16, v0

    .line 31
    .local v16, "id":I
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    move-object/from16 v17, v0

    .line 32
    .local v17, "jsonRead":Lorg/json/JSONObject;
    const-string v0, "id"
    :try_end_2
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_2} :catch_8
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_7

    move-object/from16 v18, v4

    move/from16 v4, v16

    move-object/from16 v16, v5

    move-object/from16 v5, v17

    .end local v17    # "jsonRead":Lorg/json/JSONObject;
    .local v4, "id":I
    .local v5, "jsonRead":Lorg/json/JSONObject;
    .local v16, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .local v18, "username":Ljava/lang/String;
    :try_start_3
    invoke-virtual {v5, v0, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 33
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0
    :try_end_3
    .catch Lorg/json/JSONException; {:try_start_3 .. :try_end_3} :catch_6
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_5

    move-object/from16 v17, v3

    .end local v3    # "url":Ljava/lang/String;
    .local v17, "url":Ljava/lang/String;
    :try_start_4
    const-string v3, "/set-read-notification"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2, v5, v1}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    .line 34
    invoke-virtual {v15}, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;->getFromUser()Ljava/lang/String;

    move-result-object v0

    move-object v3, v0

    .line 35
    .local v3, "fromUser":Ljava/lang/String;
    invoke-virtual {v15}, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;->getContent()Ljava/lang/String;

    move-result-object v0

    move-object/from16 v19, v0

    .line 36
    .local v19, "content":Ljava/lang/String;
    move-object/from16 v20, v2

    const v2, 0x1080077

    .line 37
    .local v2, "icon":I
    move-object/from16 v21, v19

    .line 38
    .local v21, "tickerText":Ljava/lang/CharSequence;
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v22

    move-wide/from16 v24, v22

    .line 39
    .local v24, "when":J
    new-instance v0, Landroid/app/Notification;

    move-object/from16 v22, v3

    move-object/from16 v23, v5

    move-object/from16 v3, v21

    move-object/from16 v21, v6

    move-wide/from16 v5, v24

    .end local v6    # "jsonCfg":Lorg/json/JSONObject;
    .end local v24    # "when":J
    .local v3, "tickerText":Ljava/lang/CharSequence;
    .local v5, "when":J
    .local v21, "jsonCfg":Lorg/json/JSONObject;
    .local v22, "fromUser":Ljava/lang/String;
    .local v23, "jsonRead":Lorg/json/JSONObject;
    invoke-direct {v0, v2, v3, v5, v6}, Landroid/app/Notification;-><init>(ILjava/lang/CharSequence;J)V

    move-object/from16 v24, v0

    .line 40
    .local v24, "notification":Landroid/app/Notification;
    move-object/from16 v25, v19

    .line 41
    .local v25, "contentTitle":Ljava/lang/CharSequence;
    move-object/from16 v26, v19

    .line 42
    .local v26, "contentText":Ljava/lang/CharSequence;
    new-instance v0, Landroid/content/Intent;

    move/from16 v27, v2

    .end local v2    # "icon":I
    .local v27, "icon":I
    const-class v2, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    move-object v2, v0

    .line 43
    .local v2, "notificationIntent":Landroid/content/Intent;
    const/high16 v0, 0x8000000

    invoke-static {v1, v4, v2, v0}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v0
    :try_end_4
    .catch Lorg/json/JSONException; {:try_start_4 .. :try_end_4} :catch_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3

    move-object/from16 v28, v0

    .line 50
    .local v28, "contentIntent":Landroid/app/PendingIntent;
    const/16 v29, 0x2

    const/16 v30, 0x1

    :try_start_5
    const-class v0, Landroid/app/Notification;

    const-string v1, "setLatestEventInfo"
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_2
    .catch Lorg/json/JSONException; {:try_start_5 .. :try_end_5} :catch_4

    move-object/from16 v31, v2

    .end local v2    # "notificationIntent":Landroid/content/Intent;
    .local v31, "notificationIntent":Landroid/content/Intent;
    const/4 v2, 0x4

    move-object/from16 v32, v3

    .end local v3    # "tickerText":Ljava/lang/CharSequence;
    .local v32, "tickerText":Ljava/lang/CharSequence;
    :try_start_6
    new-array v3, v2, [Ljava/lang/Class;

    const-class v33, Landroid/content/Context;

    const/16 v34, 0x0

    aput-object v33, v3, v34

    const-class v33, Ljava/lang/CharSequence;

    aput-object v33, v3, v30

    const-class v33, Ljava/lang/CharSequence;

    aput-object v33, v3, v29

    const-class v33, Landroid/app/PendingIntent;

    const/16 v35, 0x3

    aput-object v33, v3, v35

    invoke-virtual {v0, v1, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    .line 53
    .local v0, "setLatestEventInfo":Ljava/lang/reflect/Method;
    new-array v1, v2, [Ljava/lang/Object;

    aput-object p0, v1, v34

    aput-object v25, v1, v30

    aput-object v26, v1, v29

    aput-object v28, v1, v35
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1
    .catch Lorg/json/JSONException; {:try_start_6 .. :try_end_6} :catch_4

    move-object/from16 v2, v24

    .end local v24    # "notification":Landroid/app/Notification;
    .local v2, "notification":Landroid/app/Notification;
    :try_start_7
    invoke-virtual {v0, v2, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_0
    .catch Lorg/json/JSONException; {:try_start_7 .. :try_end_7} :catch_4

    .line 56
    .end local v0    # "setLatestEventInfo":Ljava/lang/reflect/Method;
    goto :goto_2

    .line 54
    :catch_0
    move-exception v0

    goto :goto_1

    .end local v2    # "notification":Landroid/app/Notification;
    .restart local v24    # "notification":Landroid/app/Notification;
    :catch_1
    move-exception v0

    move-object/from16 v2, v24

    .end local v24    # "notification":Landroid/app/Notification;
    .restart local v2    # "notification":Landroid/app/Notification;
    goto :goto_1

    .end local v31    # "notificationIntent":Landroid/content/Intent;
    .end local v32    # "tickerText":Ljava/lang/CharSequence;
    .local v2, "notificationIntent":Landroid/content/Intent;
    .restart local v3    # "tickerText":Ljava/lang/CharSequence;
    .restart local v24    # "notification":Landroid/app/Notification;
    :catch_2
    move-exception v0

    move-object/from16 v31, v2

    move-object/from16 v32, v3

    move-object/from16 v2, v24

    .line 55
    .end local v3    # "tickerText":Ljava/lang/CharSequence;
    .end local v24    # "notification":Landroid/app/Notification;
    .local v0, "e":Ljava/lang/Exception;
    .local v2, "notification":Landroid/app/Notification;
    .restart local v31    # "notificationIntent":Landroid/content/Intent;
    .restart local v32    # "tickerText":Ljava/lang/CharSequence;
    :goto_1
    :try_start_8
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 57
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_2
    iget v0, v2, Landroid/app/Notification;->defaults:I

    or-int/lit8 v0, v0, 0x1

    iput v0, v2, Landroid/app/Notification;->defaults:I

    .line 58
    iget v0, v2, Landroid/app/Notification;->defaults:I

    or-int/lit8 v0, v0, 0x2

    iput v0, v2, Landroid/app/Notification;->defaults:I

    .line 60
    if-lez v4, :cond_0

    move v1, v4

    goto :goto_3

    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const-wide/16 v29, 0x2710

    rem-long v0, v0, v29

    long-to-int v1, v0

    .line 61
    .local v1, "notifyId":I
    :goto_3
    invoke-virtual {v13, v1, v2}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V
    :try_end_8
    .catch Lorg/json/JSONException; {:try_start_8 .. :try_end_8} :catch_4
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_3

    .line 62
    .end local v1    # "notifyId":I
    .end local v2    # "notification":Landroid/app/Notification;
    .end local v4    # "id":I
    .end local v5    # "when":J
    .end local v15    # "msg":Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;
    .end local v19    # "content":Ljava/lang/String;
    .end local v22    # "fromUser":Ljava/lang/String;
    .end local v23    # "jsonRead":Lorg/json/JSONObject;
    .end local v25    # "contentTitle":Ljava/lang/CharSequence;
    .end local v26    # "contentText":Ljava/lang/CharSequence;
    .end local v27    # "icon":I
    .end local v28    # "contentIntent":Landroid/app/PendingIntent;
    .end local v31    # "notificationIntent":Landroid/content/Intent;
    .end local v32    # "tickerText":Ljava/lang/CharSequence;
    move-object/from16 v1, p0

    move-object/from16 v5, v16

    move-object/from16 v3, v17

    move-object/from16 v4, v18

    move-object/from16 v2, v20

    move-object/from16 v6, v21

    goto/16 :goto_0

    .line 65
    .end local v7    # "server":Lorg/json/JSONObject;
    .end local v8    # "fastLogin":Lorg/json/JSONObject;
    .end local v9    # "jsonNotifications":Lorg/json/JSONObject;
    .end local v10    # "responseRaw":Ljava/lang/String;
    .end local v11    # "notifications":Ljava/util/List;, "Ljava/util/List<Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;>;"
    .end local v12    # "ns":Ljava/lang/String;
    .end local v13    # "navManager":Landroid/app/NotificationManager;
    .end local v16    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v21    # "jsonCfg":Lorg/json/JSONObject;
    :catch_3
    move-exception v0

    move-object/from16 v3, v17

    move-object/from16 v4, v18

    goto :goto_4

    .line 63
    :catch_4
    move-exception v0

    move-object/from16 v3, v17

    move-object/from16 v4, v18

    goto :goto_5

    .line 65
    .end local v17    # "url":Ljava/lang/String;
    .local v3, "url":Ljava/lang/String;
    :catch_5
    move-exception v0

    move-object/from16 v17, v3

    move-object/from16 v4, v18

    .end local v3    # "url":Ljava/lang/String;
    .restart local v17    # "url":Ljava/lang/String;
    goto :goto_4

    .line 63
    .end local v17    # "url":Ljava/lang/String;
    .restart local v3    # "url":Ljava/lang/String;
    :catch_6
    move-exception v0

    move-object/from16 v17, v3

    move-object/from16 v4, v18

    .end local v3    # "url":Ljava/lang/String;
    .restart local v17    # "url":Ljava/lang/String;
    goto :goto_5

    .line 29
    .end local v17    # "url":Ljava/lang/String;
    .end local v18    # "username":Ljava/lang/String;
    .restart local v3    # "url":Ljava/lang/String;
    .local v4, "username":Ljava/lang/String;
    .local v5, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .restart local v6    # "jsonCfg":Lorg/json/JSONObject;
    .restart local v7    # "server":Lorg/json/JSONObject;
    .restart local v8    # "fastLogin":Lorg/json/JSONObject;
    .restart local v9    # "jsonNotifications":Lorg/json/JSONObject;
    .restart local v10    # "responseRaw":Ljava/lang/String;
    .restart local v11    # "notifications":Ljava/util/List;, "Ljava/util/List<Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;>;"
    .restart local v12    # "ns":Ljava/lang/String;
    .restart local v13    # "navManager":Landroid/app/NotificationManager;
    :cond_1
    move-object/from16 v17, v3

    move-object/from16 v18, v4

    move-object/from16 v16, v5

    move-object/from16 v21, v6

    .line 67
    .end local v3    # "url":Ljava/lang/String;
    .end local v4    # "username":Ljava/lang/String;
    .end local v5    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v6    # "jsonCfg":Lorg/json/JSONObject;
    .end local v7    # "server":Lorg/json/JSONObject;
    .end local v8    # "fastLogin":Lorg/json/JSONObject;
    .end local v9    # "jsonNotifications":Lorg/json/JSONObject;
    .end local v10    # "responseRaw":Ljava/lang/String;
    .end local v11    # "notifications":Ljava/util/List;, "Ljava/util/List<Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;>;"
    .end local v12    # "ns":Ljava/lang/String;
    .end local v13    # "navManager":Landroid/app/NotificationManager;
    .restart local v17    # "url":Ljava/lang/String;
    .restart local v18    # "username":Ljava/lang/String;
    goto :goto_6

    .line 65
    .end local v17    # "url":Ljava/lang/String;
    .end local v18    # "username":Ljava/lang/String;
    .restart local v3    # "url":Ljava/lang/String;
    .restart local v4    # "username":Ljava/lang/String;
    :catch_7
    move-exception v0

    move-object/from16 v17, v3

    move-object/from16 v18, v4

    .end local v3    # "url":Ljava/lang/String;
    .end local v4    # "username":Ljava/lang/String;
    .restart local v17    # "url":Ljava/lang/String;
    .restart local v18    # "username":Ljava/lang/String;
    goto :goto_4

    .line 63
    .end local v17    # "url":Ljava/lang/String;
    .end local v18    # "username":Ljava/lang/String;
    .restart local v3    # "url":Ljava/lang/String;
    .restart local v4    # "username":Ljava/lang/String;
    :catch_8
    move-exception v0

    move-object/from16 v17, v3

    move-object/from16 v18, v4

    .end local v3    # "url":Ljava/lang/String;
    .end local v4    # "username":Ljava/lang/String;
    .restart local v17    # "url":Ljava/lang/String;
    .restart local v18    # "username":Ljava/lang/String;
    goto :goto_5

    .line 65
    .end local v17    # "url":Ljava/lang/String;
    .end local v18    # "username":Ljava/lang/String;
    .restart local v3    # "url":Ljava/lang/String;
    .restart local v4    # "username":Ljava/lang/String;
    :catch_9
    move-exception v0

    move-object/from16 v17, v3

    .end local v3    # "url":Ljava/lang/String;
    .restart local v17    # "url":Ljava/lang/String;
    goto :goto_4

    .line 63
    .end local v17    # "url":Ljava/lang/String;
    .restart local v3    # "url":Ljava/lang/String;
    :catch_a
    move-exception v0

    move-object/from16 v17, v3

    .end local v3    # "url":Ljava/lang/String;
    .restart local v17    # "url":Ljava/lang/String;
    goto :goto_5

    .line 65
    .end local v17    # "url":Ljava/lang/String;
    .restart local v3    # "url":Ljava/lang/String;
    :catch_b
    move-exception v0

    .line 66
    .restart local v0    # "e":Ljava/lang/Exception;
    :goto_4
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_6

    .line 63
    .end local v0    # "e":Ljava/lang/Exception;
    :catch_c
    move-exception v0

    .line 64
    .local v0, "e":Lorg/json/JSONException;
    :goto_5
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 67
    .end local v0    # "e":Lorg/json/JSONException;
    nop

    .line 68
    :goto_6
    return-void
.end method
