.class public Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;
.super Landroid/widget/BaseAdapter;
.source "ChannelAdapter.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter$ViewHolder;
    }
.end annotation


# instance fields
.field private channelList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/Channel;",
            ">;"
        }
    .end annotation
.end field

.field private context:Landroid/content/Context;

.field private inflater:Landroid/view/LayoutInflater;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/util/List;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/Channel;",
            ">;)V"
        }
    .end annotation

    .line 13
    .local p2, "channelList":Ljava/util/List;, "Ljava/util/List<Lcom/LinkaMaterialProject/linkaMaterial/Channel;>;"
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 14
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;->context:Landroid/content/Context;

    .line 15
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;->channelList:Ljava/util/List;

    .line 16
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;->inflater:Landroid/view/LayoutInflater;

    .line 17
    return-void
.end method


# virtual methods
.method public getCount()I
    .locals 1

    .line 20
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;->channelList:Ljava/util/List;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;->channelList:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .locals 1
    .param p1, "position"    # I

    .line 24
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;->channelList:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public getItemId(I)J
    .locals 2
    .param p1, "position"    # I

    .line 28
    int-to-long v0, p1

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 5
    .param p1, "position"    # I
    .param p2, "convertView"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 37
    if-nez p2, :cond_0

    .line 38
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;->inflater:Landroid/view/LayoutInflater;

    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->item_channel:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    .line 39
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter$ViewHolder;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter$ViewHolder;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter-IA;)V

    .line 40
    .local v0, "holder":Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter$ViewHolder;
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->txtChannelName:I

    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, v0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter$ViewHolder;->txtName:Landroid/widget/TextView;

    .line 41
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->txtChannelDescription:I

    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, v0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter$ViewHolder;->txtDescription:Landroid/widget/TextView;

    .line 42
    invoke-virtual {p2, v0}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    goto :goto_0

    .line 44
    .end local v0    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter$ViewHolder;
    :cond_0
    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter$ViewHolder;

    .line 46
    .restart local v0    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter$ViewHolder;
    :goto_0
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;->channelList:Ljava/util/List;

    invoke-interface {v1, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/LinkaMaterialProject/linkaMaterial/Channel;

    .line 47
    .local v1, "channel":Lcom/LinkaMaterialProject/linkaMaterial/Channel;
    iget-object v2, v0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter$ViewHolder;->txtName:Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "# "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/Channel;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 48
    iget-object v2, v0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter$ViewHolder;->txtDescription:Landroid/widget/TextView;

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/Channel;->getDescription()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 49
    return-object p2
.end method
