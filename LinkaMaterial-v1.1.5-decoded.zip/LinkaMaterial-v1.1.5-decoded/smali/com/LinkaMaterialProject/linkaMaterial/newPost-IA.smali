.class public final synthetic Lcom/LinkaMaterialProject/linkaMaterial/newPost-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
