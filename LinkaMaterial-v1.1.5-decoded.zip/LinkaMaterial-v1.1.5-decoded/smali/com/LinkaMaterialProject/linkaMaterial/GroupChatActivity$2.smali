.class Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$2;
.super Ljava/lang/Object;
.source "GroupChatActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    .line 78
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 81
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    const-class v2, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 82
    .local v0, "intent":Landroid/content/Intent;
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->startActivity(Landroid/content/Intent;)V

    .line 83
    return-void
.end method
