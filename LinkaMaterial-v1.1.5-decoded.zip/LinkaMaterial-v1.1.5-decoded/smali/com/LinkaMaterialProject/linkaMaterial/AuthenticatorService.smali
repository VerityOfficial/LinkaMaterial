.class public Lcom/LinkaMaterialProject/linkaMaterial/AuthenticatorService;
.super Landroid/app/Service;
.source "AuthenticatorService.java"


# instance fields
.field private mAuthenticator:Lcom/LinkaMaterialProject/linkaMaterial/Authenticator;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 5
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 2
    .param p1, "intent"    # Landroid/content/Intent;

    .line 14
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    const-string v1, "android.accounts.AccountAuthenticator"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 15
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AuthenticatorService;->mAuthenticator:Lcom/LinkaMaterialProject/linkaMaterial/Authenticator;

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/Authenticator;->getIBinder()Landroid/os/IBinder;

    move-result-object v0

    return-object v0

    .line 17
    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public onCreate()V
    .locals 1

    .line 9
    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    .line 10
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/Authenticator;

    invoke-direct {v0, p0}, Lcom/LinkaMaterialProject/linkaMaterial/Authenticator;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/AuthenticatorService;->mAuthenticator:Lcom/LinkaMaterialProject/linkaMaterial/Authenticator;

    .line 11
    return-void
.end method
