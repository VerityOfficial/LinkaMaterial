.class public Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup;
.super Landroid/app/Activity;
.source "EnterGroup.java"


# instance fields
.field private btnSend:Landroid/widget/Button;

.field private edtCode:Landroid/widget/EditText;

.field private url:Ljava/lang/String;

.field private username:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetedtCode(Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup;->edtCode:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup;->url:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup;->username:Ljava/lang/String;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 1

    .line 20
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 23
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup;->url:Ljava/lang/String;

    .line 24
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup;->username:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 6
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 26
    const-string v0, ""

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 28
    :try_start_0
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v1}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 29
    .local v1, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v2, Lorg/json/JSONObject;

    const-string v3, "config.cfg"

    invoke-virtual {v1, p0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 30
    .local v2, "jsonCfg":Lorg/json/JSONObject;
    const-string v3, "SERVER"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    .line 31
    .local v3, "server":Lorg/json/JSONObject;
    const-string v4, "FAST_LOGIN"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    .line 32
    .local v4, "fastLogin":Lorg/json/JSONObject;
    const-string v5, "username"

    invoke-virtual {v4, v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup;->username:Ljava/lang/String;

    .line 33
    const-string v5, "url"

    invoke-virtual {v3, v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup;->url:Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 36
    .end local v1    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v2    # "jsonCfg":Lorg/json/JSONObject;
    .end local v3    # "server":Lorg/json/JSONObject;
    .end local v4    # "fastLogin":Lorg/json/JSONObject;
    goto :goto_0

    .line 34
    :catch_0
    move-exception v0

    .line 35
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 37
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->activity_enter_group:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup;->setContentView(I)V

    .line 38
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtCode:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup;->edtCode:Landroid/widget/EditText;

    .line 39
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnSend:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup;->btnSend:Landroid/widget/Button;

    .line 40
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup;->btnSend:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup$1;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/EnterGroup;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 53
    return-void
.end method
