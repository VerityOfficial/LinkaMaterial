.class Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;
.super Landroid/os/AsyncTask;
.source "RemoveGroupChannel.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "FetchChannelsTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/Void;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;


# direct methods
.method private constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)V
    .locals 0

    .line 159
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)V

    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 159
    check-cast p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->doInBackground([Ljava/lang/Void;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/Void;)Ljava/lang/String;
    .locals 4
    .param p1, "params"    # [Ljava/lang/Void;

    .line 163
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 164
    .local v0, "jsonChannels":Lorg/json/JSONObject;
    const-string v1, "username"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 165
    const-string v1, "group_id"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fgetgroupId(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 166
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/view-channels"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "POST"

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v1, v2, v0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    .line 167
    .end local v0    # "jsonChannels":Lorg/json/JSONObject;
    :catch_0
    move-exception v0

    .line 168
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 169
    const/4 v1, 0x0

    return-object v1
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 159
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 7
    .param p1, "result"    # Ljava/lang/String;

    .line 175
    if-eqz p1, :cond_2

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_2

    .line 180
    :cond_0
    :try_start_0
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0, p1}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    .line 181
    .local v0, "array":Lorg/json/JSONArray;
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fgetchannelList(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->clear()V

    .line 182
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge v1, v2, :cond_1

    .line 183
    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    .line 184
    .local v2, "obj":Lorg/json/JSONObject;
    const-string v3, "channel_name"

    const-string v4, "General"

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 185
    .local v3, "channelName":Ljava/lang/String;
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fgetchannelList(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)Ljava/util/List;

    move-result-object v4

    new-instance v5, Lcom/LinkaMaterialProject/linkaMaterial/Channel;

    const-string v6, "C"

    invoke-direct {v5, v3, v6}, Lcom/LinkaMaterialProject/linkaMaterial/Channel;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 182
    nop

    .end local v2    # "obj":Lorg/json/JSONObject;
    .end local v3    # "channelName":Ljava/lang/String;
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 187
    .end local v1    # "i":I
    :cond_1
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fgetchannelList(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)Ljava/util/List;

    move-result-object v4

    invoke-direct {v2, v3, v4}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;-><init>(Landroid/content/Context;Ljava/util/List;)V

    invoke-static {v1, v2}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fputadapter(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;)V

    .line 188
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fgetlistChannelsView(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)Landroid/widget/ListView;

    move-result-object v1

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fgetadapter(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 189
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fgetlistChannelsView(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)Landroid/widget/ListView;

    move-result-object v1

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask$1;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;)V

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 209
    .end local v0    # "array":Lorg/json/JSONArray;
    goto :goto_1

    .line 207
    :catch_0
    move-exception v0

    .line 208
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 210
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_1
    return-void

    .line 176
    :cond_2
    :goto_2
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    const-string v1, "Erro ao carregar canais"

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 177
    return-void
.end method
