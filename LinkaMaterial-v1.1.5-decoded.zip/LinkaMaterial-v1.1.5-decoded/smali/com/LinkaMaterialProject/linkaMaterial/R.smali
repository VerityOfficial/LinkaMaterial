.class public final Lcom/LinkaMaterialProject/linkaMaterial/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/R$color;,
        Lcom/LinkaMaterialProject/linkaMaterial/R$dimen;,
        Lcom/LinkaMaterialProject/linkaMaterial/R$drawable;,
        Lcom/LinkaMaterialProject/linkaMaterial/R$id;,
        Lcom/LinkaMaterialProject/linkaMaterial/R$layout;,
        Lcom/LinkaMaterialProject/linkaMaterial/R$mipmap;,
        Lcom/LinkaMaterialProject/linkaMaterial/R$string;,
        Lcom/LinkaMaterialProject/linkaMaterial/R$style;,
        Lcom/LinkaMaterialProject/linkaMaterial/R$xml;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
