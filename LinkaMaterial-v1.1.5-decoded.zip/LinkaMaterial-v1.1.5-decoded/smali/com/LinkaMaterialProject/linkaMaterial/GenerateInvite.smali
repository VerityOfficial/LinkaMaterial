.class public Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;
.super Landroid/app/Activity;
.source "GenerateInvite.java"


# instance fields
.field private adapter:Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter;

.field private btnChat:Landroid/widget/ImageButton;

.field private btnGenerate:Landroid/widget/Button;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;

.field private handler:Landroid/os/Handler;

.field private inviteList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private listInvite:Landroid/widget/ListView;

.field private url:Ljava/lang/String;

.field private username:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetadapter(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->adapter:Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgethandler(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)Landroid/os/Handler;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->handler:Landroid/os/Handler;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetinviteList(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)Ljava/util/List;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->inviteList:Ljava/util/List;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->url:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->username:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mcarregarConvites(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)V
    .locals 0

    invoke-direct {p0}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->carregarConvites()V

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 19
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 27
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->url:Ljava/lang/String;

    .line 28
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->username:Ljava/lang/String;

    return-void
.end method

.method private carregarConvites()V
    .locals 2

    .line 142
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 186
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 187
    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 6
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 37
    const-string v0, ""

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 38
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->generate_invite:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->setContentView(I)V

    .line 40
    new-instance v1, Landroid/os/Handler;

    invoke-direct {v1}, Landroid/os/Handler;-><init>()V

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->handler:Landroid/os/Handler;

    .line 41
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->inviteList:Ljava/util/List;

    .line 43
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnGenerate:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->btnGenerate:Landroid/widget/Button;

    .line 44
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->listInvite:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ListView;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->listInvite:Landroid/widget/ListView;

    .line 45
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->btnHome:Landroid/widget/ImageButton;

    .line 46
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->btnChat:Landroid/widget/ImageButton;

    .line 47
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->btnOptions:Landroid/widget/ImageButton;

    .line 48
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->btnProfile:Landroid/widget/ImageButton;

    .line 49
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->inviteList:Ljava/util/List;

    invoke-direct {v1, p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter;-><init>(Landroid/content/Context;Ljava/util/List;)V

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->adapter:Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter;

    .line 50
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->listInvite:Landroid/widget/ListView;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->adapter:Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter;

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 51
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->btnHome:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$1;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 58
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->btnOptions:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$2;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 65
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->btnProfile:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$3;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 72
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->btnChat:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$4;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 80
    :try_start_0
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v1}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 81
    .local v1, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v2, Lorg/json/JSONObject;

    const-string v3, "config.cfg"

    invoke-virtual {v1, p0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 82
    .local v2, "jsonCfg":Lorg/json/JSONObject;
    const-string v3, "FAST_LOGIN"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    .line 83
    .local v3, "fastLogin":Lorg/json/JSONObject;
    const-string v4, "SERVER"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    .line 85
    .local v4, "server":Lorg/json/JSONObject;
    if-eqz v3, :cond_0

    .line 86
    const-string v5, "username"

    invoke-virtual {v3, v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->username:Ljava/lang/String;

    .line 88
    :cond_0
    if-eqz v4, :cond_1

    .line 89
    const-string v5, "url"

    invoke-virtual {v4, v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->url:Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 93
    .end local v1    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v2    # "jsonCfg":Lorg/json/JSONObject;
    .end local v3    # "fastLogin":Lorg/json/JSONObject;
    .end local v4    # "server":Lorg/json/JSONObject;
    :cond_1
    goto :goto_0

    .line 91
    :catch_0
    move-exception v1

    .line 92
    .local v1, "e":Lorg/json/JSONException;
    invoke-virtual {v1}, Lorg/json/JSONException;->printStackTrace()V

    .line 95
    .end local v1    # "e":Lorg/json/JSONException;
    :goto_0
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->btnGenerate:Landroid/widget/Button;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 136
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->username:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->url:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    .line 137
    invoke-direct {p0}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->carregarConvites()V

    .line 139
    :cond_2
    return-void
.end method
