.class Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;
.super Landroid/os/AsyncTask;
.source "DmChat.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/DmChat;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "FetchMessagesTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/Void;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;


# direct methods
.method private constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)V
    .locals 0

    .line 108
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;Lcom/LinkaMaterialProject/linkaMaterial/DmChat-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)V

    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 108
    check-cast p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;->doInBackground([Ljava/lang/Void;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/Void;)Ljava/lang/String;
    .locals 7
    .param p1, "params"    # [Ljava/lang/Void;

    .line 112
    :try_start_0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->-$$Nest$fgetother_user(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "@"

    const-string v2, ""

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 113
    .local v0, "cleanOtherUser":Ljava/lang/String;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/view"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 114
    .local v1, "fullUrl":Ljava/lang/String;
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 115
    .local v2, "json_chat":Lorg/json/JSONObject;
    const-string v3, "user1"

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 116
    const-string v3, "user2"

    invoke-virtual {v2, v3, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 117
    const-string v3, "id"

    const/4 v4, 0x0

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 118
    const-string v3, "post"

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v1, v3, v2, v4}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    .line 119
    .local v3, "response":Ljava/lang/String;
    const-string v4, "MATERIAL_DEBUG"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "[Fetch] Resposta do servidor: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 120
    return-object v3

    .line 121
    .end local v0    # "cleanOtherUser":Ljava/lang/String;
    .end local v1    # "fullUrl":Ljava/lang/String;
    .end local v2    # "json_chat":Lorg/json/JSONObject;
    .end local v3    # "response":Ljava/lang/String;
    :catch_0
    move-exception v0

    .line 122
    .local v0, "e":Ljava/lang/Exception;
    const/4 v1, 0x0

    return-object v1
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 108
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 11
    .param p1, "response"    # Ljava/lang/String;

    .line 127
    const-string v0, ""

    const-string v1, "messages"

    if-eqz p1, :cond_4

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_4

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->-$$Nest$fgetchatContainer(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Landroid/widget/LinearLayout;

    move-result-object v2

    if-nez v2, :cond_0

    goto/16 :goto_3

    .line 131
    :cond_0
    :try_start_0
    new-instance v2, Lorg/json/JSONObject;

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 132
    .local v2, "rootObject":Lorg/json/JSONObject;
    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_1

    .line 133
    return-void

    .line 135
    :cond_1
    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    .line 137
    .local v1, "messagesArray":Lorg/json/JSONArray;
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->-$$Nest$fgetchatContainer(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Landroid/widget/LinearLayout;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 138
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_0
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v4

    if-ge v3, v4, :cond_3

    .line 139
    invoke-virtual {v1, v3}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    .line 140
    .local v4, "msgObj":Lorg/json/JSONObject;
    const-string v5, "message"

    invoke-virtual {v4, v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 141
    .local v5, "text":Ljava/lang/String;
    const-string v6, "sender"

    invoke-virtual {v4, v6, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 142
    .local v6, "sender":Ljava/lang/String;
    iget-object v7, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v7}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v7

    .line 143
    .local v7, "isMe":Z
    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_2

    move-object v8, v5

    goto :goto_1

    :cond_2
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, ": "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    .line 144
    .local v8, "displayText":Ljava/lang/String;
    :goto_1
    new-instance v9, Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;

    iget-object v10, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-direct {v9, v10, v8, v7}, Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;-><init>(Landroid/content/Context;Ljava/lang/String;Z)V

    .line 145
    .local v9, "bubble":Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;
    iget-object v10, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v10}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->-$$Nest$fgetchatContainer(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Landroid/widget/LinearLayout;

    move-result-object v10

    invoke-virtual {v10, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 138
    .end local v4    # "msgObj":Lorg/json/JSONObject;
    .end local v5    # "text":Ljava/lang/String;
    .end local v6    # "sender":Ljava/lang/String;
    .end local v7    # "isMe":Z
    .end local v8    # "displayText":Ljava/lang/String;
    .end local v9    # "bubble":Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 149
    .end local v1    # "messagesArray":Lorg/json/JSONArray;
    .end local v2    # "rootObject":Lorg/json/JSONObject;
    .end local v3    # "i":I
    :cond_3
    goto :goto_2

    .line 147
    :catch_0
    move-exception v0

    .line 148
    .local v0, "e":Lorg/json/JSONException;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "[Fetch] Falha ao processar o JSON de resposta: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "MATERIAL_DEBUG"

    invoke-static {v2, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 150
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_2
    return-void

    .line 128
    :cond_4
    :goto_3
    return-void
.end method
