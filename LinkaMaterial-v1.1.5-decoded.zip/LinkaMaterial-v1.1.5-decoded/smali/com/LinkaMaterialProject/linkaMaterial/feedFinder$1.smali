.class Lcom/LinkaMaterialProject/linkaMaterial/feedFinder$1;
.super Ljava/lang/Object;
.source "feedFinder.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;

    .line 63
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 66
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;

    const-class v2, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 67
    .local v0, "intent":Landroid/content/Intent;
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->-$$Nest$fgetedtUrl(Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;)Landroid/widget/EditText;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "url"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 68
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->startActivity(Landroid/content/Intent;)V

    .line 69
    return-void
.end method
