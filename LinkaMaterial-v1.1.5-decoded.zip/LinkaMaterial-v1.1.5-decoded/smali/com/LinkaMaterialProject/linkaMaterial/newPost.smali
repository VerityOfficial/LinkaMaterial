.class public Lcom/LinkaMaterialProject/linkaMaterial/newPost;
.super Landroid/app/Activity;
.source "newPost.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/newPost$UploadImageTask;,
        Lcom/LinkaMaterialProject/linkaMaterial/newPost$SendPostTask;
    }
.end annotation


# static fields
.field private static final PICK_IMAGE_REQUEST:I = 0x3e9


# instance fields
.field private btnImage:Landroid/widget/Button;

.field private btnSend:Landroid/widget/Button;

.field private newPostText:Landroid/widget/TextView;

.field private textPost:Landroid/widget/EditText;


# direct methods
.method static bridge synthetic -$$Nest$fgetbtnImage(Lcom/LinkaMaterialProject/linkaMaterial/newPost;)Landroid/widget/Button;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->btnImage:Landroid/widget/Button;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetbtnSend(Lcom/LinkaMaterialProject/linkaMaterial/newPost;)Landroid/widget/Button;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->btnSend:Landroid/widget/Button;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgettextPost(Lcom/LinkaMaterialProject/linkaMaterial/newPost;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->textPost:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mopenGallery(Lcom/LinkaMaterialProject/linkaMaterial/newPost;)V
    .locals 0

    invoke-direct {p0}, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->openGallery()V

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 15
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private openGallery()V
    .locals 3

    .line 54
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.GET_CONTENT"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 55
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "image/*"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 56
    const-string v1, "Select Image"

    invoke-static {v0, v1}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    move-result-object v1

    const/16 v2, 0x3e9

    invoke-virtual {p0, v1, v2}, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->startActivityForResult(Landroid/content/Intent;I)V

    .line 57
    return-void
.end method


# virtual methods
.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 4
    .param p1, "requestCode"    # I
    .param p2, "resultCode"    # I
    .param p3, "data"    # Landroid/content/Intent;

    .line 61
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    .line 63
    const/16 v0, 0x3e9

    if-ne p1, v0, :cond_0

    const/4 v0, -0x1

    if-ne p2, v0, :cond_0

    if-eqz p3, :cond_0

    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 64
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    .line 65
    .local v0, "selectedImageUri":Landroid/net/Uri;
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->btnImage:Landroid/widget/Button;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setEnabled(Z)V

    .line 66
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/newPost$UploadImageTask;

    const/4 v3, 0x0

    invoke-direct {v1, p0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/newPost$UploadImageTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/newPost;Lcom/LinkaMaterialProject/linkaMaterial/newPost-IA;)V

    const/4 v3, 0x1

    new-array v3, v3, [Landroid/net/Uri;

    aput-object v0, v3, v2

    invoke-virtual {v1, v3}, Lcom/LinkaMaterialProject/linkaMaterial/newPost$UploadImageTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 68
    .end local v0    # "selectedImageUri":Landroid/net/Uri;
    :cond_0
    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 2
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 24
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 25
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->new_post_activity:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->setContentView(I)V

    .line 27
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->newPostText:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->newPostText:Landroid/widget/TextView;

    .line 28
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->textPost:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->textPost:Landroid/widget/EditText;

    .line 29
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnSend:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->btnSend:Landroid/widget/Button;

    .line 30
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnImage:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->btnImage:Landroid/widget/Button;

    .line 32
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->btnSend:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/newPost$1;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/newPost$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/newPost;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 45
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->btnImage:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/newPost$2;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/newPost$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/newPost;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 51
    return-void
.end method
