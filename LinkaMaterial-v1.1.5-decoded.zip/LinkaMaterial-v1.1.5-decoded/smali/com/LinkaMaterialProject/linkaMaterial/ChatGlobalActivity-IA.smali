.class public final synthetic Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
