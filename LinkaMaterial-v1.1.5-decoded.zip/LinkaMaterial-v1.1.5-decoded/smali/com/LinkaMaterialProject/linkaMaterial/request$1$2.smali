.class Lcom/LinkaMaterialProject/linkaMaterial/request$1$2;
.super Ljava/lang/Object;
.source "request.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/request$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/request$1;

.field final synthetic val$e:Ljava/lang/Exception;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/request$1;Ljava/lang/Exception;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/request$1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 36
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/request$1;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1$2;->val$e:Ljava/lang/Exception;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 39
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/request$1;

    iget-object v0, v0, Lcom/LinkaMaterialProject/linkaMaterial/request$1;->val$callback:Lcom/LinkaMaterialProject/linkaMaterial/request$RequestCallback;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1$2;->val$e:Ljava/lang/Exception;

    invoke-interface {v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/request$RequestCallback;->onError(Ljava/lang/Exception;)V

    .line 40
    return-void
.end method
