.class public Lcom/LinkaMaterialProject/linkaMaterial/request;
.super Ljava/lang/Object;
.source "request.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/request$RequestCallback;,
        Lcom/LinkaMaterialProject/linkaMaterial/request$RequestBytesCallback;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static requestBytes(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)[B
    .locals 10
    .param p0, "urlParam"    # Ljava/lang/String;
    .param p1, "method"    # Ljava/lang/String;
    .param p2, "context"    # Landroid/content/Context;

    .line 84
    const-string v0, "FAST_LOGIN"

    const/4 v1, 0x0

    .line 86
    .local v1, "connection":Ljava/net/HttpURLConnection;
    :try_start_0
    const-string v2, "http.keepAlive"

    const-string v3, "false"

    invoke-static {v2, v3}, Ljava/lang/System;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 87
    new-instance v2, Ljava/net/URL;

    invoke-direct {v2, p0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 88
    .local v2, "url":Ljava/net/URL;
    invoke-virtual {v2}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v3

    check-cast v3, Ljava/net/HttpURLConnection;

    move-object v1, v3

    .line 89
    invoke-virtual {p1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v3

    move-object p1, v3

    .line 90
    invoke-virtual {v1, p1}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 91
    if-eqz p2, :cond_1

    .line 93
    :try_start_1
    new-instance v3, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v3}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 94
    .local v3, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    const-string v4, "config.cfg"

    invoke-virtual {v3, p2, v4}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 95
    .local v4, "rawCfg":Ljava/lang/String;
    if-eqz v4, :cond_0

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_0

    .line 96
    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 97
    .local v5, "jsonCfg":Lorg/json/JSONObject;
    invoke-virtual {v5, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_0

    .line 98
    invoke-virtual {v5, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    .line 99
    .local v0, "fastLogin":Lorg/json/JSONObject;
    const-string v6, "token_session"

    const-string v7, ""

    invoke-virtual {v0, v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 100
    .local v6, "token":Ljava/lang/String;
    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_0

    .line 101
    const-string v7, "Authorization"

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "Bearer "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1, v7, v8}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 129
    .end local v0    # "fastLogin":Lorg/json/JSONObject;
    .end local v2    # "url":Ljava/net/URL;
    .end local v3    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v4    # "rawCfg":Ljava/lang/String;
    .end local v5    # "jsonCfg":Lorg/json/JSONObject;
    .end local v6    # "token":Ljava/lang/String;
    :catchall_0
    move-exception v0

    move-object v5, p2

    goto/16 :goto_6

    .line 105
    .restart local v2    # "url":Ljava/net/URL;
    :catch_0
    move-exception v0

    :cond_0
    :goto_0
    nop

    .line 107
    :cond_1
    :try_start_2
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0

    .line 108
    .local v0, "responseCode":I
    const/16 v3, 0x193

    if-ne v0, v3, :cond_3

    if-eqz p2, :cond_3

    .line 109
    invoke-static {p2}, Lcom/LinkaMaterialProject/linkaMaterial/tokenManager;->newSession(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    move-object v9, v3

    .line 110
    .local v9, "newToken":Ljava/lang/String;
    if-eqz v9, :cond_2

    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_2

    .line 111
    new-instance v4, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v4}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 112
    .local v4, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    const-string v6, "config.cfg"

    const-string v7, "FAST_LOGIN"

    const-string v8, "token_session"
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    move-object v5, p2

    .end local p2    # "context":Landroid/content/Context;
    .local v5, "context":Landroid/content/Context;
    :try_start_3
    invoke-virtual/range {v4 .. v9}, Lcom/LinkaMaterialProject/linkaMaterial/config;->updateCfg(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    goto :goto_1

    .line 110
    .end local v4    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v5    # "context":Landroid/content/Context;
    .restart local p2    # "context":Landroid/content/Context;
    :cond_2
    move-object v5, p2

    .end local p2    # "context":Landroid/content/Context;
    .restart local v5    # "context":Landroid/content/Context;
    goto :goto_1

    .line 108
    .end local v5    # "context":Landroid/content/Context;
    .end local v9    # "newToken":Ljava/lang/String;
    .restart local p2    # "context":Landroid/content/Context;
    :cond_3
    move-object v5, p2

    .line 115
    .end local p2    # "context":Landroid/content/Context;
    .restart local v5    # "context":Landroid/content/Context;
    :goto_1
    const/16 p2, 0xc8

    if-ne v0, p2, :cond_6

    .line 116
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object p2

    .line 117
    .local p2, "in":Ljava/io/InputStream;
    new-instance v3, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v3}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 118
    .local v3, "out":Ljava/io/ByteArrayOutputStream;
    const/16 v4, 0x1000

    new-array v4, v4, [B

    .line 120
    .local v4, "buffer":[B
    :goto_2
    invoke-virtual {p2, v4}, Ljava/io/InputStream;->read([B)I

    move-result v6

    move v7, v6

    .local v7, "bytesRead":I
    const/4 v8, -0x1

    if-eq v6, v8, :cond_4

    .line 121
    const/4 v6, 0x0

    invoke-virtual {v3, v4, v6, v7}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_2

    .line 123
    :cond_4
    invoke-virtual {p2}, Ljava/io/InputStream;->close()V

    .line 124
    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v6
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 129
    if-eqz v1, :cond_5

    .line 130
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 124
    :cond_5
    return-object v6

    .line 126
    .end local v0    # "responseCode":I
    .end local v2    # "url":Ljava/net/URL;
    .end local v3    # "out":Ljava/io/ByteArrayOutputStream;
    .end local v4    # "buffer":[B
    .end local v7    # "bytesRead":I
    .end local p2    # "in":Ljava/io/InputStream;
    :catch_1
    move-exception v0

    move-object p2, v0

    goto :goto_4

    .line 129
    :cond_6
    if-eqz v1, :cond_7

    .line 130
    :goto_3
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    goto :goto_5

    .line 129
    .end local v5    # "context":Landroid/content/Context;
    .local p2, "context":Landroid/content/Context;
    :catchall_1
    move-exception v0

    move-object v5, p2

    .end local p2    # "context":Landroid/content/Context;
    .restart local v5    # "context":Landroid/content/Context;
    goto :goto_6

    .line 126
    .end local v5    # "context":Landroid/content/Context;
    .restart local p2    # "context":Landroid/content/Context;
    :catch_2
    move-exception v0

    move-object v5, p2

    move-object p2, v0

    .line 127
    .restart local v5    # "context":Landroid/content/Context;
    .local p2, "e":Ljava/lang/Exception;
    :goto_4
    :try_start_4
    invoke-virtual {p2}, Ljava/lang/Exception;->printStackTrace()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 129
    .end local p2    # "e":Ljava/lang/Exception;
    if-eqz v1, :cond_7

    .line 130
    goto :goto_3

    .line 133
    :cond_7
    :goto_5
    const/4 p2, 0x0

    return-object p2

    .line 129
    :catchall_2
    move-exception v0

    :goto_6
    if-eqz v1, :cond_8

    .line 130
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 132
    :cond_8
    goto :goto_8

    :goto_7
    throw v0

    :goto_8
    goto :goto_7
.end method

.method public static requestBytesAsync(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lcom/LinkaMaterialProject/linkaMaterial/request$RequestBytesCallback;)V
    .locals 2
    .param p0, "urlParam"    # Ljava/lang/String;
    .param p1, "method"    # Ljava/lang/String;
    .param p2, "context"    # Landroid/content/Context;
    .param p3, "callback"    # Lcom/LinkaMaterialProject/linkaMaterial/request$RequestBytesCallback;

    .line 48
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/request$2;

    invoke-direct {v1, p0, p1, p2, p3}, Lcom/LinkaMaterialProject/linkaMaterial/request$2;-><init>(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lcom/LinkaMaterialProject/linkaMaterial/request$RequestBytesCallback;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 72
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 73
    return-void
.end method

.method public static requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;
    .locals 2
    .param p0, "urlParam"    # Ljava/lang/String;
    .param p1, "method"    # Ljava/lang/String;
    .param p2, "json_body"    # Lorg/json/JSONObject;

    .line 75
    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p0, p1, p2, v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;ILandroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;I)Ljava/lang/String;
    .locals 1
    .param p0, "urlParam"    # Ljava/lang/String;
    .param p1, "method"    # Ljava/lang/String;
    .param p2, "json_body"    # Lorg/json/JSONObject;
    .param p3, "status_code"    # I

    .line 81
    const/4 v0, 0x0

    invoke-static {p0, p1, p2, p3, v0}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;ILandroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;ILandroid/content/Context;)Ljava/lang/String;
    .locals 12
    .param p0, "urlParam"    # Ljava/lang/String;
    .param p1, "method"    # Ljava/lang/String;
    .param p2, "json_body"    # Lorg/json/JSONObject;
    .param p3, "status_code"    # I
    .param p4, "context"    # Landroid/content/Context;

    .line 136
    move-object/from16 v1, p4

    const-string v0, "FAST_LOGIN"

    const-string v6, ""

    const/4 v2, 0x0

    .line 138
    .local v2, "connection":Ljava/net/HttpURLConnection;
    :try_start_0
    const-string v3, "http.keepAlive"

    const-string v4, "false"

    invoke-static {v3, v4}, Ljava/lang/System;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 139
    new-instance v3, Ljava/net/URL;

    invoke-direct {v3, p0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    move-object v7, v3

    .line 140
    .local v7, "url":Ljava/net/URL;
    invoke-virtual {v7}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v3

    check-cast v3, Ljava/net/HttpURLConnection;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_3
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    move-object v8, v3

    .line 141
    .end local v2    # "connection":Ljava/net/HttpURLConnection;
    .local v8, "connection":Ljava/net/HttpURLConnection;
    :try_start_1
    invoke-virtual {p1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v2

    move-object p1, v2

    .line 142
    const/16 v2, 0x1f40

    invoke-virtual {v8, v2}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    .line 143
    invoke-virtual {v8, v2}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    .line 144
    invoke-virtual {v8, p1}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 145
    const-string v2, "Content-Type"

    const-string v3, "application/json"

    invoke-virtual {v8, v2, v3}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 146
    if-eqz v1, :cond_1

    .line 148
    :try_start_2
    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v2}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 149
    .local v2, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    const-string v3, "config.cfg"

    invoke-virtual {v2, v1, v3}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 150
    .local v3, "rawCfg":Ljava/lang/String;
    if-eqz v3, :cond_0

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_0

    .line 151
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 152
    .local v4, "jsonCfg":Lorg/json/JSONObject;
    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_0

    .line 153
    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    .line 154
    .local v0, "fastLogin":Lorg/json/JSONObject;
    const-string v5, "token_session"

    invoke-virtual {v0, v5, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 155
    .local v5, "token":Ljava/lang/String;
    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_0

    .line 156
    const-string v9, "Authorization"

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "Bearer "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v9, v10}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    goto :goto_0

    .line 160
    .end local v0    # "fastLogin":Lorg/json/JSONObject;
    .end local v2    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v3    # "rawCfg":Ljava/lang/String;
    .end local v4    # "jsonCfg":Lorg/json/JSONObject;
    .end local v5    # "token":Ljava/lang/String;
    :catch_0
    move-exception v0

    :cond_0
    :goto_0
    nop

    .line 162
    :cond_1
    :try_start_3
    const-string v0, "POST"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const-string v9, "UTF-8"

    if-nez v0, :cond_2

    :try_start_4
    const-string v0, "PUT"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 163
    :cond_2
    const/4 v0, 0x1

    invoke-virtual {v8, v0}, Ljava/net/HttpURLConnection;->setDoOutput(Z)V

    .line 164
    invoke-virtual {v8}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    .line 165
    .local v0, "os":Ljava/io/OutputStream;
    if-eqz p2, :cond_3

    .line 166
    invoke-virtual {p2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v9}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/io/OutputStream;->write([B)V

    .line 168
    :cond_3
    invoke-virtual {v0}, Ljava/io/OutputStream;->flush()V

    .line 169
    invoke-virtual {v0}, Ljava/io/OutputStream;->close()V

    .line 171
    .end local v0    # "os":Ljava/io/OutputStream;
    :cond_4
    invoke-virtual {v8}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    move v10, v0

    .line 172
    .local v10, "responseCode":I
    move v11, v10

    .line 173
    .end local p3    # "status_code":I
    .local v11, "status_code":I
    const/16 v0, 0x193

    if-ne v10, v0, :cond_5

    if-eqz v1, :cond_5

    .line 174
    :try_start_5
    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/tokenManager;->newSession(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v5

    .line 175
    .local v5, "newToken":Ljava/lang/String;
    if-eqz v5, :cond_5

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_5

    .line 176
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v0}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 177
    .local v0, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    const-string v2, "config.cfg"

    const-string v3, "FAST_LOGIN"

    const-string v4, "token_session"

    invoke-virtual/range {v0 .. v5}, Lcom/LinkaMaterialProject/linkaMaterial/config;->updateCfg(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_1
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 180
    .end local v0    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v5    # "newToken":Ljava/lang/String;
    :cond_5
    const/16 v0, 0xc8

    if-eq v10, v0, :cond_7

    const/16 v0, 0xc9

    if-ne v10, v0, :cond_6

    goto :goto_1

    .line 193
    .end local v7    # "url":Ljava/net/URL;
    .end local v10    # "responseCode":I
    :cond_6
    if-eqz v8, :cond_b

    .line 194
    invoke-virtual {v8}, Ljava/net/HttpURLConnection;->disconnect()V

    goto :goto_4

    .line 181
    .restart local v7    # "url":Ljava/net/URL;
    .restart local v10    # "responseCode":I
    :cond_7
    :goto_1
    :try_start_6
    new-instance v0, Ljava/io/BufferedReader;

    new-instance v1, Ljava/io/InputStreamReader;

    invoke-virtual {v8}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v2

    invoke-direct {v1, v2, v9}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/lang/String;)V

    invoke-direct {v0, v1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 182
    .local v0, "in":Ljava/io/BufferedReader;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 184
    .local v1, "response":Ljava/lang/StringBuilder;
    :goto_2
    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v2

    move-object v3, v2

    .local v3, "line":Ljava/lang/String;
    if-eqz v2, :cond_8

    .line 185
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_2

    .line 187
    :cond_8
    invoke-virtual {v0}, Ljava/io/BufferedReader;->close()V

    .line 188
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 193
    if-eqz v8, :cond_9

    .line 194
    invoke-virtual {v8}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 188
    :cond_9
    return-object v2

    .line 193
    .end local v0    # "in":Ljava/io/BufferedReader;
    .end local v1    # "response":Ljava/lang/StringBuilder;
    .end local v3    # "line":Ljava/lang/String;
    .end local v7    # "url":Ljava/net/URL;
    .end local v10    # "responseCode":I
    :catchall_0
    move-exception v0

    move-object v2, v8

    goto :goto_5

    .line 190
    :catch_1
    move-exception v0

    move-object v2, v8

    goto :goto_3

    .line 193
    .end local v11    # "status_code":I
    .restart local p3    # "status_code":I
    :catchall_1
    move-exception v0

    move v11, p3

    move-object v2, v8

    goto :goto_5

    .line 190
    :catch_2
    move-exception v0

    move v11, p3

    move-object v2, v8

    goto :goto_3

    .line 193
    .end local v8    # "connection":Ljava/net/HttpURLConnection;
    .local v2, "connection":Ljava/net/HttpURLConnection;
    :catchall_2
    move-exception v0

    move v11, p3

    goto :goto_5

    .line 190
    :catch_3
    move-exception v0

    move v11, p3

    .line 191
    .end local p3    # "status_code":I
    .local v0, "e":Ljava/lang/Exception;
    .restart local v11    # "status_code":I
    :goto_3
    :try_start_7
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 193
    .end local v0    # "e":Ljava/lang/Exception;
    if-eqz v2, :cond_a

    .line 194
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 197
    :cond_a
    move-object v8, v2

    .end local v2    # "connection":Ljava/net/HttpURLConnection;
    .restart local v8    # "connection":Ljava/net/HttpURLConnection;
    :cond_b
    :goto_4
    return-object v6

    .line 193
    .end local v8    # "connection":Ljava/net/HttpURLConnection;
    .restart local v2    # "connection":Ljava/net/HttpURLConnection;
    :catchall_3
    move-exception v0

    :goto_5
    if-eqz v2, :cond_c

    .line 194
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 196
    :cond_c
    goto :goto_7

    :goto_6
    throw v0

    :goto_7
    goto :goto_6
.end method

.method public static requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;
    .locals 1
    .param p0, "urlParam"    # Ljava/lang/String;
    .param p1, "method"    # Ljava/lang/String;
    .param p2, "json_body"    # Lorg/json/JSONObject;
    .param p3, "context"    # Landroid/content/Context;

    .line 78
    const/4 v0, 0x0

    invoke-static {p0, p1, p2, v0, p3}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;ILandroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static requestHTTPAsync(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;ILandroid/content/Context;Lcom/LinkaMaterialProject/linkaMaterial/request$RequestCallback;)V
    .locals 8
    .param p0, "urlParam"    # Ljava/lang/String;
    .param p1, "method"    # Ljava/lang/String;
    .param p2, "json_body"    # Lorg/json/JSONObject;
    .param p3, "status_code"    # I
    .param p4, "context"    # Landroid/content/Context;
    .param p5, "callback"    # Lcom/LinkaMaterialProject/linkaMaterial/request$RequestCallback;

    .line 21
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/request$1;

    move-object v2, p0

    move-object v3, p1

    move-object v4, p2

    move v5, p3

    move-object v6, p4

    move-object v7, p5

    .end local p0    # "urlParam":Ljava/lang/String;
    .end local p1    # "method":Ljava/lang/String;
    .end local p2    # "json_body":Lorg/json/JSONObject;
    .end local p3    # "status_code":I
    .end local p4    # "context":Landroid/content/Context;
    .end local p5    # "callback":Lcom/LinkaMaterialProject/linkaMaterial/request$RequestCallback;
    .local v2, "urlParam":Ljava/lang/String;
    .local v3, "method":Ljava/lang/String;
    .local v4, "json_body":Lorg/json/JSONObject;
    .local v5, "status_code":I
    .local v6, "context":Landroid/content/Context;
    .local v7, "callback":Lcom/LinkaMaterialProject/linkaMaterial/request$RequestCallback;
    invoke-direct/range {v1 .. v7}, Lcom/LinkaMaterialProject/linkaMaterial/request$1;-><init>(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;ILandroid/content/Context;Lcom/LinkaMaterialProject/linkaMaterial/request$RequestCallback;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 45
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 46
    return-void
.end method
