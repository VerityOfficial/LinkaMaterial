.class Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6$1;
.super Ljava/lang/Object;
.source "ViewPicture.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6;

.field final synthetic val$savedUrl:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$1"    # Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 107
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6$1;->val$savedUrl:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 110
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6$1;->val$savedUrl:Ljava/lang/String;

    .line 113
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6;

    .line 110
    const/4 v2, 0x0

    if-eqz v0, :cond_0

    .line 111
    iget-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;

    const-string v1, "Image saved in gallery!"

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 113
    :cond_0
    iget-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;

    const-string v1, "Error in saving photo in SDCard."

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 115
    :goto_0
    return-void
.end method
