.class Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask$1;
.super Ljava/lang/Object;
.source "RemoveGroupChannel.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->onPostExecute(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;)V
    .locals 0
    .param p1, "this$1"    # Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;

    .line 189
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 5
    .param p2, "view"    # Landroid/view/View;
    .param p3, "position"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 193
    .local p1, "parent":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    :try_start_0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;

    iget-object v0, v0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fgetchannelList(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/LinkaMaterialProject/linkaMaterial/Channel;

    .line 194
    .local v0, "selectedChannel":Lcom/LinkaMaterialProject/linkaMaterial/Channel;
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    .line 195
    .local v1, "jsonRemove":Lorg/json/JSONObject;
    const-string v2, "username"

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;

    iget-object v3, v3, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 196
    const-string v2, "channel_name"

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/Channel;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 197
    const-string v2, "group_id"

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;

    iget-object v3, v3, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fgetgroupId(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)I

    move-result v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 198
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;

    iget-object v3, v3, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/remove-channel"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "post"

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;

    iget-object v4, v4, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v2, v3, v1, v4}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    .line 199
    new-instance v2, Landroid/content/Intent;

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;

    iget-object v3, v3, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    const-class v4, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 200
    .local v2, "intentGroup":Landroid/content/Intent;
    const-string v3, "groupId"

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;

    iget-object v4, v4, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fgetgroupId(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)I

    move-result v4

    invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 201
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;

    iget-object v3, v3, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-virtual {v3, v2}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 204
    .end local v0    # "selectedChannel":Lcom/LinkaMaterialProject/linkaMaterial/Channel;
    .end local v1    # "jsonRemove":Lorg/json/JSONObject;
    .end local v2    # "intentGroup":Landroid/content/Intent;
    goto :goto_0

    .line 202
    :catch_0
    move-exception v0

    .line 203
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 205
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    return-void
.end method
