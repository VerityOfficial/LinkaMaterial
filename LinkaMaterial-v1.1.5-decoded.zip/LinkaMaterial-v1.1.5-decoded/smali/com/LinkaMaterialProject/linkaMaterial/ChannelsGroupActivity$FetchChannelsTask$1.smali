.class Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask$1;
.super Ljava/lang/Object;
.source "ChannelsGroupActivity.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->onPostExecute(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;)V
    .locals 0
    .param p1, "this$1"    # Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;

    .line 214
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 4
    .param p2, "view"    # Landroid/view/View;
    .param p3, "position"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 217
    .local p1, "parent":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;

    iget-object v0, v0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->-$$Nest$fgetchannelList(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/LinkaMaterialProject/linkaMaterial/Channel;

    .line 218
    .local v0, "selectedChannel":Lcom/LinkaMaterialProject/linkaMaterial/Channel;
    new-instance v1, Landroid/content/Intent;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;

    iget-object v2, v2, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    const-class v3, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 219
    .local v1, "intent":Landroid/content/Intent;
    const-string v2, "channel"

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/Channel;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 220
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;

    iget-object v2, v2, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->-$$Nest$fgetgroupId(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)I

    move-result v2

    const-string v3, "group_id"

    invoke-virtual {v1, v3, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 221
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;

    iget-object v2, v2, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-virtual {v2, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->startActivity(Landroid/content/Intent;)V

    .line 222
    return-void
.end method
