.class Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer$1;
.super Ljava/lang/Object;
.source "ChangeServer.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;

    .line 49
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 7
    .param p1, "v"    # Landroid/view/View;

    .line 51
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->-$$Nest$fgetedtServer(Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    .line 53
    .local v6, "url":Ljava/lang/String;
    :try_start_0
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v1}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 54
    .local v1, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;

    const-string v3, "config.cfg"

    const-string v4, "SERVER"

    const-string v5, "url"

    invoke-virtual/range {v1 .. v6}, Lcom/LinkaMaterialProject/linkaMaterial/config;->updateCfg(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 57
    nop

    .end local v1    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    goto :goto_0

    .line 55
    :catch_0
    move-exception v0

    .line 56
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 58
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_0
    return-void
.end method
