.class Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$2;
.super Ljava/lang/Object;
.source "EditAccount.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;

    .line 52
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 55
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->-$$Nest$mopenGallery(Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;)V

    .line 56
    return-void
.end method
