.class Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2$1;
.super Ljava/lang/Object;
.source "FederationsAdapter.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2;

.field final synthetic val$bitmap:Landroid/graphics/Bitmap;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2;Landroid/graphics/Bitmap;)V
    .locals 0
    .param p1, "this$1"    # Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 96
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2$1;->val$bitmap:Landroid/graphics/Bitmap;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 99
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2;

    iget-object v0, v0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2;->val$targetImageView:Landroid/widget/ImageView;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2$1;->val$bitmap:Landroid/graphics/Bitmap;

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 100
    return-void
.end method
