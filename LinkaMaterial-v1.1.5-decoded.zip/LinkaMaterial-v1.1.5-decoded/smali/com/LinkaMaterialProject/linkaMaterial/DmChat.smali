.class public Lcom/LinkaMaterialProject/linkaMaterial/DmChat;
.super Landroid/app/Activity;
.source "DmChat.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;,
        Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;
    }
.end annotation


# static fields
.field private static final TAG:Ljava/lang/String; = "MATERIAL_DEBUG"

.field private static final UPDATE_INTERVAL:I = 0x7d0


# instance fields
.field private final autoUpdateHandler:Landroid/os/Handler;

.field private autoUpdateRunnable:Ljava/lang/Runnable;

.field private btnHeaderImage:Landroid/widget/ImageButton;

.field private btnSend:Landroid/widget/Button;

.field private chatContainer:Landroid/widget/LinearLayout;

.field private edtInputMessage:Landroid/widget/EditText;

.field private other_user:Ljava/lang/String;

.field private txtHeaderTitle:Landroid/widget/TextView;

.field private url:Ljava/lang/String;

.field private username:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetautoUpdateHandler(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Landroid/os/Handler;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->autoUpdateHandler:Landroid/os/Handler;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetchatContainer(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Landroid/widget/LinearLayout;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->chatContainer:Landroid/widget/LinearLayout;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetedtInputMessage(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->edtInputMessage:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetother_user(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->other_user:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->url:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->username:Ljava/lang/String;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 2

    .line 19
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 26
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->username:Ljava/lang/String;

    .line 27
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->url:Ljava/lang/String;

    .line 28
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->other_user:Ljava/lang/String;

    .line 29
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->autoUpdateHandler:Landroid/os/Handler;

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 11
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 34
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 35
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->global_chat:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->setContentView(I)V

    .line 36
    const-string v0, "=== DmChat Started ==="

    const-string v1, "MATERIAL_DEBUG"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 37
    invoke-virtual {p0}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->getIntent()Landroid/content/Intent;

    move-result-object v0

    .line 38
    .local v0, "intent":Landroid/content/Intent;
    if-eqz v0, :cond_1

    .line 39
    const-string v2, "target_user"

    invoke-virtual {v0, v2}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_0

    .line 40
    invoke-virtual {v0, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->other_user:Ljava/lang/String;

    goto :goto_0

    .line 41
    :cond_0
    const-string v2, "friend"

    invoke-virtual {v0, v2}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_1

    .line 42
    invoke-virtual {v0, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->other_user:Ljava/lang/String;

    .line 45
    :cond_1
    :goto_0
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->other_user:Ljava/lang/String;

    const-string v3, ""

    if-nez v2, :cond_2

    .line 46
    iput-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->other_user:Ljava/lang/String;

    .line 48
    :cond_2
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->other_user:Ljava/lang/String;

    const-string v4, "@"

    invoke-virtual {v2, v4, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    .line 50
    .local v2, "cleanOtherUser":Ljava/lang/String;
    :try_start_0
    new-instance v5, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v5}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 51
    .local v5, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    const-string v6, "config.cfg"

    invoke-virtual {v5, p0, v6}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 52
    .local v6, "rawCfg":Ljava/lang/String;
    if-eqz v6, :cond_3

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_3

    .line 53
    new-instance v7, Lorg/json/JSONObject;

    invoke-direct {v7, v6}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 54
    .local v7, "jsonCfg":Lorg/json/JSONObject;
    const-string v8, "FAST_LOGIN"

    invoke-virtual {v7, v8}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v8

    .line 55
    .local v8, "fastLogin":Lorg/json/JSONObject;
    const-string v9, "SERVER"

    invoke-virtual {v7, v9}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v9

    .line 56
    .local v9, "server":Lorg/json/JSONObject;
    const-string v10, "username"

    invoke-virtual {v8, v10, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10, v4, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->username:Ljava/lang/String;

    .line 57
    const-string v4, "url"

    invoke-virtual {v9, v4, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    iput-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->url:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 61
    .end local v5    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v6    # "rawCfg":Ljava/lang/String;
    .end local v7    # "jsonCfg":Lorg/json/JSONObject;
    .end local v8    # "fastLogin":Lorg/json/JSONObject;
    .end local v9    # "server":Lorg/json/JSONObject;
    :cond_3
    goto :goto_1

    .line 59
    :catch_0
    move-exception v3

    .line 60
    .local v3, "e":Ljava/lang/Exception;
    const-string v4, "Error parsing config.cfg"

    invoke-static {v1, v4, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 62
    .end local v3    # "e":Ljava/lang/Exception;
    :goto_1
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHeaderImage:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->btnHeaderImage:Landroid/widget/ImageButton;

    .line 63
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->txtHeaderTitle:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->txtHeaderTitle:Landroid/widget/TextView;

    .line 64
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnSend:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->btnSend:Landroid/widget/Button;

    .line 65
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtInputMessage:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/EditText;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->edtInputMessage:Landroid/widget/EditText;

    .line 66
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->layoutMessagesContainer:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->chatContainer:Landroid/widget/LinearLayout;

    .line 67
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->txtHeaderTitle:Landroid/widget/TextView;

    if-eqz v1, :cond_5

    .line 68
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->txtHeaderTitle:Landroid/widget/TextView;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_4

    const-string v3, "Chat"

    goto :goto_2

    :cond_4
    move-object v3, v2

    :goto_2
    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 70
    :cond_5
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->btnSend:Landroid/widget/Button;

    if-eqz v1, :cond_6

    .line 71
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->btnSend:Landroid/widget/Button;

    new-instance v3, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$1;

    invoke-direct {v3, p0}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)V

    invoke-virtual {v1, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 82
    :cond_6
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->btnHeaderImage:Landroid/widget/ImageButton;

    if-eqz v1, :cond_7

    .line 83
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->btnHeaderImage:Landroid/widget/ImageButton;

    new-instance v3, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$2;

    invoke-direct {v3, p0}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)V

    invoke-virtual {v1, v3}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 90
    :cond_7
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$3;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)V

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->autoUpdateRunnable:Ljava/lang/Runnable;

    .line 97
    return-void
.end method

.method protected onPause()V
    .locals 2

    .line 105
    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    .line 106
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->autoUpdateHandler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->autoUpdateRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 107
    return-void
.end method

.method protected onResume()V
    .locals 2

    .line 100
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 101
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->autoUpdateHandler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->autoUpdateRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 102
    return-void
.end method
