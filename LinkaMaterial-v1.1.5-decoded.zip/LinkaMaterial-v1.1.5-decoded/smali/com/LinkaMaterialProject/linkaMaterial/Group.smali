.class public Lcom/LinkaMaterialProject/linkaMaterial/Group;
.super Ljava/lang/Object;
.source "Group.java"


# instance fields
.field private id:I

.field private name:Ljava/lang/String;

.field private permissions:Ljava/lang/String;


# direct methods
.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "id"    # I
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "permissions"    # Ljava/lang/String;

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    iput p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/Group;->id:I

    .line 8
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/Group;->name:Ljava/lang/String;

    .line 9
    iput-object p3, p0, Lcom/LinkaMaterialProject/linkaMaterial/Group;->permissions:Ljava/lang/String;

    .line 10
    return-void
.end method


# virtual methods
.method public getId()I
    .locals 1

    .line 11
    iget v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/Group;->id:I

    return v0
.end method

.method public getName()Ljava/lang/String;
    .locals 1

    .line 12
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/Group;->name:Ljava/lang/String;

    return-object v0
.end method

.method public getPermissions()Ljava/lang/String;
    .locals 1

    .line 13
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/Group;->permissions:Ljava/lang/String;

    return-object v0
.end method
