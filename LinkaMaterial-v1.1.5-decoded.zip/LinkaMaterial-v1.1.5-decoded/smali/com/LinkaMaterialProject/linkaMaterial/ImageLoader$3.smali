.class Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$3;
.super Ljava/lang/Object;
.source "ImageLoader.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;->viewProfilePicture(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;

.field final synthetic val$context:Landroid/content/Context;

.field final synthetic val$targetImageView:Landroid/widget/ImageView;

.field final synthetic val$username:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 108
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$3;->val$context:Landroid/content/Context;

    iput-object p3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$3;->val$username:Ljava/lang/String;

    iput-object p4, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$3;->val$targetImageView:Landroid/widget/ImageView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 12

    .line 112
    const-string v0, "profile-picture"

    :try_start_0
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v1}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 113
    .local v1, "configInstance":Lcom/LinkaMaterialProject/linkaMaterial/config;
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$3;->val$context:Landroid/content/Context;

    const-string v3, "config.cfg"

    invoke-virtual {v1, v2, v3}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 114
    .local v2, "rawConfig":Ljava/lang/String;
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 115
    .local v3, "jsonConfig":Lorg/json/JSONObject;
    const-string v4, "SERVER"

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    .line 117
    .local v4, "serverConfig":Lorg/json/JSONObject;
    const-string v5, "url"

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 118
    .local v5, "baseUrl":Ljava/lang/String;
    const-string v6, "/"

    invoke-virtual {v5, v6}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_0

    .line 119
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v6

    add-int/lit8 v6, v6, -0x1

    const/4 v7, 0x0

    invoke-virtual {v5, v7, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v6

    move-object v5, v6

    .line 122
    :cond_0
    new-instance v6, Lorg/json/JSONObject;

    invoke-direct {v6}, Lorg/json/JSONObject;-><init>()V

    .line 123
    .local v6, "requestBody":Lorg/json/JSONObject;
    const-string v7, "username"

    iget-object v8, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$3;->val$username:Ljava/lang/String;

    invoke-virtual {v6, v7, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 125
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, "/view-profile-picture"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const-string v8, "POST"

    iget-object v9, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$3;->val$context:Landroid/content/Context;

    invoke-static {v7, v8, v6, v9}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v7

    .line 127
    .local v7, "jsonResponse":Ljava/lang/String;
    if-eqz v7, :cond_1

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_1

    .line 128
    new-instance v8, Lorg/json/JSONObject;

    invoke-direct {v8, v7}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 130
    .local v8, "responseData":Lorg/json/JSONObject;
    invoke-virtual {v8, v0}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v9

    if-nez v9, :cond_1

    .line 131
    const-string v9, ""

    invoke-virtual {v8, v0, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 133
    .local v0, "avatarUrl":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_1

    const-string v9, "null"

    invoke-virtual {v0, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1

    .line 134
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, "/lite-render?url="

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, "UTF-8"

    invoke-static {v0, v10}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    .line 135
    .local v9, "proxyUrl":Ljava/lang/String;
    iget-object v10, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;

    iget-object v11, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$3;->val$targetImageView:Landroid/widget/ImageView;

    invoke-virtual {v10, v9, v11}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;->processImageData(Ljava/lang/String;Landroid/widget/ImageView;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 140
    .end local v0    # "avatarUrl":Ljava/lang/String;
    .end local v1    # "configInstance":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v2    # "rawConfig":Ljava/lang/String;
    .end local v3    # "jsonConfig":Lorg/json/JSONObject;
    .end local v4    # "serverConfig":Lorg/json/JSONObject;
    .end local v5    # "baseUrl":Ljava/lang/String;
    .end local v6    # "requestBody":Lorg/json/JSONObject;
    .end local v7    # "jsonResponse":Ljava/lang/String;
    .end local v8    # "responseData":Lorg/json/JSONObject;
    .end local v9    # "proxyUrl":Ljava/lang/String;
    :catch_0
    move-exception v0

    goto :goto_1

    .line 139
    :catch_1
    move-exception v0

    .line 141
    :cond_1
    :goto_0
    nop

    .line 142
    :goto_1
    return-void
.end method
