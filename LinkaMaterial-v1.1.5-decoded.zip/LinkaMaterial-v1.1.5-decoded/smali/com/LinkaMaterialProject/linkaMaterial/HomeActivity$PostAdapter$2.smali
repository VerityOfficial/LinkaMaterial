.class Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$2;
.super Ljava/lang/Object;
.source "HomeActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;->getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;

.field final synthetic val$id:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$1"    # Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 266
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$2;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$2;->val$id:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 269
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$2;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;

    iget-object v1, v1, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    const-class v2, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 270
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "post_id"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$2;->val$id:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 271
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$2;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;

    iget-object v1, v1, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->startActivity(Landroid/content/Intent;)V

    .line 272
    return-void
.end method
