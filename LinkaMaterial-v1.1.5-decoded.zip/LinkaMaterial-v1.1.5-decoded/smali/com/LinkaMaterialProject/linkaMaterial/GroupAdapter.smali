.class public Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter;
.super Landroid/widget/BaseAdapter;
.source "GroupAdapter.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter$ViewHolder;
    }
.end annotation


# instance fields
.field private context:Landroid/content/Context;

.field private groupList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/Group;",
            ">;"
        }
    .end annotation
.end field

.field private inflater:Landroid/view/LayoutInflater;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/util/List;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/Group;",
            ">;)V"
        }
    .end annotation

    .line 13
    .local p2, "groupList":Ljava/util/List;, "Ljava/util/List<Lcom/LinkaMaterialProject/linkaMaterial/Group;>;"
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 14
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter;->context:Landroid/content/Context;

    .line 15
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter;->groupList:Ljava/util/List;

    .line 16
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter;->inflater:Landroid/view/LayoutInflater;

    .line 17
    return-void
.end method


# virtual methods
.method public getCount()I
    .locals 1

    .line 19
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter;->groupList:Ljava/util/List;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter;->groupList:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .locals 1
    .param p1, "position"    # I

    .line 21
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter;->groupList:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public getItemId(I)J
    .locals 2
    .param p1, "position"    # I

    .line 23
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter;->groupList:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/LinkaMaterialProject/linkaMaterial/Group;

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/Group;->getId()I

    move-result v0

    int-to-long v0, v0

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 5
    .param p1, "position"    # I
    .param p2, "convertView"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 31
    if-nez p2, :cond_0

    .line 32
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter;->inflater:Landroid/view/LayoutInflater;

    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->item_channel:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    .line 33
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter$ViewHolder;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter$ViewHolder;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter-IA;)V

    .line 34
    .local v0, "holder":Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter$ViewHolder;
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->txtChannelName:I

    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, v0, Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter$ViewHolder;->txtGroupName:Landroid/widget/TextView;

    .line 35
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->txtChannelDescription:I

    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, v0, Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter$ViewHolder;->txtGroupPerm:Landroid/widget/TextView;

    .line 36
    invoke-virtual {p2, v0}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    goto :goto_0

    .line 38
    .end local v0    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter$ViewHolder;
    :cond_0
    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter$ViewHolder;

    .line 40
    .restart local v0    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter$ViewHolder;
    :goto_0
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter;->groupList:Ljava/util/List;

    invoke-interface {v1, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/LinkaMaterialProject/linkaMaterial/Group;

    .line 41
    .local v1, "group":Lcom/LinkaMaterialProject/linkaMaterial/Group;
    iget-object v2, v0, Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter$ViewHolder;->txtGroupName:Landroid/widget/TextView;

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/Group;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 42
    iget-object v2, v0, Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter$ViewHolder;->txtGroupPerm:Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Permiss\u00e3o: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/Group;->getPermissions()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 43
    return-object p2
.end method
