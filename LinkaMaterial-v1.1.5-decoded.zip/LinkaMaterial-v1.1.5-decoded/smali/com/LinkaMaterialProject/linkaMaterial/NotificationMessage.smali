.class public Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;
.super Ljava/lang/Object;
.source "NotificationMessage.java"


# instance fields
.field private content:Ljava/lang/String;

.field private datetime:Ljava/lang/String;

.field private fromUser:Ljava/lang/String;

.field private id:I

.field private read:I

.field private receiver:Ljava/lang/String;

.field private type:Ljava/lang/String;


# direct methods
.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .param p1, "id"    # I
    .param p2, "content"    # Ljava/lang/String;
    .param p3, "datetime"    # Ljava/lang/String;
    .param p4, "fromUser"    # Ljava/lang/String;
    .param p5, "receiver"    # Ljava/lang/String;
    .param p6, "read"    # I
    .param p7, "type"    # Ljava/lang/String;

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    iput p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;->id:I

    .line 14
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;->content:Ljava/lang/String;

    .line 15
    iput-object p3, p0, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;->datetime:Ljava/lang/String;

    .line 16
    iput-object p4, p0, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;->fromUser:Ljava/lang/String;

    .line 17
    iput-object p5, p0, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;->receiver:Ljava/lang/String;

    .line 18
    iput p6, p0, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;->read:I

    .line 19
    iput-object p7, p0, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;->type:Ljava/lang/String;

    .line 20
    return-void
.end method


# virtual methods
.method public getContent()Ljava/lang/String;
    .locals 1

    .line 23
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;->content:Ljava/lang/String;

    return-object v0
.end method

.method public getDatetime()Ljava/lang/String;
    .locals 1

    .line 24
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;->datetime:Ljava/lang/String;

    return-object v0
.end method

.method public getFromUser()Ljava/lang/String;
    .locals 1

    .line 25
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;->fromUser:Ljava/lang/String;

    return-object v0
.end method

.method public getId()I
    .locals 1

    .line 22
    iget v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;->id:I

    return v0
.end method

.method public getRead()I
    .locals 1

    .line 27
    iget v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;->read:I

    return v0
.end method

.method public getReceiver()Ljava/lang/String;
    .locals 1

    .line 26
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;->receiver:Ljava/lang/String;

    return-object v0
.end method

.method public getType()Ljava/lang/String;
    .locals 1

    .line 28
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;->type:Ljava/lang/String;

    return-object v0
.end method
