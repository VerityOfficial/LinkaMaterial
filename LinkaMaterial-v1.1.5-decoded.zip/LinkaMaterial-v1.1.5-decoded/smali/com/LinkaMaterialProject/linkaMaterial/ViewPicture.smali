.class public Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;
.super Landroid/app/Activity;
.source "ViewPicture.java"


# instance fields
.field private btnChat:Landroid/widget/ImageButton;

.field private btnDownload:Landroid/widget/Button;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;

.field private handler:Landroid/os/Handler;

.field private imageView:Landroid/widget/ImageView;


# direct methods
.method static bridge synthetic -$$Nest$fgethandler(Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;)Landroid/os/Handler;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->handler:Landroid/os/Handler;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetimageView(Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;)Landroid/widget/ImageView;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->imageView:Landroid/widget/ImageView;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$msaveImageInSd(Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;)V
    .locals 0

    invoke-direct {p0}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->saveImageInSd()V

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 16
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private saveImageInSd()V
    .locals 2

    .line 85
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->imageView:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-nez v0, :cond_0

    .line 86
    const-string v0, "Wait the image load"

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 87
    return-void

    .line 90
    :cond_0
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 128
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 129
    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 5
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 27
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 28
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->view_picture:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->setContentView(I)V

    .line 29
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->btnHome:Landroid/widget/ImageButton;

    .line 30
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->btnChat:Landroid/widget/ImageButton;

    .line 31
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->btnProfile:Landroid/widget/ImageButton;

    .line 32
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->btnOptions:Landroid/widget/ImageButton;

    .line 33
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->handler:Landroid/os/Handler;

    .line 34
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->imageView:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->imageView:Landroid/widget/ImageView;

    .line 35
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnDownload:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->btnDownload:Landroid/widget/Button;

    .line 36
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->btnHome:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$1;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 43
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->btnOptions:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$2;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 50
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->btnProfile:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$3;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 57
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->btnChat:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$4;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 64
    invoke-virtual {p0}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->getIntent()Landroid/content/Intent;

    move-result-object v0

    .line 65
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "type"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 66
    .local v1, "type":Ljava/lang/String;
    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;

    invoke-direct {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;-><init>()V

    .line 68
    .local v2, "ImageClass":Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;
    const-string v3, "profile picture"

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    .line 69
    const-string v3, "username"

    invoke-virtual {v0, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 70
    .local v3, "username":Ljava/lang/String;
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->imageView:Landroid/widget/ImageView;

    invoke-virtual {v2, p0, v3, v4}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;->viewProfilePicture(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 71
    .end local v3    # "username":Ljava/lang/String;
    goto :goto_0

    .line 72
    :cond_0
    const-string v3, "url"

    invoke-virtual {v0, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 73
    .local v3, "url":Ljava/lang/String;
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->imageView:Landroid/widget/ImageView;

    invoke-virtual {v2, v3, v4}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;->LoadImageUrl(Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 76
    .end local v3    # "url":Ljava/lang/String;
    :goto_0
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->btnDownload:Landroid/widget/Button;

    new-instance v4, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$5;

    invoke-direct {v4, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$5;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;)V

    invoke-virtual {v3, v4}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 82
    return-void
.end method
