.class Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;
.super Landroid/widget/BaseAdapter;
.source "FederationsFeed.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "PostAdapter"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;
    }
.end annotation


# instance fields
.field private final context:Landroid/content/Context;

.field private final list:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lorg/json/JSONObject;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;


# direct methods
.method public static synthetic $r8$lambda$0zRbeQYZvJZgQQeVPYBIpA6eF8M(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;Ljava/lang/String;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;->lambda$getView$1(Ljava/lang/String;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$FyCsMzD4l2Yb95JyRNzUm5es72g(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;Ljava/lang/String;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;->lambda$getView$0(Ljava/lang/String;Landroid/view/View;)V

    return-void
.end method

.method public constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;Landroid/content/Context;Ljava/util/ArrayList;)V
    .locals 0
    .param p2, "context"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/ArrayList<",
            "Lorg/json/JSONObject;",
            ">;)V"
        }
    .end annotation

    .line 335
    .local p3, "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lorg/json/JSONObject;>;"
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;

    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 336
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;->context:Landroid/content/Context;

    .line 337
    iput-object p3, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;->list:Ljava/util/ArrayList;

    .line 338
    return-void
.end method

.method private synthetic lambda$getView$0(Ljava/lang/String;Landroid/view/View;)V
    .locals 3
    .param p1, "id"    # Ljava/lang/String;
    .param p2, "v"    # Landroid/view/View;

    .line 456
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;

    const-class v2, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 461
    .local v0, "commentIntent":Landroid/content/Intent;
    const-string v1, "post_id"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 466
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->startActivity(Landroid/content/Intent;)V

    .line 467
    return-void
.end method

.method private synthetic lambda$getView$1(Ljava/lang/String;Landroid/view/View;)V
    .locals 3
    .param p1, "imageUrl"    # Ljava/lang/String;
    .param p2, "v"    # Landroid/view/View;

    .line 510
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;->context:Landroid/content/Context;

    const-class v2, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 515
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "type"

    const-string v2, "Image"

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 522
    const-string v1, "url"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 527
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;->context:Landroid/content/Context;

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 528
    return-void
.end method


# virtual methods
.method public getCount()I
    .locals 1

    .line 342
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;->list:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .locals 1
    .param p1, "position"    # I

    .line 347
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;->list:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public getItemId(I)J
    .locals 4
    .param p1, "position"    # I

    .line 352
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;->list:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/json/JSONObject;

    .line 353
    .local v0, "post":Lorg/json/JSONObject;
    const-string v1, "id"

    int-to-long v2, p1

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v1

    return-wide v1
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 11
    .param p1, "position"    # I
    .param p2, "convertView"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 374
    const-string v0, "@"

    const-string v1, ""

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez p2, :cond_0

    .line 375
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;->context:Landroid/content/Context;

    .line 376
    const-string v5, "layout_inflater"

    invoke-virtual {v4, v5}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/view/LayoutInflater;

    .line 380
    .local v4, "inflater":Landroid/view/LayoutInflater;
    sget v5, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->item_post:I

    invoke-virtual {v4, v5, p3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    .line 386
    new-instance v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;

    invoke-direct {v5, p0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed-IA;)V

    .line 388
    .local v5, "holder":Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;
    sget v6, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->postAvatar:I

    .line 389
    invoke-virtual {p2, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/ImageView;

    iput-object v6, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->avatarPost:Landroid/widget/ImageView;

    .line 393
    sget v6, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->imgPost:I

    .line 394
    invoke-virtual {p2, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/ImageView;

    iput-object v6, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->imgPost:Landroid/widget/ImageView;

    .line 398
    sget v6, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->postUsername:I

    .line 399
    invoke-virtual {p2, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    iput-object v6, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->tvUsername:Landroid/widget/TextView;

    .line 403
    sget v6, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->postText:I

    .line 404
    invoke-virtual {p2, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    iput-object v6, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->tvText:Landroid/widget/TextView;

    .line 408
    sget v6, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->postDate:I

    .line 409
    invoke-virtual {p2, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    iput-object v6, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->tvDate:Landroid/widget/TextView;

    .line 413
    sget v6, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->starCount:I

    .line 414
    invoke-virtual {p2, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    iput-object v6, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->tvStarCount:Landroid/widget/TextView;

    .line 418
    sget v6, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnComments:I

    .line 419
    invoke-virtual {p2, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/Button;

    iput-object v6, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->btnComments:Landroid/widget/Button;

    .line 423
    invoke-virtual {p2, v5}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 424
    .end local v4    # "inflater":Landroid/view/LayoutInflater;
    goto :goto_0

    .line 425
    .end local v5    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;
    :cond_0
    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v4

    move-object v5, v4

    check-cast v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;

    .line 429
    .restart local v5    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;
    :goto_0
    iget-object v4, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->imgPost:Landroid/widget/ImageView;

    invoke-virtual {v4, v3}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 430
    iget-object v4, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->imgPost:Landroid/widget/ImageView;

    const/16 v6, 0x8

    invoke-virtual {v4, v6}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 431
    iget-object v4, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->imgPost:Landroid/widget/ImageView;

    invoke-virtual {v4, v3}, Landroid/widget/ImageView;->setTag(Ljava/lang/Object;)V

    .line 432
    iget-object v4, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->imgPost:Landroid/widget/ImageView;

    invoke-virtual {v4, v3}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 435
    :try_start_0
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;->list:Ljava/util/ArrayList;

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lorg/json/JSONObject;

    .line 437
    .local v3, "post":Lorg/json/JSONObject;
    const-string v4, "username"

    const-string v6, "user"

    const-string v7, "entity404"

    .line 439
    invoke-virtual {v3, v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 437
    invoke-virtual {v3, v4, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 442
    .local v4, "user":Ljava/lang/String;
    const-string v6, "text_post"

    const-string v7, "text"

    .line 444
    invoke-virtual {v3, v7, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 442
    invoke-virtual {v3, v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 447
    .local v6, "textPost":Ljava/lang/String;
    const-string v7, "datetime"

    const-string v8, "date"

    .line 449
    invoke-virtual {v3, v8, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 447
    invoke-virtual {v3, v7, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 452
    .local v7, "datetime":Ljava/lang/String;
    const-string v8, "id"

    invoke-virtual {v3, v8, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 453
    .local v1, "id":Ljava/lang/String;
    const-string v8, "stars"

    const-string v9, "0"

    invoke-virtual {v3, v8, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 455
    .local v8, "stars":Ljava/lang/String;
    iget-object v9, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->btnComments:Landroid/widget/Button;

    new-instance v10, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$$ExternalSyntheticLambda0;

    invoke-direct {v10, p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$$ExternalSyntheticLambda0;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;Ljava/lang/String;)V

    invoke-virtual {v9, v10}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 469
    iget-object v9, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->tvUsername:Landroid/widget/TextView;

    .line 470
    invoke-virtual {v4, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_1

    move-object v0, v4

    goto :goto_1

    :cond_1
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 469
    :goto_1
    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 473
    iget-object v0, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->tvDate:Landroid/widget/TextView;

    invoke-virtual {v0, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 474
    iget-object v0, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->tvStarCount:Landroid/widget/TextView;

    invoke-virtual {v0, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 476
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;

    invoke-direct {v0}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;-><init>()V

    iget-object v9, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;->context:Landroid/content/Context;

    iget-object v10, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->avatarPost:Landroid/widget/ImageView;

    invoke-virtual {v0, v9, v4, v10}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;->viewProfilePicture(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 492
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;

    invoke-static {v0, v6}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->-$$Nest$mextractImageUrl(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 494
    .local v0, "imageUrl":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_2

    .line 495
    iget-object v9, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->imgPost:Landroid/widget/ImageView;

    invoke-virtual {v9, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 499
    iget-object v2, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->imgPost:Landroid/widget/ImageView;

    invoke-virtual {v2, v0}, Landroid/widget/ImageView;->setTag(Ljava/lang/Object;)V

    .line 501
    const-string v2, "MATERIAL_FEED"

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "[IMAGE] detectada. Original="

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, " | enviando para ImageLoader"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v2, v9}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 507
    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;

    invoke-direct {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;-><init>()V

    iget-object v9, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->imgPost:Landroid/widget/ImageView;

    invoke-virtual {v2, v0, v9}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;->LoadImageUrl(Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 509
    iget-object v2, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->imgPost:Landroid/widget/ImageView;

    new-instance v9, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$$ExternalSyntheticLambda1;

    invoke-direct {v9, p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$$ExternalSyntheticLambda1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;Ljava/lang/String;)V

    invoke-virtual {v2, v9}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 532
    :cond_2
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;

    invoke-static {v2, v6}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->-$$Nest$mremoveImageMarkers(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 534
    .end local v6    # "textPost":Ljava/lang/String;
    .local v2, "textPost":Ljava/lang/String;
    iget-object v6, v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter$ViewHolder;->tvText:Landroid/widget/TextView;

    invoke-virtual {v6, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 544
    .end local v0    # "imageUrl":Ljava/lang/String;
    .end local v1    # "id":Ljava/lang/String;
    .end local v2    # "textPost":Ljava/lang/String;
    .end local v3    # "post":Lorg/json/JSONObject;
    .end local v4    # "user":Ljava/lang/String;
    .end local v7    # "datetime":Ljava/lang/String;
    .end local v8    # "stars":Ljava/lang/String;
    goto :goto_2

    .line 536
    :catch_0
    move-exception v0

    .line 537
    .local v0, "e":Ljava/lang/Exception;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Error at position "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ": "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 542
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 537
    const-string v2, "MATERIAL_ADAPTER"

    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 546
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_2
    return-object p2
.end method
