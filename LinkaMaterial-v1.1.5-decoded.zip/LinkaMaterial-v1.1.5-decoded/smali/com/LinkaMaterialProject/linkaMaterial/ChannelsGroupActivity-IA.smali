.class public final synthetic Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
