.class public Lcom/LinkaMaterialProject/linkaMaterial/tokenManager;
.super Ljava/lang/Object;
.source "tokenManager.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static newSession(Landroid/content/Context;)Ljava/lang/String;
    .locals 22
    .param p0, "context"    # Landroid/content/Context;

    .line 16
    const-string v0, "token"

    const-string v1, "UTF-8"

    const-string v2, "password"

    const-string v3, "username"

    const-string v4, "SERVER"

    const-string v5, "FAST_LOGIN"

    const-string v6, ""

    const/4 v7, 0x0

    .line 18
    .local v7, "conn":Ljava/net/HttpURLConnection;
    :try_start_0
    new-instance v8, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v8}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 19
    .local v8, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    const-string v9, "config.cfg"
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-object/from16 v10, p0

    :try_start_1
    invoke-virtual {v8, v10, v9}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 21
    .local v9, "rawJson":Ljava/lang/String;
    if-eqz v9, :cond_6

    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    move-result v11

    if-nez v11, :cond_6

    .line 22
    new-instance v11, Lorg/json/JSONObject;

    invoke-direct {v11, v9}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 24
    .local v11, "jsonCfg":Lorg/json/JSONObject;
    invoke-virtual {v11, v5}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_6

    invoke-virtual {v11, v4}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_6

    .line 25
    invoke-virtual {v11, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    .line 26
    .local v5, "fastLogin":Lorg/json/JSONObject;
    invoke-virtual {v11, v4}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    .line 28
    .local v4, "server":Lorg/json/JSONObject;
    invoke-virtual {v5, v3, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 29
    .local v12, "username":Ljava/lang/String;
    invoke-virtual {v5, v2, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 30
    .local v13, "password":Ljava/lang/String;
    const-string v14, "url"

    const-string v15, "http://linkaProject.pythonanywhere.com"

    invoke-virtual {v4, v14, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    .line 32
    .local v14, "baseUrl":Ljava/lang/String;
    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v15

    if-nez v15, :cond_4

    invoke-virtual {v13}, Ljava/lang/String;->isEmpty()Z

    move-result v15

    if-eqz v15, :cond_0

    move-object/from16 v16, v4

    goto/16 :goto_1

    .line 36
    :cond_0
    new-instance v15, Lorg/json/JSONObject;

    invoke-direct {v15}, Lorg/json/JSONObject;-><init>()V

    .line 37
    .local v15, "jsonToken":Lorg/json/JSONObject;
    invoke-virtual {v15, v3, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 38
    invoke-virtual {v15, v2, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 40
    new-instance v2, Ljava/net/URL;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    move-object/from16 v16, v4

    .end local v4    # "server":Lorg/json/JSONObject;
    .local v16, "server":Lorg/json/JSONObject;
    const-string v4, "/new-session"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 41
    .local v2, "url":Ljava/net/URL;
    invoke-virtual {v2}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v3

    check-cast v3, Ljava/net/HttpURLConnection;

    move-object v7, v3

    .line 42
    const-string v3, "POST"

    invoke-virtual {v7, v3}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 43
    const-string v3, "Content-Type"

    const-string v4, "application/json"

    invoke-virtual {v7, v3, v4}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 44
    const/16 v3, 0x2710

    invoke-virtual {v7, v3}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    .line 45
    invoke-virtual {v7, v3}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    .line 46
    const/4 v3, 0x1

    invoke-virtual {v7, v3}, Ljava/net/HttpURLConnection;->setDoOutput(Z)V

    .line 47
    invoke-virtual {v7, v3}, Ljava/net/HttpURLConnection;->setDoInput(Z)V

    .line 49
    invoke-virtual {v7}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v3

    .line 50
    .local v3, "os":Ljava/io/OutputStream;
    invoke-virtual {v15}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/io/OutputStream;->write([B)V

    .line 51
    invoke-virtual {v3}, Ljava/io/OutputStream;->flush()V

    .line 52
    invoke-virtual {v3}, Ljava/io/OutputStream;->close()V

    .line 54
    invoke-virtual {v7}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v4

    .line 55
    .local v4, "responseCode":I
    move-object/from16 v17, v2

    .end local v2    # "url":Ljava/net/URL;
    .local v17, "url":Ljava/net/URL;
    const/16 v2, 0xc8

    if-ne v4, v2, :cond_3

    .line 56
    invoke-virtual {v7}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v2

    .line 57
    .local v2, "is":Ljava/io/InputStream;
    move-object/from16 v18, v3

    .end local v3    # "os":Ljava/io/OutputStream;
    .local v18, "os":Ljava/io/OutputStream;
    new-instance v3, Ljava/io/BufferedReader;

    move/from16 v19, v4

    .end local v4    # "responseCode":I
    .local v19, "responseCode":I
    new-instance v4, Ljava/io/InputStreamReader;

    invoke-direct {v4, v2, v1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/lang/String;)V

    invoke-direct {v3, v4}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 58
    .local v3, "reader":Ljava/io/BufferedReader;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 60
    .local v1, "sb":Ljava/lang/StringBuilder;
    :goto_0
    invoke-virtual {v3}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v4

    move-object/from16 v20, v4

    .local v20, "line":Ljava/lang/String;
    if-eqz v4, :cond_1

    .line 61
    move-object/from16 v4, v20

    .end local v20    # "line":Ljava/lang/String;
    .local v4, "line":Ljava/lang/String;
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    .line 63
    .end local v4    # "line":Ljava/lang/String;
    .restart local v20    # "line":Ljava/lang/String;
    :cond_1
    move-object/from16 v4, v20

    .end local v20    # "line":Ljava/lang/String;
    .restart local v4    # "line":Ljava/lang/String;
    invoke-virtual {v3}, Ljava/io/BufferedReader;->close()V

    .line 64
    invoke-virtual {v2}, Ljava/io/InputStream;->close()V

    .line 66
    move-object/from16 v20, v1

    .end local v1    # "sb":Ljava/lang/StringBuilder;
    .local v20, "sb":Ljava/lang/StringBuilder;
    new-instance v1, Lorg/json/JSONObject;

    move-object/from16 v21, v2

    .end local v2    # "is":Ljava/io/InputStream;
    .local v21, "is":Ljava/io/InputStream;
    invoke-virtual/range {v20 .. v20}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 67
    .local v1, "response":Lorg/json/JSONObject;
    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_6

    .line 68
    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 76
    if-eqz v7, :cond_2

    .line 77
    invoke-virtual {v7}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 68
    :cond_2
    return-object v0

    .line 55
    .end local v1    # "response":Lorg/json/JSONObject;
    .end local v18    # "os":Ljava/io/OutputStream;
    .end local v19    # "responseCode":I
    .end local v20    # "sb":Ljava/lang/StringBuilder;
    .end local v21    # "is":Ljava/io/InputStream;
    .local v3, "os":Ljava/io/OutputStream;
    .local v4, "responseCode":I
    :cond_3
    move-object/from16 v18, v3

    move/from16 v19, v4

    .end local v3    # "os":Ljava/io/OutputStream;
    .end local v4    # "responseCode":I
    .restart local v18    # "os":Ljava/io/OutputStream;
    .restart local v19    # "responseCode":I
    goto :goto_2

    .line 32
    .end local v15    # "jsonToken":Lorg/json/JSONObject;
    .end local v16    # "server":Lorg/json/JSONObject;
    .end local v17    # "url":Ljava/net/URL;
    .end local v18    # "os":Ljava/io/OutputStream;
    .end local v19    # "responseCode":I
    .local v4, "server":Lorg/json/JSONObject;
    :cond_4
    move-object/from16 v16, v4

    .line 33
    .end local v4    # "server":Lorg/json/JSONObject;
    .restart local v16    # "server":Lorg/json/JSONObject;
    :goto_1
    nop

    .line 76
    if-eqz v7, :cond_5

    .line 77
    invoke-virtual {v7}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 33
    :cond_5
    return-object v6

    .line 76
    .end local v5    # "fastLogin":Lorg/json/JSONObject;
    .end local v8    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v9    # "rawJson":Ljava/lang/String;
    .end local v11    # "jsonCfg":Lorg/json/JSONObject;
    .end local v12    # "username":Ljava/lang/String;
    .end local v13    # "password":Ljava/lang/String;
    .end local v14    # "baseUrl":Ljava/lang/String;
    .end local v16    # "server":Lorg/json/JSONObject;
    :cond_6
    :goto_2
    if-eqz v7, :cond_7

    .line 77
    :goto_3
    invoke-virtual {v7}, Ljava/net/HttpURLConnection;->disconnect()V

    goto :goto_5

    .line 73
    :catch_0
    move-exception v0

    goto :goto_4

    .line 76
    :catchall_0
    move-exception v0

    move-object/from16 v10, p0

    goto :goto_6

    .line 73
    :catch_1
    move-exception v0

    move-object/from16 v10, p0

    .line 74
    .local v0, "e":Ljava/lang/Exception;
    :goto_4
    :try_start_2
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 76
    .end local v0    # "e":Ljava/lang/Exception;
    if-eqz v7, :cond_7

    .line 77
    goto :goto_3

    .line 80
    :cond_7
    :goto_5
    return-object v6

    .line 76
    :catchall_1
    move-exception v0

    :goto_6
    if-eqz v7, :cond_8

    .line 77
    invoke-virtual {v7}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 79
    :cond_8
    goto :goto_8

    :goto_7
    throw v0

    :goto_8
    goto :goto_7
.end method

.method public static valideToken(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)Ljava/lang/String;
    .locals 17
    .param p0, "token"    # Ljava/lang/String;
    .param p1, "url"    # Ljava/lang/String;
    .param p2, "context"    # Landroid/content/Context;

    .line 84
    const/4 v1, 0x0

    .line 86
    .local v1, "conn":Ljava/net/HttpURLConnection;
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    move-object v2, v0

    .line 87
    .local v2, "valideJson":Lorg/json/JSONObject;
    const-string v0, "token"
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_6
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    move-object/from16 v3, p0

    :try_start_1
    invoke-virtual {v2, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 89
    new-instance v0, Ljava/net/URL;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_5
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    move-object/from16 v5, p1

    :try_start_2
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v6, "/valide-session"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    move-object v4, v0

    .line 90
    .local v4, "targetUrl":Ljava/net/URL;
    invoke-virtual {v4}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v0

    check-cast v0, Ljava/net/HttpURLConnection;

    move-object v1, v0

    .line 91
    const-string v0, "POST"

    invoke-virtual {v1, v0}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 92
    const-string v0, "Content-Type"

    const-string v6, "application/json"

    invoke-virtual {v1, v0, v6}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 93
    const/16 v0, 0x2710

    invoke-virtual {v1, v0}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    .line 94
    invoke-virtual {v1, v0}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    .line 95
    const/4 v0, 0x1

    invoke-virtual {v1, v0}, Ljava/net/HttpURLConnection;->setDoOutput(Z)V

    .line 96
    invoke-virtual {v1, v0}, Ljava/net/HttpURLConnection;->setDoInput(Z)V

    .line 98
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    move-object v6, v0

    .line 99
    .local v6, "os":Ljava/io/OutputStream;
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v7, "UTF-8"

    invoke-virtual {v0, v7}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/io/OutputStream;->write([B)V

    .line 100
    invoke-virtual {v6}, Ljava/io/OutputStream;->flush()V

    .line 101
    invoke-virtual {v6}, Ljava/io/OutputStream;->close()V

    .line 103
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_4
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    move v7, v0

    .line 105
    .local v7, "statusCode":I
    const/16 v0, 0xc8

    if-eq v7, v0, :cond_2

    .line 107
    :try_start_3
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v0}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    move-object v8, v0

    .line 108
    .local v8, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v0, Lorg/json/JSONObject;

    const-string v9, "config.cfg"

    move-object/from16 v10, p2

    invoke-virtual {v8, v10, v9}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-direct {v0, v9}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 109
    .local v0, "jsonCfg":Lorg/json/JSONObject;
    const-string v9, "FAST_LOGIN"

    invoke-virtual {v0, v9}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v9

    move-object v14, v9

    .line 110
    .local v14, "fastLogin":Lorg/json/JSONObject;
    const-string v9, "username"

    invoke-virtual {v14, v9}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    move-object v15, v9

    .line 111
    .local v15, "username":Ljava/lang/String;
    const-string v9, "password"

    invoke-virtual {v14, v9}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    move-object/from16 v16, v9

    .line 112
    .local v16, "password":Ljava/lang/String;
    invoke-static {v10}, Lcom/LinkaMaterialProject/linkaMaterial/tokenManager;->newSession(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v13
    :try_end_3
    .catch Lorg/json/JSONException; {:try_start_3 .. :try_end_3} :catch_2
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_4
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 113
    .end local p0    # "token":Ljava/lang/String;
    .local v13, "token":Ljava/lang/String;
    :try_start_4
    const-string v10, "config.cfg"

    const-string v11, "FAST_LOGIN"

    const-string v12, "token_session"

    move-object/from16 v9, p2

    invoke-virtual/range {v8 .. v13}, Lcom/LinkaMaterialProject/linkaMaterial/config;->updateCfg(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 114
    const-string v3, "new token has created"
    :try_end_4
    .catch Lorg/json/JSONException; {:try_start_4 .. :try_end_4} :catch_1
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 122
    if-eqz v1, :cond_0

    .line 123
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 114
    :cond_0
    return-object v3

    .line 122
    .end local v0    # "jsonCfg":Lorg/json/JSONObject;
    .end local v2    # "valideJson":Lorg/json/JSONObject;
    .end local v4    # "targetUrl":Ljava/net/URL;
    .end local v6    # "os":Ljava/io/OutputStream;
    .end local v7    # "statusCode":I
    .end local v8    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v14    # "fastLogin":Lorg/json/JSONObject;
    .end local v15    # "username":Ljava/lang/String;
    .end local v16    # "password":Ljava/lang/String;
    :catchall_0
    move-exception v0

    move-object v3, v13

    goto :goto_5

    .line 119
    :catch_0
    move-exception v0

    move-object v3, v13

    goto :goto_3

    .line 115
    .restart local v2    # "valideJson":Lorg/json/JSONObject;
    .restart local v4    # "targetUrl":Ljava/net/URL;
    .restart local v6    # "os":Ljava/io/OutputStream;
    .restart local v7    # "statusCode":I
    :catch_1
    move-exception v0

    move-object v3, v13

    goto :goto_0

    .end local v13    # "token":Ljava/lang/String;
    .restart local p0    # "token":Ljava/lang/String;
    :catch_2
    move-exception v0

    .line 116
    .end local p0    # "token":Ljava/lang/String;
    .local v0, "e":Lorg/json/JSONException;
    .local v3, "token":Ljava/lang/String;
    :goto_0
    :try_start_5
    const-string v8, "error in json parsing"
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    .line 122
    if-eqz v1, :cond_1

    .line 123
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 116
    :cond_1
    return-object v8

    .line 119
    .end local v0    # "e":Lorg/json/JSONException;
    .end local v2    # "valideJson":Lorg/json/JSONObject;
    .end local v4    # "targetUrl":Ljava/net/URL;
    .end local v6    # "os":Ljava/io/OutputStream;
    .end local v7    # "statusCode":I
    :catch_3
    move-exception v0

    goto :goto_3

    .line 122
    .end local v3    # "token":Ljava/lang/String;
    .restart local p0    # "token":Ljava/lang/String;
    :cond_2
    if-eqz v1, :cond_3

    .line 123
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    goto :goto_4

    .line 122
    :catchall_1
    move-exception v0

    goto :goto_5

    .line 119
    :catch_4
    move-exception v0

    goto :goto_3

    .line 122
    :catchall_2
    move-exception v0

    goto :goto_1

    .line 119
    :catch_5
    move-exception v0

    goto :goto_2

    .line 122
    :catchall_3
    move-exception v0

    move-object/from16 v3, p0

    :goto_1
    move-object/from16 v5, p1

    goto :goto_5

    .line 119
    :catch_6
    move-exception v0

    move-object/from16 v3, p0

    :goto_2
    move-object/from16 v5, p1

    .line 120
    .end local p0    # "token":Ljava/lang/String;
    .local v0, "e":Ljava/lang/Exception;
    .restart local v3    # "token":Ljava/lang/String;
    :goto_3
    :try_start_6
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    .line 122
    .end local v0    # "e":Ljava/lang/Exception;
    if-eqz v1, :cond_3

    .line 123
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 126
    :cond_3
    :goto_4
    const-string v0, ""

    return-object v0

    .line 122
    :catchall_4
    move-exception v0

    :goto_5
    if-eqz v1, :cond_4

    .line 123
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 125
    :cond_4
    throw v0
.end method
