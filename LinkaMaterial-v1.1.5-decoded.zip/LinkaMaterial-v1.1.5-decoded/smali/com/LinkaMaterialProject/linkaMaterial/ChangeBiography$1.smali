.class Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography$1;
.super Ljava/lang/Object;
.source "ChangeBiography.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography;

    .line 34
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 38
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 39
    .local v0, "jsonBio":Lorg/json/JSONObject;
    const-string v1, "username"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 40
    const-string v1, "mode"

    const-string v2, "bio"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 41
    const-string v1, "content"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography;->-$$Nest$fgetedtBiography(Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography;)Landroid/widget/EditText;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 42
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/edit"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "post"

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeBiography;

    invoke-static {v1, v2, v0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 46
    nop

    .end local v0    # "jsonBio":Lorg/json/JSONObject;
    goto :goto_0

    .line 44
    :catch_0
    move-exception v0

    .line 45
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 47
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_0
    return-void
.end method
