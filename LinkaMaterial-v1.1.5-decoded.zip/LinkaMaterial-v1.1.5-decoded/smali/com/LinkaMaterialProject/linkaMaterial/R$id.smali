.class public final Lcom/LinkaMaterialProject/linkaMaterial/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static ImgAvatar:I = 0x7f040000

.field public static avatar:I = 0x7f040001

.field public static bottomBar:I = 0x7f040002

.field public static btnAccept:I = 0x7f040003

.field public static btnAdd:I = 0x7f040004

.field public static btnAddMember:I = 0x7f040005

.field public static btnBack:I = 0x7f040006

.field public static btnBanUser:I = 0x7f040007

.field public static btnChangeBiography:I = 0x7f040008

.field public static btnChangeName:I = 0x7f040009

.field public static btnChangePicture:I = 0x7f04000a

.field public static btnChangeServer:I = 0x7f04000b

.field public static btnChat:I = 0x7f04000c

.field public static btnComments:I = 0x7f04000d

.field public static btnConfig:I = 0x7f04000e

.field public static btnCreate:I = 0x7f04000f

.field public static btnDenied:I = 0x7f040010

.field public static btnDownload:I = 0x7f040011

.field public static btnEdit:I = 0x7f040012

.field public static btnEmptyFederations:I = 0x7f040013

.field public static btnEnterGroup:I = 0x7f040014

.field public static btnExit:I = 0x7f040015

.field public static btnExternalServer:I = 0x7f040016

.field public static btnFederation:I = 0x7f040017

.field public static btnFooterFederations:I = 0x7f040018

.field public static btnFriendToggle:I = 0x7f040019

.field public static btnFriends:I = 0x7f04001a

.field public static btnGenerate:I = 0x7f04001b

.field public static btnGenerateInvite:I = 0x7f04001c

.field public static btnGlobalChat:I = 0x7f04001d

.field public static btnHeaderImage:I = 0x7f04001e

.field public static btnHome:I = 0x7f04001f

.field public static btnImage:I = 0x7f040020

.field public static btnInbox:I = 0x7f040021

.field public static btnLogin:I = 0x7f040022

.field public static btnNewChat:I = 0x7f040023

.field public static btnNewGroup:I = 0x7f040024

.field public static btnOptions:I = 0x7f040025

.field public static btnProfile:I = 0x7f040026

.field public static btnRegister:I = 0x7f040027

.field public static btnRemoveChannel:I = 0x7f040028

.field public static btnSend:I = 0x7f040029

.field public static btnServer:I = 0x7f04002a

.field public static bubbleContainer:I = 0x7f04002b

.field public static cardMember:I = 0x7f04002c

.field public static commentEdt:I = 0x7f04002d

.field public static commentUsername:I = 0x7f04002e

.field public static coverFederation:I = 0x7f04002f

.field public static edtBio:I = 0x7f040030

.field public static edtCode:I = 0x7f040031

.field public static edtDescription:I = 0x7f040032

.field public static edtEmail:I = 0x7f040033

.field public static edtGroupName:I = 0x7f040034

.field public static edtInputMessage:I = 0x7f040035

.field public static edtMessage:I = 0x7f040036

.field public static edtName:I = 0x7f040037

.field public static edtPassword:I = 0x7f040038

.field public static edtRetypePassword:I = 0x7f040039

.field public static edtServer:I = 0x7f04003a

.field public static edtUrl:I = 0x7f04003b

.field public static edtUsername:I = 0x7f04003c

.field public static emptyView:I = 0x7f04003d

.field public static federationsButton:I = 0x7f04003e

.field public static imageView:I = 0x7f04003f

.field public static imgAvatar:I = 0x7f040040

.field public static imgCommentAvatar:I = 0x7f040041

.field public static imgPost:I = 0x7f040042

.field public static imgProfile:I = 0x7f040043

.field public static imgProfilePicture:I = 0x7f040044

.field public static layoutMessagesContainer:I = 0x7f040045

.field public static listChannels:I = 0x7f040046

.field public static listFederations:I = 0x7f040047

.field public static listInvite:I = 0x7f040048

.field public static listViewFriends:I = 0x7f040049

.field public static listViewMembers:I = 0x7f04004a

.field public static listViewPosts:I = 0x7f04004b

.field public static lvComments:I = 0x7f04004c

.field public static lvFriends:I = 0x7f04004d

.field public static lvInbox:I = 0x7f04004e

.field public static message:I = 0x7f04004f

.field public static navigationBar:I = 0x7f040050

.field public static newPost:I = 0x7f040051

.field public static newPostContent:I = 0x7f040052

.field public static newPostText:I = 0x7f040053

.field public static newerButton:I = 0x7f040054

.field public static postAvatar:I = 0x7f040055

.field public static postDate:I = 0x7f040056

.field public static postText:I = 0x7f040057

.field public static postUsername:I = 0x7f040058

.field public static postsContainer:I = 0x7f040059

.field public static scrollMessages:I = 0x7f04005a

.field public static sendButton:I = 0x7f04005b

.field public static starCount:I = 0x7f04005c

.field public static textComment:I = 0x7f04005d

.field public static textGroup:I = 0x7f04005e

.field public static textPost:I = 0x7f04005f

.field public static tvEmptySubtitle:I = 0x7f040060

.field public static tvEmptyTitle:I = 0x7f040061

.field public static tvFooterText:I = 0x7f040062

.field public static txtBio:I = 0x7f040063

.field public static txtChannelDescription:I = 0x7f040064

.field public static txtChannelName:I = 0x7f040065

.field public static txtGoToSignin:I = 0x7f040066

.field public static txtGoToSignup:I = 0x7f040067

.field public static txtHeader:I = 0x7f040068

.field public static txtHeaderTitle:I = 0x7f040069

.field public static txtMessage:I = 0x7f04006a

.field public static txtUsername:I = 0x7f04006b

.field public static username:I = 0x7f04006c


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
