.class public final synthetic Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
