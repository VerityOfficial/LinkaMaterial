.class Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter$ViewHolder;
.super Ljava/lang/Object;
.source "ChannelAdapter.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "ViewHolder"
.end annotation


# instance fields
.field txtDescription:Landroid/widget/TextView;

.field txtName:Landroid/widget/TextView;


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 30
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter-IA;)V
    .locals 0

    invoke-direct {p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter$ViewHolder;-><init>()V

    return-void
.end method
