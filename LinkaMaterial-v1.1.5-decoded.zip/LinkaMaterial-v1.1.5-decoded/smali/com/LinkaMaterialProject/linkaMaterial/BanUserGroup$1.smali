.class Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;
.super Ljava/lang/Object;
.source "BanUserGroup.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    .line 63
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 5
    .param p2, "view"    # Landroid/view/View;
    .param p3, "position"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 66
    .local p1, "parent":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->-$$Nest$fgetfriendsList(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;

    .line 67
    .local v0, "clickedItem":Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;
    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->getUsername()Ljava/lang/String;

    move-result-object v1

    .line 69
    .local v1, "friendName":Ljava/lang/String;
    new-instance v2, Ljava/lang/Thread;

    new-instance v3, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1$1;

    invoke-direct {v3, p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;Ljava/lang/String;)V

    invoke-direct {v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 82
    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    .line 84
    new-instance v2, Landroid/content/Intent;

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    const-class v4, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 85
    .local v2, "intentRemove":Landroid/content/Intent;
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    invoke-virtual {v3, v2}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->startActivity(Landroid/content/Intent;)V

    .line 86
    return-void
.end method
