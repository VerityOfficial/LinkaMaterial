.class Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;
.super Ljava/lang/Object;
.source "BanUserGroup.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->fetchMembers()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    .line 120
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    .line 124
    const-string v0, "/members"

    const-string v1, "BanUserGroup"

    :try_start_0
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 125
    .local v2, "jsonPayload":Lorg/json/JSONObject;
    const-string v3, "username"

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->-$$Nest$fgetmyUsername(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 126
    const-string v3, "group_id"

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->-$$Nest$fgetgroupId(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)I

    move-result v4

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 128
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Enviando payload: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " para "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 130
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v3, "post"

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    invoke-static {v0, v3, v2, v4}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    .line 132
    .local v0, "response":Ljava/lang/String;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Resposta do servidor: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 134
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;

    new-instance v4, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5$1;

    invoke-direct {v4, p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;Ljava/lang/String;)V

    invoke-virtual {v3, v4}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 183
    .end local v0    # "response":Ljava/lang/String;
    .end local v2    # "jsonPayload":Lorg/json/JSONObject;
    goto :goto_0

    .line 180
    :catch_0
    move-exception v0

    .line 181
    .local v0, "e":Lorg/json/JSONException;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Erro ao criar JSON de envio: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Lorg/json/JSONException;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 182
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 184
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    return-void
.end method
