.class public Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter;
.super Landroid/widget/ArrayAdapter;
.source "CommentAdapter.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter$ViewHolder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/widget/ArrayAdapter<",
        "Lcom/LinkaMaterialProject/linkaMaterial/Comment;",
        ">;"
    }
.end annotation


# instance fields
.field private comments:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/Comment;",
            ">;"
        }
    .end annotation
.end field

.field private context:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/util/List;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/Comment;",
            ">;)V"
        }
    .end annotation

    .line 15
    .local p2, "comments":Ljava/util/List;, "Ljava/util/List<Lcom/LinkaMaterialProject/linkaMaterial/Comment;>;"
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->item_comment:I

    invoke-direct {p0, p1, v0, p2}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    .line 16
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter;->context:Landroid/content/Context;

    .line 17
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter;->comments:Ljava/util/List;

    .line 18
    return-void
.end method


# virtual methods
.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 5
    .param p1, "position"    # I
    .param p2, "convertView"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 28
    if-nez p2, :cond_0

    .line 29
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter;->context:Landroid/content/Context;

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    .line 30
    .local v0, "inflater":Landroid/view/LayoutInflater;
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->item_comment:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    .line 31
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter$ViewHolder;

    invoke-direct {v1}, Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter$ViewHolder;-><init>()V

    .line 32
    .local v1, "holder":Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter$ViewHolder;
    sget v2, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->imgCommentAvatar:I

    invoke-virtual {p2, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    iput-object v2, v1, Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter$ViewHolder;->imgAvatar:Landroid/widget/ImageView;

    .line 33
    sget v2, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->commentUsername:I

    invoke-virtual {p2, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, v1, Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter$ViewHolder;->tvUsername:Landroid/widget/TextView;

    .line 34
    sget v2, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->textComment:I

    invoke-virtual {p2, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, v1, Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter$ViewHolder;->tvText:Landroid/widget/TextView;

    .line 35
    invoke-virtual {p2, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 36
    .end local v0    # "inflater":Landroid/view/LayoutInflater;
    goto :goto_0

    .line 37
    .end local v1    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter$ViewHolder;
    :cond_0
    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter$ViewHolder;

    .line 39
    .restart local v1    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter$ViewHolder;
    :goto_0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter;->comments:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/LinkaMaterialProject/linkaMaterial/Comment;

    .line 41
    .local v0, "comment":Lcom/LinkaMaterialProject/linkaMaterial/Comment;
    iget-object v2, v1, Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter$ViewHolder;->tvUsername:Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "@"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/Comment;->getUsername()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 42
    iget-object v2, v1, Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter$ViewHolder;->tvText:Landroid/widget/TextView;

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/Comment;->getTextComment()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 43
    return-object p2
.end method
