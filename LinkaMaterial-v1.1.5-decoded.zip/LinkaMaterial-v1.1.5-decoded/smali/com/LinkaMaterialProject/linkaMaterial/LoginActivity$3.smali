.class Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$3;
.super Ljava/lang/Object;
.source "LoginActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    .line 113
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 5
    .param p1, "v"    # Landroid/view/View;

    .line 116
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->-$$Nest$fgetedtUsername(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 117
    .local v0, "username":Ljava/lang/String;
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->-$$Nest$fgetedtPassword(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;)Landroid/widget/EditText;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 118
    .local v1, "password":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_0

    .line 121
    :cond_0
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-static {v2, v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->-$$Nest$mexecuteLogin(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_1

    .line 119
    :cond_1
    :goto_0
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    const-string v3, "fill all the fields"

    const/4 v4, 0x0

    invoke-static {v2, v3, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 123
    :goto_1
    return-void
.end method
