.class Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchMembersTask;
.super Landroid/os/AsyncTask;
.source "RemoveGroupChannel.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "FetchMembersTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/Void;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;


# direct methods
.method private constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)V
    .locals 0

    .line 118
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchMembersTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchMembersTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)V

    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 118
    check-cast p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchMembersTask;->doInBackground([Ljava/lang/Void;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/Void;)Ljava/lang/String;
    .locals 4
    .param p1, "params"    # [Ljava/lang/Void;

    .line 122
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 123
    .local v0, "jsonMembers":Lorg/json/JSONObject;
    const-string v1, "username"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchMembersTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 124
    const-string v1, "group_id"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchMembersTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fgetgroupId(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 125
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchMembersTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/members"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "POST"

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchMembersTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v1, v2, v0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    .line 126
    .end local v0    # "jsonMembers":Lorg/json/JSONObject;
    :catch_0
    move-exception v0

    .line 127
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 128
    const/4 v1, 0x0

    return-object v1
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 118
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchMembersTask;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 8
    .param p1, "result"    # Ljava/lang/String;

    .line 134
    if-eqz p1, :cond_2

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_2

    .line 138
    :cond_0
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 139
    .local v0, "jsonObject":Lorg/json/JSONObject;
    const-string v1, "members"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    .line 140
    .local v1, "membersArray":Lorg/json/JSONArray;
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 142
    .local v2, "memberList":Ljava/util/List;, "Ljava/util/List<Lcom/LinkaMaterialProject/linkaMaterial/Member;>;"
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_0
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v4

    if-ge v3, v4, :cond_1

    .line 143
    invoke-virtual {v1, v3}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v4

    .line 144
    .local v4, "memberName":Ljava/lang/String;
    new-instance v5, Landroid/widget/ImageView;

    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchMembersTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-direct {v5, v6}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 145
    .local v5, "imageView":Landroid/widget/ImageView;
    new-instance v6, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;

    invoke-direct {v6}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;-><init>()V

    .line 146
    .local v6, "imageLoader":Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;
    iget-object v7, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchMembersTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-virtual {v6, v7, v4, v5}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;->viewProfilePicture(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 148
    new-instance v7, Lcom/LinkaMaterialProject/linkaMaterial/Member;

    invoke-direct {v7, v4, v5}, Lcom/LinkaMaterialProject/linkaMaterial/Member;-><init>(Ljava/lang/String;Landroid/widget/ImageView;)V

    invoke-interface {v2, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 142
    nop

    .end local v4    # "memberName":Ljava/lang/String;
    .end local v5    # "imageView":Landroid/widget/ImageView;
    .end local v6    # "imageLoader":Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 151
    .end local v3    # "i":I
    :cond_1
    new-instance v3, Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter;

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchMembersTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-direct {v3, v4, v2}, Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter;-><init>(Landroid/content/Context;Ljava/util/List;)V

    .line 152
    .local v3, "memberAdapter":Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter;
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel$FetchMembersTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;->-$$Nest$fgetlistViewMembers(Lcom/LinkaMaterialProject/linkaMaterial/RemoveGroupChannel;)Landroid/widget/ListView;

    move-result-object v4

    invoke-virtual {v4, v3}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 155
    .end local v0    # "jsonObject":Lorg/json/JSONObject;
    .end local v1    # "membersArray":Lorg/json/JSONArray;
    .end local v2    # "memberList":Ljava/util/List;, "Ljava/util/List<Lcom/LinkaMaterialProject/linkaMaterial/Member;>;"
    .end local v3    # "memberAdapter":Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter;
    goto :goto_1

    .line 153
    :catch_0
    move-exception v0

    .line 154
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 156
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_1
    return-void

    .line 135
    :cond_2
    :goto_2
    return-void
.end method
