.class Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$FetchMessagesTask;
.super Landroid/os/AsyncTask;
.source "ChatGlobalActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "FetchMessagesTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/Void;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;


# direct methods
.method private constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)V
    .locals 0

    .line 89
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$FetchMessagesTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)V

    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 89
    check-cast p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$FetchMessagesTask;->doInBackground([Ljava/lang/Void;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/Void;)Ljava/lang/String;
    .locals 6
    .param p1, "params"    # [Ljava/lang/Void;

    .line 93
    const/4 v0, 0x0

    :try_start_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/view-global-message"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 94
    .local v1, "fullUrl":Ljava/lang/String;
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_1

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_0

    .line 95
    :cond_0
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 96
    .local v2, "json_chat":Lorg/json/JSONObject;
    const-string v3, "id"

    const/4 v4, 0x0

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 97
    const-string v3, "post"

    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    invoke-static {v1, v3, v2, v4, v5}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;ILandroid/content/Context;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 94
    .end local v2    # "json_chat":Lorg/json/JSONObject;
    :cond_1
    :goto_0
    return-object v0

    .line 98
    .end local v1    # "fullUrl":Ljava/lang/String;
    :catch_0
    move-exception v1

    .line 99
    .local v1, "e":Ljava/lang/Exception;
    const-string v2, "MATERIAL_DEBUG"

    const-string v3, "Exception in FetchMessagesTask"

    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 100
    return-object v0
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 89
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$FetchMessagesTask;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 9
    .param p1, "response"    # Ljava/lang/String;

    .line 105
    if-eqz p1, :cond_3

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_3

    .line 107
    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->-$$Nest$fgetchatContainer(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 108
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0, p1}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    .line 109
    .local v0, "jsonArray":Lorg/json/JSONArray;
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge v1, v2, :cond_2

    .line 110
    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    .line 111
    .local v2, "obj":Lorg/json/JSONObject;
    const-string v3, "message"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 112
    .local v3, "text":Ljava/lang/String;
    const-string v4, "sender"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 113
    .local v4, "sender":Ljava/lang/String;
    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    invoke-static {v5}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    .line 114
    .local v5, "isMe":Z
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_1

    move-object v6, v3

    goto :goto_1

    :cond_1
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, ": "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 115
    .local v6, "displayText":Ljava/lang/String;
    :goto_1
    new-instance v7, Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;

    iget-object v8, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    invoke-direct {v7, v8, v6, v5}, Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;-><init>(Landroid/content/Context;Ljava/lang/String;Z)V

    .line 116
    .local v7, "bubble":Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;
    iget-object v8, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$FetchMessagesTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    invoke-static {v8}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->-$$Nest$fgetchatContainer(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)Landroid/widget/LinearLayout;

    move-result-object v8

    invoke-virtual {v8, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 109
    .end local v2    # "obj":Lorg/json/JSONObject;
    .end local v3    # "text":Ljava/lang/String;
    .end local v4    # "sender":Ljava/lang/String;
    .end local v5    # "isMe":Z
    .end local v6    # "displayText":Ljava/lang/String;
    .end local v7    # "bubble":Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 120
    .end local v0    # "jsonArray":Lorg/json/JSONArray;
    .end local v1    # "i":I
    :cond_2
    goto :goto_2

    .line 118
    :catch_0
    move-exception v0

    .line 119
    .local v0, "e":Lorg/json/JSONException;
    const-string v1, "MATERIAL_DEBUG"

    const-string v2, "JSON parsing error"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 121
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_2
    return-void

    .line 105
    :cond_3
    :goto_3
    return-void
.end method
