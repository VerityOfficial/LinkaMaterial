.class public final synthetic Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
