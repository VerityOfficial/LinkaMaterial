.class Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter$ViewHolder;
.super Ljava/lang/Object;
.source "CommentAdapter.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/CommentAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "ViewHolder"
.end annotation


# instance fields
.field imgAvatar:Landroid/widget/ImageView;

.field tvText:Landroid/widget/TextView;

.field tvUsername:Landroid/widget/TextView;


# direct methods
.method constructor <init>()V
    .locals 0

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
