.class Lcom/LinkaMaterialProject/linkaMaterial/profile$5;
.super Ljava/lang/Object;
.source "profile.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/profile;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/profile;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/profile;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/profile;

    .line 105
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/profile;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 7
    .param p1, "v"    # Landroid/view/View;

    .line 108
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v0}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    move-object v1, v0

    .line 109
    .local v1, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/profile;

    const-string v5, "username"

    const-string v6, ""

    const-string v3, "config.cfg"

    const-string v4, "FAST_LOGIN"

    invoke-virtual/range {v1 .. v6}, Lcom/LinkaMaterialProject/linkaMaterial/config;->updateCfg(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 110
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/profile;

    const-string v5, "password"

    const-string v6, ""

    const-string v3, "config.cfg"

    const-string v4, "FAST_LOGIN"

    invoke-virtual/range {v1 .. v6}, Lcom/LinkaMaterialProject/linkaMaterial/config;->updateCfg(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 111
    new-instance v0, Landroid/content/Intent;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/profile;

    const-class v3, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-direct {v0, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 112
    .local v0, "intent":Landroid/content/Intent;
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/profile;

    invoke-virtual {v2, v0}, Lcom/LinkaMaterialProject/linkaMaterial/profile;->startActivity(Landroid/content/Intent;)V

    .line 113
    return-void
.end method
