.class Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;
.super Landroid/os/AsyncTask;
.source "ChannelsGroupActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "FetchChannelsTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/Void;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;


# direct methods
.method private constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)V
    .locals 0

    .line 184
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)V

    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 184
    check-cast p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->doInBackground([Ljava/lang/Void;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/Void;)Ljava/lang/String;
    .locals 4
    .param p1, "params"    # [Ljava/lang/Void;

    .line 188
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 189
    .local v0, "jsonChannels":Lorg/json/JSONObject;
    const-string v1, "username"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 190
    const-string v1, "group_id"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->-$$Nest$fgetgroupId(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 191
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/view-channels"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "POST"

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-static {v1, v2, v0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    .line 192
    .end local v0    # "jsonChannels":Lorg/json/JSONObject;
    :catch_0
    move-exception v0

    .line 193
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 194
    const/4 v1, 0x0

    return-object v1
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 184
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 7
    .param p1, "result"    # Ljava/lang/String;

    .line 200
    if-eqz p1, :cond_2

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_2

    .line 205
    :cond_0
    :try_start_0
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0, p1}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    .line 206
    .local v0, "array":Lorg/json/JSONArray;
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->-$$Nest$fgetchannelList(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->clear()V

    .line 207
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge v1, v2, :cond_1

    .line 208
    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    .line 209
    .local v2, "obj":Lorg/json/JSONObject;
    const-string v3, "channel_name"

    const-string v4, "Geral"

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 210
    .local v3, "channelName":Ljava/lang/String;
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->-$$Nest$fgetchannelList(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)Ljava/util/List;

    move-result-object v4

    new-instance v5, Lcom/LinkaMaterialProject/linkaMaterial/Channel;

    const-string v6, "C"

    invoke-direct {v5, v3, v6}, Lcom/LinkaMaterialProject/linkaMaterial/Channel;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 207
    nop

    .end local v2    # "obj":Lorg/json/JSONObject;
    .end local v3    # "channelName":Ljava/lang/String;
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 212
    .end local v1    # "i":I
    :cond_1
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->-$$Nest$fgetchannelList(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)Ljava/util/List;

    move-result-object v4

    invoke-direct {v2, v3, v4}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;-><init>(Landroid/content/Context;Ljava/util/List;)V

    invoke-static {v1, v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->-$$Nest$fputadapter(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;)V

    .line 213
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->-$$Nest$fgetlistChannelsView(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)Landroid/widget/ListView;

    move-result-object v1

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->-$$Nest$fgetadapter(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 214
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->-$$Nest$fgetlistChannelsView(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)Landroid/widget/ListView;

    move-result-object v1

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask$1;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;)V

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 226
    .end local v0    # "array":Lorg/json/JSONArray;
    goto :goto_1

    .line 224
    :catch_0
    move-exception v0

    .line 225
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 227
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_1
    return-void

    .line 201
    :cond_2
    :goto_2
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    const-string v1, "Erro ao carregar canais"

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 202
    return-void
.end method
