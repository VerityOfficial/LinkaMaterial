.class public Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;
.super Landroid/app/Activity;
.source "ExternalChat.java"


# instance fields
.field private btnAdd:Landroid/widget/Button;

.field private btnChat:Landroid/widget/ImageButton;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;

.field private edtUrl:Landroid/widget/EditText;

.field private edtUsername:Landroid/widget/EditText;

.field private url:Ljava/lang/String;

.field private username:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetedtUrl(Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->edtUrl:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetedtUsername(Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->edtUsername:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->url:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->username:Ljava/lang/String;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 1

    .line 31
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 32
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->username:Ljava/lang/String;

    .line 33
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->url:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 6
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 43
    const-string v0, ""

    :try_start_0
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v1}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 44
    .local v1, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v2, Lorg/json/JSONObject;

    const-string v3, "config.cfg"

    invoke-virtual {v1, p0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 45
    .local v2, "jsonCfg":Lorg/json/JSONObject;
    const-string v3, "FAST_LOGIN"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    .line 46
    .local v3, "fastLogin":Lorg/json/JSONObject;
    const-string v4, "SERVER"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    .line 47
    .local v4, "server":Lorg/json/JSONObject;
    const-string v5, "url"

    invoke-virtual {v4, v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->url:Ljava/lang/String;

    .line 48
    const-string v5, "username"

    invoke-virtual {v3, v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->username:Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 51
    .end local v1    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v2    # "jsonCfg":Lorg/json/JSONObject;
    .end local v3    # "fastLogin":Lorg/json/JSONObject;
    .end local v4    # "server":Lorg/json/JSONObject;
    goto :goto_0

    .line 49
    :catch_0
    move-exception v0

    .line 50
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 52
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 53
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->external_chat:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->setContentView(I)V

    .line 54
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtUrl:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->edtUrl:Landroid/widget/EditText;

    .line 55
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtUsername:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->edtUsername:Landroid/widget/EditText;

    .line 56
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnAdd:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->btnAdd:Landroid/widget/Button;

    .line 57
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->btnHome:Landroid/widget/ImageButton;

    .line 58
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->btnChat:Landroid/widget/ImageButton;

    .line 59
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->btnOptions:Landroid/widget/ImageButton;

    .line 60
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->btnProfile:Landroid/widget/ImageButton;

    .line 61
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->btnAdd:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$1;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 79
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->btnHome:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$2;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 86
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->btnOptions:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$3;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 93
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->btnProfile:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$4;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 100
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->btnChat:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$5;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$5;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 107
    return-void
.end method
