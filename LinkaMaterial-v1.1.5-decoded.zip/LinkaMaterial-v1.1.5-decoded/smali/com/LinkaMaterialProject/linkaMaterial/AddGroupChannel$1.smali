.class Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel$1;
.super Ljava/lang/Object;
.source "AddGroupChannel.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;

    .line 36
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 6
    .param p1, "v"    # Landroid/view/View;

    .line 40
    const-string v0, "group_id"

    :try_start_0
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->getIntent()Landroid/content/Intent;

    move-result-object v1

    .line 41
    .local v1, "GetIntent":Landroid/content/Intent;
    const/4 v2, -0x1

    invoke-virtual {v1, v0, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v2

    .line 42
    .local v2, "group_id":I
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    .line 43
    .local v3, "jsonAdd":Lorg/json/JSONObject;
    const-string v4, "username"

    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;

    invoke-static {v5}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 44
    const-string v4, "channel_name"

    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;

    invoke-static {v5}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->-$$Nest$fgetedtName(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;)Landroid/widget/EditText;

    move-result-object v5

    invoke-virtual {v5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 45
    invoke-virtual {v3, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 46
    const-string v0, "type"

    const-string v4, "chat"

    invoke-virtual {v3, v0, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 47
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v4, "/new-channel"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v4, "post"

    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;

    invoke-static {v0, v4, v3, v5}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    .line 48
    new-instance v0, Landroid/content/Intent;

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;

    const-class v5, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-direct {v0, v4, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 49
    .local v0, "intent":Landroid/content/Intent;
    const-string v4, "groupId"

    invoke-virtual {v0, v4, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 50
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;

    invoke-virtual {v4, v0}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupChannel;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 53
    .end local v0    # "intent":Landroid/content/Intent;
    .end local v1    # "GetIntent":Landroid/content/Intent;
    .end local v2    # "group_id":I
    .end local v3    # "jsonAdd":Lorg/json/JSONObject;
    goto :goto_0

    .line 51
    :catch_0
    move-exception v0

    .line 52
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 54
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    return-void
.end method
