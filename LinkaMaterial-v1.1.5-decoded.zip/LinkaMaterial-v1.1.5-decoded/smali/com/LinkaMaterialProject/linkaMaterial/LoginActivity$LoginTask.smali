.class Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;
.super Landroid/os/AsyncTask;
.source "LoginActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "LoginTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/String;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field private attemptedPassword:Ljava/lang/String;

.field private attemptedUsername:Ljava/lang/String;

.field private progressDialog:Landroid/app/ProgressDialog;

.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;


# direct methods
.method private constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;)V
    .locals 0

    .line 144
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;)V

    return-void
.end method


# virtual methods
.method public dismissDialogSafely()V
    .locals 3

    .line 283
    :try_start_0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->progressDialog:Landroid/app/ProgressDialog;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->progressDialog:Landroid/app/ProgressDialog;

    invoke-virtual {v0}, Landroid/app/ProgressDialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 284
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->progressDialog:Landroid/app/ProgressDialog;

    invoke-virtual {v0}, Landroid/app/ProgressDialog;->dismiss()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 288
    :cond_0
    goto :goto_0

    .line 286
    :catch_0
    move-exception v0

    .line 287
    .local v0, "e":Ljava/lang/Exception;
    const-string v1, "LinkaMaterialLogin"

    const-string v2, "Error dismissing progress dialog"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 289
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_0
    return-void
.end method

.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 144
    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->doInBackground([Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/String;)Ljava/lang/String;
    .locals 17
    .param p1, "params"    # [Ljava/lang/String;

    .line 162
    move-object/from16 v1, p0

    const-string v0, "UTF-8"

    const-string v2, "LinkaMaterialLogin"

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->isCancelled()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_0

    return-object v4

    .line 164
    :cond_0
    const/4 v3, 0x0

    aget-object v5, p1, v3

    iput-object v5, v1, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->attemptedUsername:Ljava/lang/String;

    .line 165
    const/4 v5, 0x1

    aget-object v6, p1, v5

    iput-object v6, v1, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->attemptedPassword:Ljava/lang/String;

    .line 166
    const/4 v6, 0x0

    .line 169
    .local v6, "connection":Ljava/net/HttpURLConnection;
    :try_start_0
    iget-object v7, v1, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-static {v7}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->-$$Nest$fgetserverUrl(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    .line 170
    .local v7, "baseUrl":Ljava/lang/String;
    const-string v8, "/"

    invoke-virtual {v7, v8}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_1

    .line 171
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    sub-int/2addr v8, v5

    invoke-virtual {v7, v3, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    move-object v7, v3

    .line 174
    :cond_1
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v8, "/login"

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 175
    .local v3, "targetUrl":Ljava/lang/String;
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "Iniciando conex\u00e3o HTTP POST para: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v2, v8}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 177
    new-instance v8, Ljava/net/URL;

    invoke-direct {v8, v3}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 178
    .local v8, "url":Ljava/net/URL;
    invoke-virtual {v8}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v9

    check-cast v9, Ljava/net/HttpURLConnection;

    move-object v6, v9

    .line 179
    const-string v9, "POST"

    invoke-virtual {v6, v9}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 181
    const-string v9, "User-Agent"

    const-string v10, "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"

    invoke-virtual {v6, v9, v10}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 182
    const-string v9, "Content-Type"

    const-string v10, "application/json; charset=UTF-8"

    invoke-virtual {v6, v9, v10}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 183
    const-string v9, "Accept"

    const-string v10, "application/json"

    invoke-virtual {v6, v9, v10}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 184
    const-string v9, "Connection"

    const-string v10, "close"

    invoke-virtual {v6, v9, v10}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 185
    const/16 v9, 0x2710

    invoke-virtual {v6, v9}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    .line 186
    invoke-virtual {v6, v9}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    .line 187
    invoke-virtual {v6, v5}, Ljava/net/HttpURLConnection;->setDoOutput(Z)V

    .line 189
    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5}, Lorg/json/JSONObject;-><init>()V

    .line 190
    .local v5, "jsonParam":Lorg/json/JSONObject;
    const-string v9, "username"

    iget-object v10, v1, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->attemptedUsername:Ljava/lang/String;

    invoke-virtual {v5, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 191
    const-string v9, "password"

    iget-object v10, v1, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->attemptedPassword:Ljava/lang/String;

    invoke-virtual {v5, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 193
    invoke-virtual {v5}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v9

    .line 194
    .local v9, "postData":[B
    const-string v10, "Content-Length"

    array-length v11, v9

    invoke-static {v11}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v6, v10, v11}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 196
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "Enviando Payload JSON: "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v5}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v2, v10}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 198
    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v10

    .line 199
    .local v10, "os":Ljava/io/OutputStream;
    invoke-virtual {v10, v9}, Ljava/io/OutputStream;->write([B)V

    .line 200
    invoke-virtual {v10}, Ljava/io/OutputStream;->flush()V

    .line 201
    invoke-virtual {v10}, Ljava/io/OutputStream;->close()V

    .line 203
    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v11

    .line 204
    .local v11, "responseCode":I
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "C\u00f3digo de Resposta HTTP recebido: "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-static {v2, v12}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 206
    const/16 v12, 0xc8

    if-lt v11, v12, :cond_2

    const/16 v12, 0x12c

    if-ge v11, v12, :cond_2

    .line 207
    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v12

    goto :goto_0

    .line 208
    :cond_2
    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->getErrorStream()Ljava/io/InputStream;

    move-result-object v12

    :goto_0
    nop

    .line 210
    .local v12, "stream":Ljava/io/InputStream;
    if-eqz v12, :cond_6

    .line 211
    new-instance v13, Ljava/io/BufferedReader;

    new-instance v14, Ljava/io/InputStreamReader;

    invoke-direct {v14, v12, v0}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/lang/String;)V

    invoke-direct {v13, v14}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 212
    .local v13, "in":Ljava/io/BufferedReader;
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 214
    .local v0, "response":Ljava/lang/StringBuilder;
    :goto_1
    invoke-virtual {v13}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v14

    move-object v15, v14

    .local v15, "line":Ljava/lang/String;
    if-eqz v14, :cond_4

    .line 215
    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->isCancelled()Z

    move-result v14

    if-eqz v14, :cond_3

    goto :goto_2

    .line 216
    :cond_3
    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    .line 218
    :cond_4
    :goto_2
    invoke-virtual {v13}, Ljava/io/BufferedReader;->close()V

    .line 219
    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-object/from16 v16, v4

    :try_start_1
    const-string v4, "Resposta bruta do servidor: "

    invoke-virtual {v14, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v4, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 220
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 229
    if-eqz v6, :cond_5

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 220
    :cond_5
    return-object v2

    .line 222
    .end local v0    # "response":Ljava/lang/StringBuilder;
    .end local v13    # "in":Ljava/io/BufferedReader;
    .end local v15    # "line":Ljava/lang/String;
    :cond_6
    move-object/from16 v16, v4

    :try_start_2
    const-string v0, "InputStream e ErrorStream vieram nulos do servidor."

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 229
    nop

    .end local v3    # "targetUrl":Ljava/lang/String;
    .end local v5    # "jsonParam":Lorg/json/JSONObject;
    .end local v7    # "baseUrl":Ljava/lang/String;
    .end local v8    # "url":Ljava/net/URL;
    .end local v9    # "postData":[B
    .end local v10    # "os":Ljava/io/OutputStream;
    .end local v11    # "responseCode":I
    .end local v12    # "stream":Ljava/io/InputStream;
    if-eqz v6, :cond_7

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 231
    :cond_7
    return-object v16

    .line 225
    :catch_0
    move-exception v0

    goto :goto_3

    .line 229
    :catchall_0
    move-exception v0

    goto :goto_4

    .line 225
    :catch_1
    move-exception v0

    move-object/from16 v16, v4

    .line 226
    .local v0, "e":Ljava/lang/Exception;
    :goto_3
    :try_start_3
    const-string v3, "EXCE\u00c7\u00c3O DURANTE O REQUEST HTTP: "

    invoke-static {v2, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 227
    nop

    .line 229
    if-eqz v6, :cond_8

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 227
    :cond_8
    return-object v16

    .line 229
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_4
    if-eqz v6, :cond_9

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 230
    :cond_9
    goto :goto_6

    :goto_5
    throw v0

    :goto_6
    goto :goto_5
.end method

.method protected onCancelled()V
    .locals 0

    .line 278
    invoke-virtual {p0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->dismissDialogSafely()V

    .line 279
    return-void
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 144
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 11
    .param p1, "result"    # Ljava/lang/String;

    .line 236
    invoke-virtual {p0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->dismissDialogSafely()V

    .line 237
    invoke-virtual {p0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->isCancelled()Z

    move-result v0

    if-nez v0, :cond_4

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->isFinishing()Z

    move-result v0

    if-eqz v0, :cond_0

    goto/16 :goto_3

    .line 239
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "onPostExecute chamado com resultado: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "LinkaMaterialLogin"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 241
    const/4 v2, 0x0

    if-eqz p1, :cond_3

    .line 243
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 244
    .local v0, "responseJson":Lorg/json/JSONObject;
    const-string v3, "status"

    const-string v4, ""

    invoke-virtual {v0, v3, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 245
    .local v3, "status":Ljava/lang/String;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Status extra\u00eddo do JSON: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v1, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 247
    const-string v4, "login is sucessful"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_2

    const-string v4, "login is successful"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_2

    const-string v4, "success"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1

    goto :goto_0

    .line 263
    :cond_1
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Login recusado pelo backend. Status: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v1, v4}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 264
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    const-string v5, "Username or password incorrect!"

    const/4 v6, 0x1

    invoke-static {v4, v5, v6}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v4

    invoke-virtual {v4}, Landroid/widget/Toast;->show()V

    goto/16 :goto_1

    .line 249
    :cond_2
    :goto_0
    new-instance v4, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v4}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    move-object v5, v4

    .line 250
    .local v5, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    const-string v7, "config.cfg"

    const-string v8, "FAST_LOGIN"

    const-string v9, "username"

    iget-object v10, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->attemptedUsername:Ljava/lang/String;

    invoke-virtual/range {v5 .. v10}, Lcom/LinkaMaterialProject/linkaMaterial/config;->updateCfg(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 251
    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    const-string v7, "config.cfg"

    const-string v8, "FAST_LOGIN"

    const-string v9, "password"

    iget-object v10, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->attemptedPassword:Ljava/lang/String;

    invoke-virtual/range {v5 .. v10}, Lcom/LinkaMaterialProject/linkaMaterial/config;->updateCfg(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 254
    const-string v4, "Gerando nova sess\u00e3o no TokenManager..."

    invoke-static {v1, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 255
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/tokenManager;->newSession(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v10

    .line 256
    .local v10, "newToken":Ljava/lang/String;
    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    const-string v7, "config.cfg"

    const-string v8, "FAST_LOGIN"

    const-string v9, "token_session"

    invoke-virtual/range {v5 .. v10}, Lcom/LinkaMaterialProject/linkaMaterial/config;->updateCfg(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 258
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    const-string v6, "Login successful!"

    invoke-static {v4, v6, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v4

    invoke-virtual {v4}, Landroid/widget/Toast;->show()V

    .line 259
    new-instance v4, Landroid/content/Intent;

    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    const-class v7, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    invoke-direct {v4, v6, v7}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 260
    .local v4, "intent":Landroid/content/Intent;
    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-virtual {v6, v4}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->startActivity(Landroid/content/Intent;)V

    .line 261
    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-virtual {v6}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->finish()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 262
    .end local v4    # "intent":Landroid/content/Intent;
    .end local v5    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v10    # "newToken":Ljava/lang/String;
    goto :goto_1

    .line 266
    .end local v0    # "responseJson":Lorg/json/JSONObject;
    .end local v3    # "status":Ljava/lang/String;
    :catch_0
    move-exception v0

    .line 267
    .local v0, "e":Ljava/lang/Exception;
    const-string v3, "EXCE\u00c7\u00c3O AO PROCESSAR O JSON NO ONPOSTEXECUTE: "

    invoke-static {v1, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 268
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Error processing data: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 269
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_1
    goto :goto_2

    .line 271
    :cond_3
    const-string v0, "Resultado nulo recebido em onPostExecute. Conex\u00e3o falhou completamente."

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 272
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    const-string v1, "Connection with server failed"

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 274
    :goto_2
    return-void

    .line 237
    :cond_4
    :goto_3
    return-void
.end method

.method protected onPreExecute()V
    .locals 2

    .line 151
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_0

    .line 152
    new-instance v0, Landroid/app/ProgressDialog;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-direct {v0, v1}, Landroid/app/ProgressDialog;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->progressDialog:Landroid/app/ProgressDialog;

    .line 153
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->progressDialog:Landroid/app/ProgressDialog;

    const-string v1, "Wait"

    invoke-virtual {v0, v1}, Landroid/app/ProgressDialog;->setTitle(Ljava/lang/CharSequence;)V

    .line 154
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->progressDialog:Landroid/app/ProgressDialog;

    const-string v1, "Login..."

    invoke-virtual {v0, v1}, Landroid/app/ProgressDialog;->setMessage(Ljava/lang/CharSequence;)V

    .line 155
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->progressDialog:Landroid/app/ProgressDialog;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/app/ProgressDialog;->setCancelable(Z)V

    .line 156
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->progressDialog:Landroid/app/ProgressDialog;

    invoke-virtual {v0}, Landroid/app/ProgressDialog;->show()V

    .line 158
    :cond_0
    return-void
.end method
