.class public Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;
.super Landroid/app/Activity;
.source "ConfigGroup.java"


# instance fields
.field private btnBanUser:Landroid/widget/Button;

.field private btnChangeName:Landroid/widget/Button;

.field private btnChat:Landroid/widget/ImageButton;

.field private btnExit:Landroid/widget/Button;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;

.field private btnRemoveChannel:Landroid/widget/Button;

.field private groupId:I

.field private url:Ljava/lang/String;

.field private username:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetgroupId(Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;)I
    .locals 0

    iget p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->groupId:I

    return p0
.end method

.method static bridge synthetic -$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->url:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->username:Ljava/lang/String;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 1

    .line 22
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 26
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->username:Ljava/lang/String;

    .line 27
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->url:Ljava/lang/String;

    .line 28
    const/4 v0, -0x1

    iput v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->groupId:I

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 7
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 35
    const-string v0, ""

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 36
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->config_group:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->setContentView(I)V

    .line 37
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->btnHome:Landroid/widget/ImageButton;

    .line 38
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->btnChat:Landroid/widget/ImageButton;

    .line 39
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->btnOptions:Landroid/widget/ImageButton;

    .line 40
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->btnProfile:Landroid/widget/ImageButton;

    .line 41
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnBanUser:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->btnBanUser:Landroid/widget/Button;

    .line 42
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChangeName:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->btnChangeName:Landroid/widget/Button;

    .line 43
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnExit:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->btnExit:Landroid/widget/Button;

    .line 44
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnRemoveChannel:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->btnRemoveChannel:Landroid/widget/Button;

    .line 45
    invoke-virtual {p0}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->getIntent()Landroid/content/Intent;

    move-result-object v1

    .line 46
    .local v1, "intentGroup":Landroid/content/Intent;
    const-string v2, "groupId"

    const/4 v3, -0x1

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v2

    iput v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->groupId:I

    .line 48
    :try_start_0
    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v2}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 49
    .local v2, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v3, Lorg/json/JSONObject;

    const-string v4, "config.cfg"

    invoke-virtual {v2, p0, v4}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 50
    .local v3, "jsonCfg":Lorg/json/JSONObject;
    const-string v4, "SERVER"

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    .line 51
    .local v4, "server":Lorg/json/JSONObject;
    const-string v5, "FAST_LOGIN"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    .line 52
    .local v5, "fastLogin":Lorg/json/JSONObject;
    const-string v6, "url"

    invoke-virtual {v4, v6, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    iput-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->url:Ljava/lang/String;

    .line 53
    const-string v6, "username"

    invoke-virtual {v5, v6, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->username:Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 56
    .end local v2    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v3    # "jsonCfg":Lorg/json/JSONObject;
    .end local v4    # "server":Lorg/json/JSONObject;
    .end local v5    # "fastLogin":Lorg/json/JSONObject;
    goto :goto_0

    .line 54
    :catch_0
    move-exception v0

    .line 55
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 57
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->btnChangeName:Landroid/widget/Button;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$1;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 65
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->btnRemoveChannel:Landroid/widget/Button;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$2;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 73
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->btnExit:Landroid/widget/Button;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$3;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 88
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->btnBanUser:Landroid/widget/Button;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$4;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 96
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->btnHome:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$5;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$5;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;)V

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 104
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->btnOptions:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$6;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$6;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;)V

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 112
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->btnProfile:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$7;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$7;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;)V

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 120
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;->btnChat:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$8;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup$8;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ConfigGroup;)V

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 127
    return-void
.end method
