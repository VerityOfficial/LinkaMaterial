.class Lcom/LinkaMaterialProject/linkaMaterial/request$1;
.super Ljava/lang/Object;
.source "request.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTPAsync(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;ILandroid/content/Context;Lcom/LinkaMaterialProject/linkaMaterial/request$RequestCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$callback:Lcom/LinkaMaterialProject/linkaMaterial/request$RequestCallback;

.field final synthetic val$context:Landroid/content/Context;

.field final synthetic val$json_body:Lorg/json/JSONObject;

.field final synthetic val$method:Ljava/lang/String;

.field final synthetic val$status_code:I

.field final synthetic val$urlParam:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;ILandroid/content/Context;Lcom/LinkaMaterialProject/linkaMaterial/request$RequestCallback;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 21
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1;->val$urlParam:Ljava/lang/String;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1;->val$method:Ljava/lang/String;

    iput-object p3, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1;->val$json_body:Lorg/json/JSONObject;

    iput p4, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1;->val$status_code:I

    iput-object p5, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1;->val$context:Landroid/content/Context;

    iput-object p6, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1;->val$callback:Lcom/LinkaMaterialProject/linkaMaterial/request$RequestCallback;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    .line 25
    :try_start_0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1;->val$urlParam:Ljava/lang/String;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1;->val$method:Ljava/lang/String;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1;->val$json_body:Lorg/json/JSONObject;

    iget v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1;->val$status_code:I

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1;->val$context:Landroid/content/Context;

    invoke-static {v0, v1, v2, v3, v4}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;ILandroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    .line 26
    .local v0, "result":Ljava/lang/String;
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1;->val$callback:Lcom/LinkaMaterialProject/linkaMaterial/request$RequestCallback;

    if-eqz v1, :cond_0

    .line 27
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/request$1$1;

    invoke-direct {v2, p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/request$1$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/request$1;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 43
    .end local v0    # "result":Ljava/lang/String;
    :cond_0
    goto :goto_0

    .line 34
    :catch_0
    move-exception v0

    .line 35
    .local v0, "e":Ljava/lang/Exception;
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1;->val$callback:Lcom/LinkaMaterialProject/linkaMaterial/request$RequestCallback;

    if-eqz v1, :cond_1

    .line 36
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/request$1$2;

    invoke-direct {v2, p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/request$1$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/request$1;Ljava/lang/Exception;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 44
    .end local v0    # "e":Ljava/lang/Exception;
    :cond_1
    :goto_0
    return-void
.end method
