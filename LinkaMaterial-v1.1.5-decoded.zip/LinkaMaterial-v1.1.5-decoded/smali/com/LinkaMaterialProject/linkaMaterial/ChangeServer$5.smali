.class Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer$5;
.super Ljava/lang/Object;
.source "ChangeServer.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;

    .line 83
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 86
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;

    const-class v2, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 87
    .local v0, "intent":Landroid/content/Intent;
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->startActivity(Landroid/content/Intent;)V

    .line 88
    return-void
.end method
