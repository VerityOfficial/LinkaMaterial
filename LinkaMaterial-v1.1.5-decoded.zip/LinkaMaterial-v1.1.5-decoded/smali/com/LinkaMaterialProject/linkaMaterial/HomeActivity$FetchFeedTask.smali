.class Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$FetchFeedTask;
.super Landroid/os/AsyncTask;
.source "HomeActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "FetchFeedTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/String;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;


# direct methods
.method private constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;)V
    .locals 0

    .line 174
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$FetchFeedTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$FetchFeedTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;)V

    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 174
    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$FetchFeedTask;->doInBackground([Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .param p1, "urls"    # [Ljava/lang/String;

    .line 177
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$FetchFeedTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    const/4 v1, 0x0

    aget-object v1, p1, v1

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const-string v3, "GET"

    invoke-virtual {v0, v1, v3, v2}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 174
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$FetchFeedTask;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 5
    .param p1, "result"    # Ljava/lang/String;

    .line 182
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$FetchFeedTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->-$$Nest$fgetpostsList(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 184
    const/4 v0, 0x0

    if-eqz p1, :cond_2

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_2

    .line 191
    :cond_0
    :try_start_0
    new-instance v1, Lorg/json/JSONArray;

    invoke-direct {v1, p1}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    .line 192
    .local v1, "jsonArray":Lorg/json/JSONArray;
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_0
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v3

    if-ge v2, v3, :cond_1

    .line 193
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$FetchFeedTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->-$$Nest$fgetpostsList(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;)Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v1, v2}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 192
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 198
    .end local v1    # "jsonArray":Lorg/json/JSONArray;
    .end local v2    # "i":I
    :cond_1
    goto :goto_1

    .line 195
    :catch_0
    move-exception v1

    .line 196
    .local v1, "e":Ljava/lang/Exception;
    invoke-virtual {v1}, Ljava/lang/Exception;->printStackTrace()V

    .line 197
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$FetchFeedTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    const-string v3, "Error in parsing posts"

    invoke-static {v2, v3, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 200
    .end local v1    # "e":Ljava/lang/Exception;
    :goto_1
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$FetchFeedTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->-$$Nest$fgetpostAdapter(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;)Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;

    move-result-object v0

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;->notifyDataSetChanged()V

    .line 201
    return-void

    .line 185
    :cond_2
    :goto_2
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$FetchFeedTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->-$$Nest$fgetpostAdapter(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;)Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;

    move-result-object v1

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;->notifyDataSetChanged()V

    .line 186
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$FetchFeedTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    const-string v2, "Error in feed loading"

    invoke-static {v1, v2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 187
    return-void
.end method
