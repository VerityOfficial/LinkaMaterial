.class Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$2;
.super Ljava/lang/Object;
.source "ImageLoader.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;->LoadImageUrl(Ljava/lang/String;Landroid/widget/ImageView;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;

.field final synthetic val$imageUrl:Ljava/lang/String;

.field final synthetic val$targetView:Landroid/widget/ImageView;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;Ljava/lang/String;Landroid/widget/ImageView;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 99
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$2;->val$imageUrl:Ljava/lang/String;

    iput-object p3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$2;->val$targetView:Landroid/widget/ImageView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 102
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$2;->val$imageUrl:Ljava/lang/String;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$2;->val$targetView:Landroid/widget/ImageView;

    invoke-virtual {v0, v1, v2}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;->processImageData(Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 103
    return-void
.end method
