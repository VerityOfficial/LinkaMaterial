.class public Lcom/LinkaMaterialProject/linkaMaterial/profile;
.super Landroid/app/Activity;
.source "profile.java"


# instance fields
.field private biography:Ljava/lang/String;

.field private btnChat:Landroid/widget/ImageButton;

.field private btnEdit:Landroid/widget/Button;

.field private btnExit:Landroid/widget/Button;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;

.field private imgProfilePicture:Landroid/widget/ImageView;

.field private postsContainer:Landroid/widget/LinearLayout;

.field private txtBio:Landroid/widget/TextView;

.field private txtUsername:Landroid/widget/TextView;

.field private url:Ljava/lang/String;

.field private username:Ljava/lang/String;

.field private usernameProfile:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetusernameProfile(Lcom/LinkaMaterialProject/linkaMaterial/profile;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->usernameProfile:Ljava/lang/String;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 1

    .line 25
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 27
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->username:Ljava/lang/String;

    .line 28
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->url:Ljava/lang/String;

    .line 29
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->biography:Ljava/lang/String;

    .line 35
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->usernameProfile:Ljava/lang/String;

    return-void
.end method

.method private loadPosts(Ljava/lang/String;)V
    .locals 16
    .param p1, "usernameProfile"    # Ljava/lang/String;

    .line 136
    move-object/from16 v1, p0

    const-string v0, ""

    :try_start_0
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 137
    .local v2, "jsonReq":Lorg/json/JSONObject;
    const-string v3, "username"
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    move-object/from16 v4, p1

    :try_start_1
    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 139
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, v1, Lcom/LinkaMaterialProject/linkaMaterial/profile;->url:Ljava/lang/String;

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, "/view-profile-posts"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v5, "post"

    invoke-static {v3, v5, v2, v1}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    .line 140
    .local v3, "responseStr":Ljava/lang/String;
    new-instance v5, Lorg/json/JSONArray;

    invoke-direct {v5, v3}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    .line 142
    .local v5, "postsArray":Lorg/json/JSONArray;
    iget-object v6, v1, Lcom/LinkaMaterialProject/linkaMaterial/profile;->postsContainer:Landroid/widget/LinearLayout;

    invoke-virtual {v6}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 144
    const/4 v6, 0x0

    .local v6, "i":I
    :goto_0
    invoke-virtual {v5}, Lorg/json/JSONArray;->length()I

    move-result v7

    if-ge v6, v7, :cond_0

    .line 145
    invoke-virtual {v5, v6}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v7

    .line 146
    .local v7, "post":Lorg/json/JSONObject;
    const-string v8, "text_post"

    invoke-virtual {v7, v8, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 147
    .local v8, "textPost":Ljava/lang/String;
    const-string v9, "datetime"

    invoke-virtual {v7, v9, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 149
    .local v9, "datetime":Ljava/lang/String;
    new-instance v10, Landroid/widget/LinearLayout;

    invoke-direct {v10, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 150
    .local v10, "postCard":Landroid/widget/LinearLayout;
    const/4 v11, 0x1

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 152
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v12, -0x1

    const/4 v13, -0x2

    invoke-direct {v11, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 156
    .local v11, "cardParams":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v12, 0x18

    const/4 v13, 0x0

    invoke-virtual {v11, v13, v13, v13, v12}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 157
    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 158
    const/16 v12, 0x10

    invoke-virtual {v10, v12, v12, v12, v12}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 160
    new-instance v12, Landroid/widget/TextView;

    invoke-direct {v12, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 161
    .local v12, "txtDate":Landroid/widget/TextView;
    invoke-virtual {v12, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 162
    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/profile;->getResources()Landroid/content/res/Resources;

    move-result-object v14

    sget v15, Lcom/LinkaMaterialProject/linkaMaterial/R$color;->app_text_secondary:I

    invoke-virtual {v14, v15}, Landroid/content/res/Resources;->getColor(I)I

    move-result v14

    invoke-virtual {v12, v14}, Landroid/widget/TextView;->setTextColor(I)V

    .line 163
    const/high16 v14, 0x41400000    # 12.0f

    invoke-virtual {v12, v14}, Landroid/widget/TextView;->setTextSize(F)V

    .line 165
    new-instance v14, Landroid/widget/TextView;

    invoke-direct {v14, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 166
    .local v14, "txtContent":Landroid/widget/TextView;
    invoke-virtual {v14, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 167
    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/profile;->getResources()Landroid/content/res/Resources;

    move-result-object v15

    sget v13, Lcom/LinkaMaterialProject/linkaMaterial/R$color;->app_text_primary:I

    invoke-virtual {v15, v13}, Landroid/content/res/Resources;->getColor(I)I

    move-result v13

    invoke-virtual {v14, v13}, Landroid/widget/TextView;->setTextColor(I)V

    .line 168
    const/high16 v13, 0x41600000    # 14.0f

    invoke-virtual {v14, v13}, Landroid/widget/TextView;->setTextSize(F)V

    .line 169
    const/16 v13, 0x8

    const/4 v15, 0x0

    invoke-virtual {v14, v15, v13, v15, v15}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 171
    invoke-virtual {v10, v12}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 172
    invoke-virtual {v10, v14}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 174
    iget-object v13, v1, Lcom/LinkaMaterialProject/linkaMaterial/profile;->postsContainer:Landroid/widget/LinearLayout;

    invoke-virtual {v13, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 144
    .end local v7    # "post":Lorg/json/JSONObject;
    .end local v8    # "textPost":Ljava/lang/String;
    .end local v9    # "datetime":Ljava/lang/String;
    .end local v10    # "postCard":Landroid/widget/LinearLayout;
    .end local v11    # "cardParams":Landroid/widget/LinearLayout$LayoutParams;
    .end local v12    # "txtDate":Landroid/widget/TextView;
    .end local v14    # "txtContent":Landroid/widget/TextView;
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    .line 178
    .end local v2    # "jsonReq":Lorg/json/JSONObject;
    .end local v3    # "responseStr":Ljava/lang/String;
    .end local v5    # "postsArray":Lorg/json/JSONArray;
    .end local v6    # "i":I
    :cond_0
    goto :goto_2

    .line 176
    :catch_0
    move-exception v0

    goto :goto_1

    :catch_1
    move-exception v0

    move-object/from16 v4, p1

    .line 177
    .local v0, "e":Ljava/lang/Exception;
    :goto_1
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 179
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_2
    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 6
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 41
    const-string v0, ""

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 42
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->my_profile:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/profile;->setContentView(I)V

    .line 43
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/profile;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->btnHome:Landroid/widget/ImageButton;

    .line 44
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/profile;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->btnChat:Landroid/widget/ImageButton;

    .line 45
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/profile;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->btnOptions:Landroid/widget/ImageButton;

    .line 46
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/profile;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->btnProfile:Landroid/widget/ImageButton;

    .line 47
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->btnHome:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/profile$1;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/profile$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/profile;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 54
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->btnOptions:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/profile$2;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/profile$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/profile;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 61
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->btnProfile:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/profile$3;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/profile$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/profile;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 68
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->btnChat:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/profile$4;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/profile$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/profile;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 76
    :try_start_0
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v1}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 77
    .local v1, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v2, Lorg/json/JSONObject;

    const-string v3, "config.cfg"

    invoke-virtual {v1, p0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 78
    .local v2, "jsonCfg":Lorg/json/JSONObject;
    const-string v3, "FAST_LOGIN"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    .line 79
    .local v3, "fastLogin":Lorg/json/JSONObject;
    const-string v4, "SERVER"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    .line 80
    .local v4, "server":Lorg/json/JSONObject;
    const-string v5, "username"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v5

    iput-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->usernameProfile:Ljava/lang/String;

    .line 81
    const-string v5, "url"

    invoke-virtual {v4, v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->url:Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 84
    .end local v1    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v2    # "jsonCfg":Lorg/json/JSONObject;
    .end local v3    # "fastLogin":Lorg/json/JSONObject;
    .end local v4    # "server":Lorg/json/JSONObject;
    goto :goto_0

    .line 82
    :catch_0
    move-exception v1

    .line 83
    .local v1, "e":Lorg/json/JSONException;
    invoke-virtual {v1}, Lorg/json/JSONException;->printStackTrace()V

    .line 88
    .end local v1    # "e":Lorg/json/JSONException;
    :goto_0
    :try_start_1
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    .line 89
    .local v1, "jsonProfile":Lorg/json/JSONObject;
    new-instance v2, Lorg/json/JSONObject;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->url:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "/view_profile/"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->usernameProfile:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "get"

    invoke-static {v3, v4, v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 90
    .local v2, "response":Lorg/json/JSONObject;
    const-string v3, "bio"

    invoke-virtual {v2, v3, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->biography:Ljava/lang/String;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 93
    .end local v1    # "jsonProfile":Lorg/json/JSONObject;
    .end local v2    # "response":Lorg/json/JSONObject;
    goto :goto_1

    .line 91
    :catch_1
    move-exception v0

    .line 92
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 95
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_1
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->imgProfilePicture:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/profile;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->imgProfilePicture:Landroid/widget/ImageView;

    .line 96
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->txtUsername:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/profile;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->txtUsername:Landroid/widget/TextView;

    .line 97
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->txtBio:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/profile;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->txtBio:Landroid/widget/TextView;

    .line 98
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->postsContainer:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/profile;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->postsContainer:Landroid/widget/LinearLayout;

    .line 99
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnExit:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/profile;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->btnExit:Landroid/widget/Button;

    .line 100
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->txtUsername:Landroid/widget/TextView;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->usernameProfile:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 101
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->txtBio:Landroid/widget/TextView;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->biography:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 102
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnEdit:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/profile;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->btnEdit:Landroid/widget/Button;

    .line 103
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;

    invoke-direct {v0}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;-><init>()V

    .line 104
    .local v0, "imageLoader":Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->usernameProfile:Ljava/lang/String;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->imgProfilePicture:Landroid/widget/ImageView;

    invoke-virtual {v0, p0, v1, v2}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;->viewProfilePicture(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 105
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->btnExit:Landroid/widget/Button;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/profile$5;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/profile$5;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/profile;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 115
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->imgProfilePicture:Landroid/widget/ImageView;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/profile$6;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/profile$6;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/profile;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 124
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->btnEdit:Landroid/widget/Button;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/profile$7;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/profile$7;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/profile;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 131
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/profile;->usernameProfile:Ljava/lang/String;

    invoke-direct {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/profile;->loadPosts(Ljava/lang/String;)V

    .line 132
    return-void
.end method
