.class Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$SendMessageTask;
.super Landroid/os/AsyncTask;
.source "GroupChatActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "SendMessageTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/Void;",
        "Ljava/lang/Void;",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field private messageToSend:Ljava/lang/String;

.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;


# direct methods
.method public constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;Ljava/lang/String;)V
    .locals 0
    .param p2, "message"    # Ljava/lang/String;

    .line 190
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    .line 191
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$SendMessageTask;->messageToSend:Ljava/lang/String;

    .line 192
    return-void
.end method


# virtual methods
.method protected varargs doInBackground([Ljava/lang/Void;)Ljava/lang/Boolean;
    .locals 10
    .param p1, "params"    # [Ljava/lang/Void;

    .line 197
    const-string v0, "group_id"

    const-string v1, "channel"

    const-string v2, "MATERIAL_DEBUG"

    const/4 v3, 0x0

    :try_start_0
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4}, Lorg/json/JSONObject;-><init>()V

    .line 198
    .local v4, "jsonChat":Lorg/json/JSONObject;
    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-virtual {v5}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->getIntent()Landroid/content/Intent;

    move-result-object v5

    .line 199
    .local v5, "intent":Landroid/content/Intent;
    invoke-virtual {v5, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 200
    .local v6, "channel":Ljava/lang/String;
    const/4 v7, -0x1

    invoke-virtual {v5, v0, v7}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v7

    .line 202
    .local v7, "groupId":I
    const-string v8, "message"

    iget-object v9, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$SendMessageTask;->messageToSend:Ljava/lang/String;

    invoke-virtual {v4, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 203
    invoke-virtual {v4, v1, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 204
    const-string v1, "sender"

    iget-object v8, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-static {v8}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v4, v1, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 205
    const-string v1, "username"

    iget-object v8, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-static {v8}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v4, v1, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 206
    invoke-virtual {v4, v0, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 208
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "/send-group-message"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 209
    .local v0, "fullUrl":Ljava/lang/String;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "SendMessageTask enviando mensagem para: "

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v8, " Payload: "

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v4}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 211
    const-string v1, "post"

    iget-object v8, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-static {v0, v1, v4, v8}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    .line 212
    .local v1, "res":Ljava/lang/String;
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "SendMessageTask resposta: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v2, v8}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 214
    if-eqz v1, :cond_0

    const-string v8, "success"

    invoke-virtual {v1, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_0

    const/4 v8, 0x1

    goto :goto_0

    :cond_0
    const/4 v8, 0x0

    :goto_0
    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v2

    .line 215
    .end local v0    # "fullUrl":Ljava/lang/String;
    .end local v1    # "res":Ljava/lang/String;
    .end local v4    # "jsonChat":Lorg/json/JSONObject;
    .end local v5    # "intent":Landroid/content/Intent;
    .end local v6    # "channel":Ljava/lang/String;
    .end local v7    # "groupId":I
    :catch_0
    move-exception v0

    .line 216
    .local v0, "e":Ljava/lang/Exception;
    const-string v1, "Erro em SendMessageTask doInBackground"

    invoke-static {v2, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 217
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    return-object v1
.end method

.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 187
    check-cast p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$SendMessageTask;->doInBackground([Ljava/lang/Void;)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method

.method protected onPostExecute(Ljava/lang/Boolean;)V
    .locals 4
    .param p1, "success"    # Ljava/lang/Boolean;

    .line 223
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v1, 0x0

    const-string v2, "MATERIAL_DEBUG"

    if-eqz v0, :cond_0

    .line 224
    const-string v0, "Mensagem enviada com sucesso. Forcando atualizacao..."

    invoke-static {v2, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 225
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    const/4 v3, 0x0

    invoke-direct {v0, v2, v3}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity-IA;)V

    new-array v1, v1, [Ljava/lang/Void;

    invoke-virtual {v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    goto :goto_0

    .line 227
    :cond_0
    const-string v0, "Falha ao enviar mensagem."

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 228
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    const-string v2, "Error sending message"

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 230
    :goto_0
    return-void
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 187
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$SendMessageTask;->onPostExecute(Ljava/lang/Boolean;)V

    return-void
.end method
