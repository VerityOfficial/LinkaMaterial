.class public Lcom/LinkaMaterialProject/linkaMaterial/Comment;
.super Ljava/lang/Object;
.source "Comment.java"


# instance fields
.field private commentId:I

.field private postId:I

.field private textComment:Ljava/lang/String;

.field private username:Ljava/lang/String;


# direct methods
.method public constructor <init>(IILjava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "commentId"    # I
    .param p2, "postId"    # I
    .param p3, "username"    # Ljava/lang/String;
    .param p4, "textComment"    # Ljava/lang/String;

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    iput p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/Comment;->commentId:I

    .line 9
    iput p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/Comment;->postId:I

    .line 10
    iput-object p3, p0, Lcom/LinkaMaterialProject/linkaMaterial/Comment;->username:Ljava/lang/String;

    .line 11
    iput-object p4, p0, Lcom/LinkaMaterialProject/linkaMaterial/Comment;->textComment:Ljava/lang/String;

    .line 12
    return-void
.end method


# virtual methods
.method public getCommentId()I
    .locals 1

    .line 13
    iget v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/Comment;->commentId:I

    return v0
.end method

.method public getPostId()I
    .locals 1

    .line 14
    iget v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/Comment;->postId:I

    return v0
.end method

.method public getTextComment()Ljava/lang/String;
    .locals 1

    .line 16
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/Comment;->textComment:Ljava/lang/String;

    return-object v0
.end method

.method public getUsername()Ljava/lang/String;
    .locals 1

    .line 15
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/Comment;->username:Ljava/lang/String;

    return-object v0
.end method
