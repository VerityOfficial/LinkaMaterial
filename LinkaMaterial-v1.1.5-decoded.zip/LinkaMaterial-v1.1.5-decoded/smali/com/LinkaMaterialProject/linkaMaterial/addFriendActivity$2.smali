.class Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$2;
.super Ljava/lang/Object;
.source "addFriendActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;

    .line 75
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 78
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;

    const-class v2, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 79
    .local v0, "intent":Landroid/content/Intent;
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/addFriendActivity;->startActivity(Landroid/content/Intent;)V

    .line 80
    return-void
.end method
