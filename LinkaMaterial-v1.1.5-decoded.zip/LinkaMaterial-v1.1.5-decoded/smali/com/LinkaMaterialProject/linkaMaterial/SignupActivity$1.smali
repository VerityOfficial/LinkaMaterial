.class Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;
.super Ljava/lang/Object;
.source "SignupActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;

.field final synthetic val$baseUrl:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 100
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;->val$baseUrl:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 23
    .param p1, "v"    # Landroid/view/View;

    .line 103
    move-object/from16 v1, p0

    iget-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->-$$Nest$fgetedtUsername(Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    .line 104
    .local v7, "username":Ljava/lang/String;
    iget-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->-$$Nest$fgetedtPassword(Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v13

    .line 105
    .local v13, "password":Ljava/lang/String;
    iget-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->-$$Nest$fgetedtEmail(Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v14

    .line 106
    .local v14, "email":Ljava/lang/String;
    iget-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->-$$Nest$fgetedtRetypePassword(Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v15

    .line 109
    .local v15, "passwordRetyped":Ljava/lang/String;
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 110
    .local v0, "json_register":Lorg/json/JSONObject;
    const-string v2, "username"

    invoke-virtual {v0, v2, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 111
    const-string v2, "senha"

    invoke-virtual {v0, v2, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 112
    const-string v2, "password"

    invoke-virtual {v0, v2, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 113
    const-string v2, "email"

    invoke-virtual {v0, v2, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 115
    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 133
    iget-object v3, v1, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;

    .line 115
    const/4 v4, 0x0

    if-eqz v2, :cond_1

    .line 116
    :try_start_1
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, v1, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;->val$baseUrl:Ljava/lang/String;

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v5, "/register"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v5, "post"

    invoke-virtual {v3, v2, v5, v0}, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v16, v2

    .line 118
    .local v16, "response":Ljava/lang/String;
    invoke-virtual/range {v16 .. v16}, Ljava/lang/String;->length()I

    move-result v2

    if-eqz v2, :cond_0

    .line 119
    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v2}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    move-object/from16 v17, v2

    .line 120
    .local v17, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    iget-object v3, v1, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;

    const-string v4, "config.cfg"

    const-string v5, "FAST_LOGIN"

    const-string v6, "username"

    move-object/from16 v2, v17

    .end local v17    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .local v2, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    invoke-virtual/range {v2 .. v7}, Lcom/LinkaMaterialProject/linkaMaterial/config;->updateCfg(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 121
    .end local v2    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .restart local v17    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    iget-object v9, v1, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;

    const-string v10, "config.cfg"

    const-string v11, "FAST_LOGIN"

    const-string v12, "password"

    move-object/from16 v8, v17

    .end local v17    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .local v8, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    invoke-virtual/range {v8 .. v13}, Lcom/LinkaMaterialProject/linkaMaterial/config;->updateCfg(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 123
    .end local v8    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .restart local v17    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    iget-object v2, v1, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/tokenManager;->newSession(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v22

    .line 124
    .local v22, "newToken":Ljava/lang/String;
    iget-object v2, v1, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;

    const-string v19, "config.cfg"

    const-string v20, "FAST_LOGIN"

    const-string v21, "token_session"

    move-object/from16 v18, v2

    invoke-virtual/range {v17 .. v22}, Lcom/LinkaMaterialProject/linkaMaterial/config;->updateCfg(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 126
    new-instance v2, Landroid/content/Intent;

    iget-object v3, v1, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;

    const-class v4, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 127
    .local v2, "intent":Landroid/content/Intent;
    iget-object v3, v1, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;

    invoke-virtual {v3, v2}, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->startActivity(Landroid/content/Intent;)V

    .line 128
    iget-object v3, v1, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;

    invoke-virtual {v3}, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;->finish()V

    .line 129
    .end local v2    # "intent":Landroid/content/Intent;
    .end local v17    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v22    # "newToken":Ljava/lang/String;
    goto :goto_0

    .line 130
    :cond_0
    iget-object v2, v1, Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/SignupActivity;

    const-string v3, "Connection with server has failed"

    invoke-static {v2, v3, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 132
    .end local v16    # "response":Ljava/lang/String;
    :goto_0
    goto :goto_1

    .line 133
    :cond_1
    const-string v2, "Passwords don\'t match!"

    invoke-static {v3, v2, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 137
    .end local v0    # "json_register":Lorg/json/JSONObject;
    :goto_1
    goto :goto_2

    .line 135
    :catch_0
    move-exception v0

    .line 136
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 138
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_2
    return-void
.end method
