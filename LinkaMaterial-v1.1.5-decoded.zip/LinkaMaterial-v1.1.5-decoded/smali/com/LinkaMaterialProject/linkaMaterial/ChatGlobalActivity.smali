.class public Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;
.super Landroid/app/Activity;
.source "ChatGlobalActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$SendMessageTask;,
        Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$FetchMessagesTask;
    }
.end annotation


# static fields
.field private static final TAG:Ljava/lang/String; = "MATERIAL_DEBUG"

.field private static final UPDATE_INTERVAL:I = 0x7d0


# instance fields
.field private autoUpdateHandler:Landroid/os/Handler;

.field private autoUpdateRunnable:Ljava/lang/Runnable;

.field private btnHeaderImage:Landroid/widget/ImageButton;

.field private btnSend:Landroid/widget/Button;

.field private chatContainer:Landroid/widget/LinearLayout;

.field private edtInputMessage:Landroid/widget/EditText;

.field private txtHeaderTitle:Landroid/widget/TextView;

.field private url:Ljava/lang/String;

.field private username:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetautoUpdateHandler(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)Landroid/os/Handler;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->autoUpdateHandler:Landroid/os/Handler;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetchatContainer(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)Landroid/widget/LinearLayout;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->chatContainer:Landroid/widget/LinearLayout;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetedtInputMessage(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->edtInputMessage:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->url:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->username:Ljava/lang/String;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 1

    .line 19
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 26
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->username:Ljava/lang/String;

    .line 27
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->url:Ljava/lang/String;

    .line 28
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->autoUpdateHandler:Landroid/os/Handler;

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 8
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 33
    const-string v0, ""

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 34
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->global_chat:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->setContentView(I)V

    .line 35
    const-string v1, "=== ChatGlobalActivity Started ==="

    const-string v2, "MATERIAL_DEBUG"

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 37
    :try_start_0
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v1}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 38
    .local v1, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    const-string v3, "config.cfg"

    invoke-virtual {v1, p0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 39
    .local v3, "rawCfg":Ljava/lang/String;
    if-eqz v3, :cond_0

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_0

    .line 40
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 41
    .local v4, "jsonCfg":Lorg/json/JSONObject;
    const-string v5, "FAST_LOGIN"

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    .line 42
    .local v5, "fastLogin":Lorg/json/JSONObject;
    const-string v6, "SERVER"

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v6

    .line 43
    .local v6, "server":Lorg/json/JSONObject;
    const-string v7, "username"

    invoke-virtual {v5, v7, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    iput-object v7, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->username:Ljava/lang/String;

    .line 44
    const-string v7, "url"

    invoke-virtual {v6, v7, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->url:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 48
    .end local v1    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v3    # "rawCfg":Ljava/lang/String;
    .end local v4    # "jsonCfg":Lorg/json/JSONObject;
    .end local v5    # "fastLogin":Lorg/json/JSONObject;
    .end local v6    # "server":Lorg/json/JSONObject;
    :cond_0
    goto :goto_0

    .line 46
    :catch_0
    move-exception v0

    .line 47
    .local v0, "e":Ljava/lang/Exception;
    const-string v1, "Error parsing config.cfg"

    invoke-static {v2, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 49
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_0
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHeaderImage:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->btnHeaderImage:Landroid/widget/ImageButton;

    .line 50
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->txtHeaderTitle:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->txtHeaderTitle:Landroid/widget/TextView;

    .line 51
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnSend:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->btnSend:Landroid/widget/Button;

    .line 52
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtInputMessage:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->edtInputMessage:Landroid/widget/EditText;

    .line 53
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->layoutMessagesContainer:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->chatContainer:Landroid/widget/LinearLayout;

    .line 54
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->btnSend:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$1;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 64
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->btnHeaderImage:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$2;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 71
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$3;

    invoke-direct {v0, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)V

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->autoUpdateRunnable:Ljava/lang/Runnable;

    .line 78
    return-void
.end method

.method protected onPause()V
    .locals 2

    .line 86
    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    .line 87
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->autoUpdateHandler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->autoUpdateRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 88
    return-void
.end method

.method protected onResume()V
    .locals 2

    .line 81
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 82
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->autoUpdateHandler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->autoUpdateRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 83
    return-void
.end method
