.class public final Lcom/LinkaMaterialProject/linkaMaterial/R$drawable;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "drawable"
.end annotation


# static fields
.field public static account:I = 0x7f030001

.field public static back:I = 0x7f030002

.field public static bg_material_button:I = 0x7f030003

.field public static bg_material_card:I = 0x7f030004

.field public static btn_dark_custom:I = 0x7f030005

.field public static card_item:I = 0x7f030006

.field public static chat:I = 0x7f030007

.field public static hdpi:I = 0x7f030008

.field public static home:I = 0x7f030009

.field public static ic_launcher_foreground:I = 0x7f03000a

.field public static icon:I = 0x7f03000b

.field public static options:I = 0x7f03000c


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
