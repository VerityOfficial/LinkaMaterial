.class public final Lcom/LinkaMaterialProject/linkaMaterial/R$xml;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "xml"
.end annotation


# static fields
.field public static account_preferences:I = 0x7f090000

.field public static authenticator:I = 0x7f090001

.field public static backup_rules:I = 0x7f090002

.field public static data_extraction_rules:I = 0x7f090003


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
