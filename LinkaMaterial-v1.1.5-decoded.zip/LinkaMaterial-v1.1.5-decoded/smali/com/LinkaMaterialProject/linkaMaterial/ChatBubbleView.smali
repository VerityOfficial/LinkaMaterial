.class public Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;
.super Landroid/widget/LinearLayout;
.source "ChatBubbleView.java"


# instance fields
.field private bubbleContainer:Landroid/widget/LinearLayout;

.field private txtMessage:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Z)V
    .locals 0
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "text"    # Ljava/lang/String;
    .param p3, "isMe"    # Z

    .line 11
    invoke-direct {p0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 12
    invoke-direct {p0, p1, p2, p3}, Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;->init(Landroid/content/Context;Ljava/lang/String;Z)V

    .line 13
    return-void
.end method

.method private init(Landroid/content/Context;Ljava/lang/String;Z)V
    .locals 3
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "text"    # Ljava/lang/String;
    .param p3, "isMe"    # Z

    .line 15
    const-string v0, "layout_inflater"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/LayoutInflater;

    .line 16
    .local v0, "inflater":Landroid/view/LayoutInflater;
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->chat_bubble_item:I

    const/4 v2, 0x1

    invoke-virtual {v0, v1, p0, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 17
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->bubbleContainer:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;->bubbleContainer:Landroid/widget/LinearLayout;

    .line 18
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->txtMessage:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;->txtMessage:Landroid/widget/TextView;

    .line 19
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;->txtMessage:Landroid/widget/TextView;

    invoke-virtual {v1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 20
    nop

    .line 24
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;->bubbleContainer:Landroid/widget/LinearLayout;

    .line 20
    if-eqz p3, :cond_0

    .line 21
    const/4 v2, 0x5

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 22
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;->txtMessage:Landroid/widget/TextView;

    sget v2, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->bubble_mine:I

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    goto :goto_0

    .line 24
    :cond_0
    const/4 v2, 0x3

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 25
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatBubbleView;->txtMessage:Landroid/widget/TextView;

    sget v2, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->bubble_other:I

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 27
    :goto_0
    return-void
.end method
