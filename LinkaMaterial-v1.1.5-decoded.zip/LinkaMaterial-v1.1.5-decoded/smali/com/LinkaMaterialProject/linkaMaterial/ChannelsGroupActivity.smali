.class public Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;
.super Landroid/app/Activity;
.source "ChannelsGroupActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchMembersTask;,
        Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;
    }
.end annotation


# instance fields
.field private adapter:Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;

.field private btnAdd:Landroid/widget/Button;

.field private btnAddMember:Landroid/widget/Button;

.field private btnBack:Landroid/widget/ImageButton;

.field private btnChat:Landroid/widget/ImageButton;

.field private btnConfig:Landroid/widget/Button;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;

.field private channelList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/Channel;",
            ">;"
        }
    .end annotation
.end field

.field private groupId:I

.field private listChannelsView:Landroid/widget/ListView;

.field private listViewMembers:Landroid/widget/ListView;

.field private textGroup:Landroid/widget/TextView;

.field private url:Ljava/lang/String;

.field private username:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetadapter(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->adapter:Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetchannelList(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)Ljava/util/List;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->channelList:Ljava/util/List;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetgroupId(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)I
    .locals 0

    iget p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->groupId:I

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetlistChannelsView(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)Landroid/widget/ListView;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->listChannelsView:Landroid/widget/ListView;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetlistViewMembers(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)Landroid/widget/ListView;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->listViewMembers:Landroid/widget/ListView;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->url:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->username:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fputadapter(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;)V
    .locals 0

    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->adapter:Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 23
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 36
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->url:Ljava/lang/String;

    .line 37
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->username:Ljava/lang/String;

    .line 38
    const/4 v0, -0x1

    iput v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->groupId:I

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 7
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 44
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 45
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->activity_channels:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->setContentView(I)V

    .line 47
    invoke-virtual {p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    .line 48
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "groupId"

    const/4 v2, -0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    iput v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->groupId:I

    .line 49
    iget v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->groupId:I

    const/4 v3, 0x0

    if-ne v1, v2, :cond_0

    .line 50
    const-string v1, "ID do grupo inv\u00e1lido"

    invoke-static {p0, v1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 51
    invoke-virtual {p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->finish()V

    .line 52
    return-void

    .line 56
    :cond_0
    :try_start_0
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v1}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 57
    .local v1, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v2, Lorg/json/JSONObject;

    const-string v4, "config.cfg"

    invoke-virtual {v1, p0, v4}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 58
    .local v2, "jsonCfg":Lorg/json/JSONObject;
    const-string v4, "FAST_LOGIN"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    .line 59
    .local v4, "fastLogin":Lorg/json/JSONObject;
    const-string v5, "SERVER"

    invoke-virtual {v2, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    .line 60
    .local v5, "server":Lorg/json/JSONObject;
    const-string v6, "url"

    invoke-virtual {v5, v6}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    iput-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->url:Ljava/lang/String;

    .line 61
    const-string v6, "username"

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    iput-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->username:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 64
    .end local v1    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v2    # "jsonCfg":Lorg/json/JSONObject;
    .end local v4    # "fastLogin":Lorg/json/JSONObject;
    .end local v5    # "server":Lorg/json/JSONObject;
    goto :goto_0

    .line 62
    :catch_0
    move-exception v1

    .line 63
    .local v1, "e":Ljava/lang/Exception;
    invoke-virtual {v1}, Ljava/lang/Exception;->printStackTrace()V

    .line 66
    .end local v1    # "e":Ljava/lang/Exception;
    :goto_0
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnBack:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->btnBack:Landroid/widget/ImageButton;

    .line 67
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->textGroup:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->textGroup:Landroid/widget/TextView;

    .line 68
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnAdd:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->btnAdd:Landroid/widget/Button;

    .line 69
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnConfig:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->btnConfig:Landroid/widget/Button;

    .line 70
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->btnHome:Landroid/widget/ImageButton;

    .line 71
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->btnChat:Landroid/widget/ImageButton;

    .line 72
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->btnOptions:Landroid/widget/ImageButton;

    .line 73
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->btnProfile:Landroid/widget/ImageButton;

    .line 74
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->listChannels:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ListView;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->listChannelsView:Landroid/widget/ListView;

    .line 75
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->listViewMembers:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ListView;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->listViewMembers:Landroid/widget/ListView;

    .line 76
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->channelList:Ljava/util/List;

    .line 77
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnAddMember:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->btnAddMember:Landroid/widget/Button;

    .line 79
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchMembersTask;

    const/4 v2, 0x0

    invoke-direct {v1, p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchMembersTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity-IA;)V

    new-array v4, v3, [Ljava/lang/Void;

    invoke-virtual {v1, v4}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchMembersTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 80
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;

    invoke-direct {v1, p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity-IA;)V

    new-array v2, v3, [Ljava/lang/Void;

    invoke-virtual {v1, v2}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$FetchChannelsTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 81
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->btnConfig:Landroid/widget/Button;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$1;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 89
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->btnBack:Landroid/widget/ImageButton;

    if-eqz v1, :cond_1

    .line 90
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->btnBack:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$2;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 98
    :cond_1
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->btnAdd:Landroid/widget/Button;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$3;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 106
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->btnAddMember:Landroid/widget/Button;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$4;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 114
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->btnHome:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$5;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$5;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 121
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->btnOptions:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$6;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$6;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 128
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->btnProfile:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$7;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$7;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 135
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->btnChat:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$8;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$8;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 141
    return-void
.end method
