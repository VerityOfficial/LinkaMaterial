.class public Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter;
.super Landroid/widget/BaseAdapter;
.source "MemberAdapter.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter$ViewHolder;
    }
.end annotation


# instance fields
.field private final context:Landroid/content/Context;

.field private final inflater:Landroid/view/LayoutInflater;

.field private final memberList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/Member;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/util/List;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/Member;",
            ">;)V"
        }
    .end annotation

    .line 18
    .local p2, "memberList":Ljava/util/List;, "Ljava/util/List<Lcom/LinkaMaterialProject/linkaMaterial/Member;>;"
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 19
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter;->context:Landroid/content/Context;

    .line 20
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter;->memberList:Ljava/util/List;

    .line 21
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter;->inflater:Landroid/view/LayoutInflater;

    .line 22
    return-void
.end method


# virtual methods
.method public getCount()I
    .locals 1

    .line 26
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter;->memberList:Ljava/util/List;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter;->memberList:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .locals 1
    .param p1, "position"    # I

    .line 31
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter;->memberList:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public getItemId(I)J
    .locals 2
    .param p1, "position"    # I

    .line 36
    int-to-long v0, p1

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 5
    .param p1, "position"    # I
    .param p2, "convertView"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 48
    if-nez p2, :cond_0

    .line 49
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter;->inflater:Landroid/view/LayoutInflater;

    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->card_member:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    .line 50
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter$ViewHolder;

    invoke-direct {v0}, Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter$ViewHolder;-><init>()V

    .line 51
    .local v0, "holder":Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter$ViewHolder;
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->ImgAvatar:I

    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    iput-object v1, v0, Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter$ViewHolder;->imgAvatar:Landroid/widget/ImageView;

    .line 52
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->txtUsername:I

    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, v0, Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter$ViewHolder;->txtUsername:Landroid/widget/TextView;

    .line 53
    invoke-virtual {p2, v0}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    goto :goto_0

    .line 55
    .end local v0    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter$ViewHolder;
    :cond_0
    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter$ViewHolder;

    .line 58
    .restart local v0    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter$ViewHolder;
    :goto_0
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter;->memberList:Ljava/util/List;

    invoke-interface {v1, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/LinkaMaterialProject/linkaMaterial/Member;

    .line 60
    .local v1, "member":Lcom/LinkaMaterialProject/linkaMaterial/Member;
    iget-object v2, v0, Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter$ViewHolder;->txtUsername:Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "@"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/Member;->getUsername()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 63
    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/Member;->getAvatarImageView()Landroid/widget/ImageView;

    move-result-object v2

    if-eqz v2, :cond_1

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/Member;->getAvatarImageView()Landroid/widget/ImageView;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    if-eqz v2, :cond_1

    .line 64
    iget-object v2, v0, Lcom/LinkaMaterialProject/linkaMaterial/MemberAdapter$ViewHolder;->imgAvatar:Landroid/widget/ImageView;

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/Member;->getAvatarImageView()Landroid/widget/ImageView;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 67
    :cond_1
    return-object p2
.end method
