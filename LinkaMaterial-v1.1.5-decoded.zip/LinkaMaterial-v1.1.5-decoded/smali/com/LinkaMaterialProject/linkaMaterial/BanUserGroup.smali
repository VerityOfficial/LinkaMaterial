.class public Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;
.super Landroid/app/Activity;
.source "BanUserGroup.java"


# instance fields
.field private adapter:Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;

.field private btnChat:Landroid/widget/ImageButton;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;

.field private friendsList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;",
            ">;"
        }
    .end annotation
.end field

.field private groupId:I

.field private lvFriends:Landroid/widget/ListView;

.field private myUsername:Ljava/lang/String;

.field private url:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetadapter(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->adapter:Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetfriendsList(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)Ljava/util/List;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->friendsList:Ljava/util/List;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetgroupId(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)I
    .locals 0

    iget p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->groupId:I

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetmyUsername(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->myUsername:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->url:Ljava/lang/String;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 1

    .line 19
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 27
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->url:Ljava/lang/String;

    .line 28
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->myUsername:Ljava/lang/String;

    .line 29
    const/4 v0, -0x1

    iput v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->groupId:I

    return-void
.end method

.method private fetchMembers()V
    .locals 2

    .line 115
    iget v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->groupId:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_1

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->url:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->myUsername:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 120
    :cond_0
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$5;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 185
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 186
    return-void

    .line 116
    :cond_1
    :goto_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Parametros invalidos: url="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->url:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", myUsername="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->myUsername:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", groupId="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->groupId:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "BanUserGroup"

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 117
    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 6
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 33
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 34
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->activity_chat:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->setContentView(I)V

    .line 36
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->btnHome:Landroid/widget/ImageButton;

    .line 37
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->btnChat:Landroid/widget/ImageButton;

    .line 38
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->btnOptions:Landroid/widget/ImageButton;

    .line 39
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->btnProfile:Landroid/widget/ImageButton;

    .line 40
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->lvFriends:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->lvFriends:Landroid/widget/ListView;

    .line 42
    invoke-virtual {p0}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->getIntent()Landroid/content/Intent;

    move-result-object v0

    .line 43
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "groupId"

    const/4 v2, -0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    iput v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->groupId:I

    .line 45
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->friendsList:Ljava/util/List;

    .line 46
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->friendsList:Ljava/util/List;

    invoke-direct {v1, p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;-><init>(Landroid/content/Context;Ljava/util/List;)V

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->adapter:Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;

    .line 47
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->lvFriends:Landroid/widget/ListView;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->adapter:Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 50
    :try_start_0
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v1}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 51
    .local v1, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v2, Lorg/json/JSONObject;

    const-string v3, "config.cfg"

    invoke-virtual {v1, p0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 52
    .local v2, "jsonCfg":Lorg/json/JSONObject;
    const-string v3, "FAST_LOGIN"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    .line 53
    .local v3, "fastLogin":Lorg/json/JSONObject;
    const-string v4, "SERVER"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    .line 54
    .local v4, "server":Lorg/json/JSONObject;
    const-string v5, "url"

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->url:Ljava/lang/String;

    .line 55
    const-string v5, "username"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->myUsername:Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 59
    .end local v1    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v2    # "jsonCfg":Lorg/json/JSONObject;
    .end local v3    # "fastLogin":Lorg/json/JSONObject;
    .end local v4    # "server":Lorg/json/JSONObject;
    goto :goto_0

    .line 56
    :catch_0
    move-exception v1

    .line 57
    .local v1, "e":Lorg/json/JSONException;
    invoke-virtual {v1}, Lorg/json/JSONException;->printStackTrace()V

    .line 58
    const-string v2, "BanUserGroup"

    const-string v3, "Erro ao carregar arquivo de configuracao config.cfg"

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 61
    .end local v1    # "e":Lorg/json/JSONException;
    :goto_0
    invoke-direct {p0}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->fetchMembers()V

    .line 63
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->lvFriends:Landroid/widget/ListView;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)V

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 89
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->btnHome:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$2;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 97
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->btnOptions:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$3;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 105
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;->btnProfile:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$4;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/BanUserGroup;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 112
    return-void
.end method
