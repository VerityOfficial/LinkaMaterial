.class Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity$1;
.super Ljava/lang/Object;
.source "NewGroupActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;

    .line 51
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 6
    .param p1, "v"    # Landroid/view/View;

    .line 55
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 56
    .local v0, "jsonGroup":Lorg/json/JSONObject;
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->-$$Nest$fgetedtGroupName(Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;)Landroid/widget/EditText;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    .line 57
    .local v1, "name_group":Ljava/lang/String;
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->-$$Nest$fgetedtDescription(Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;)Landroid/widget/EditText;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    .line 58
    .local v2, "description":Ljava/lang/String;
    const-string v3, "username"

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 59
    const-string v3, "name_group"

    invoke-virtual {v0, v3, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 60
    const-string v3, "description"

    invoke-virtual {v0, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 61
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "/create-group"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "post"

    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/NewGroupActivity;

    invoke-static {v3, v4, v0, v5}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 64
    nop

    .end local v0    # "jsonGroup":Lorg/json/JSONObject;
    .end local v1    # "name_group":Ljava/lang/String;
    .end local v2    # "description":Ljava/lang/String;
    goto :goto_0

    .line 62
    :catch_0
    move-exception v0

    .line 63
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 65
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    return-void
.end method
