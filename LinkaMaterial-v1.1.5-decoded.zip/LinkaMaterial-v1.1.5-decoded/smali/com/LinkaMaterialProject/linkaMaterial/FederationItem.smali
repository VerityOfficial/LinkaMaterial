.class public Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;
.super Ljava/lang/Object;
.source "FederationItem.java"


# instance fields
.field private coverImage:Ljava/lang/String;

.field private description:Ljava/lang/String;

.field private name:Ljava/lang/String;

.field private url:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "coverImage"    # Ljava/lang/String;
    .param p2, "description"    # Ljava/lang/String;
    .param p3, "name"    # Ljava/lang/String;
    .param p4, "url"    # Ljava/lang/String;

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;->coverImage:Ljava/lang/String;

    .line 9
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;->description:Ljava/lang/String;

    .line 10
    iput-object p3, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;->name:Ljava/lang/String;

    .line 11
    iput-object p4, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;->url:Ljava/lang/String;

    .line 12
    return-void
.end method


# virtual methods
.method public getCoverImage()Ljava/lang/String;
    .locals 1

    .line 13
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;->coverImage:Ljava/lang/String;

    return-object v0
.end method

.method public getDescription()Ljava/lang/String;
    .locals 1

    .line 14
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;->description:Ljava/lang/String;

    return-object v0
.end method

.method public getName()Ljava/lang/String;
    .locals 1

    .line 15
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;->name:Ljava/lang/String;

    return-object v0
.end method

.method public getUrl()Ljava/lang/String;
    .locals 1

    .line 16
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;->url:Ljava/lang/String;

    return-object v0
.end method
