.class public final synthetic Lcom/LinkaMaterialProject/linkaMaterial/GroupAdapter-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
