.class public interface abstract Lcom/LinkaMaterialProject/linkaMaterial/request$RequestBytesCallback;
.super Ljava/lang/Object;
.source "request.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/request;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "RequestBytesCallback"
.end annotation


# virtual methods
.method public abstract onError(Ljava/lang/Exception;)V
.end method

.method public abstract onSuccess([B)V
.end method
