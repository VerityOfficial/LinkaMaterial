.class Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$1;
.super Ljava/lang/Object;
.source "chatActivity.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;

    .line 83
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 4
    .param p2, "view"    # Landroid/view/View;
    .param p3, "position"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 86
    .local p1, "parent":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->-$$Nest$fgetfriendsList(Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;

    .line 87
    .local v0, "clickedItem":Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;
    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->getType()I

    move-result v1

    if-nez v1, :cond_0

    .line 88
    new-instance v1, Landroid/content/Intent;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;

    const-class v3, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 89
    .local v1, "intent":Landroid/content/Intent;
    const-string v2, "friend"

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->getUsername()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 90
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;

    invoke-virtual {v2, v1}, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->startActivity(Landroid/content/Intent;)V

    .end local v1    # "intent":Landroid/content/Intent;
    goto :goto_0

    .line 91
    :cond_0
    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->getType()I

    move-result v1

    const/4 v2, 0x1

    if-ne v1, v2, :cond_1

    .line 92
    new-instance v1, Landroid/content/Intent;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;

    const-class v3, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 93
    .restart local v1    # "intent":Landroid/content/Intent;
    const-string v2, "groupId"

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->getId()I

    move-result v3

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 94
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;

    invoke-virtual {v2, v1}, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->startActivity(Landroid/content/Intent;)V

    goto :goto_1

    .line 91
    .end local v1    # "intent":Landroid/content/Intent;
    :cond_1
    :goto_0
    nop

    .line 96
    :goto_1
    return-void
.end method
