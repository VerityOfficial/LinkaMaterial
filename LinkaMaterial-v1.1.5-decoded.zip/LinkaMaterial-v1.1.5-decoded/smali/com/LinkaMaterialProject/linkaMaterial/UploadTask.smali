.class public Lcom/LinkaMaterialProject/linkaMaterial/UploadTask;
.super Ljava/lang/Object;
.source "UploadTask.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static convertStreamToString(Ljava/io/InputStream;)Ljava/lang/String;
    .locals 2
    .param p0, "is"    # Ljava/io/InputStream;

    .line 81
    new-instance v0, Ljava/util/Scanner;

    invoke-direct {v0, p0}, Ljava/util/Scanner;-><init>(Ljava/io/InputStream;)V

    const-string v1, "\\A"

    invoke-virtual {v0, v1}, Ljava/util/Scanner;->useDelimiter(Ljava/lang/String;)Ljava/util/Scanner;

    move-result-object v0

    .line 82
    .local v0, "s":Ljava/util/Scanner;
    invoke-virtual {v0}, Ljava/util/Scanner;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Ljava/util/Scanner;->next()Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_0
    const-string v1, ""

    :goto_0
    return-object v1
.end method

.method public static uploadProfilePicture(Landroid/content/Context;Landroid/net/Uri;Ljava/lang/String;)Ljava/lang/String;
    .locals 21
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "imageUri"    # Landroid/net/Uri;
    .param p2, "targetUrl"    # Ljava/lang/String;

    .line 15
    const-string v0, "FAST_LOGIN"

    const-string v1, "\r\n"

    .line 16
    .local v1, "lineEnd":Ljava/lang/String;
    const-string v2, "--"

    .line 17
    .local v2, "twoHyphens":Ljava/lang/String;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "*****"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    invoke-virtual {v3, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 20
    .local v3, "boundary":Ljava/lang/String;
    :try_start_0
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v5

    move-object/from16 v6, p1

    invoke-virtual {v5, v6}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v5

    .line 21
    .local v5, "inputStream":Ljava/io/InputStream;
    new-instance v7, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v7}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 22
    .local v7, "byteBuffer":Ljava/io/ByteArrayOutputStream;
    const/16 v8, 0x400

    new-array v8, v8, [B

    .line 24
    .local v8, "buffer":[B
    :goto_0
    invoke-virtual {v5, v8}, Ljava/io/InputStream;->read([B)I

    move-result v9

    move v10, v9

    .local v10, "len":I
    const/4 v11, -0x1

    const/4 v12, 0x0

    if-eq v9, v11, :cond_0

    .line 25
    invoke-virtual {v7, v8, v12, v10}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_0

    .line 27
    :cond_0
    invoke-virtual {v7}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v9

    .line 28
    .local v9, "rawImageBytes":[B
    invoke-virtual {v5}, Ljava/io/InputStream;->close()V

    .line 30
    new-instance v11, Ljava/net/URL;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_6

    move-object/from16 v13, p2

    :try_start_1
    invoke-direct {v11, v13}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 31
    .local v11, "url":Ljava/net/URL;
    invoke-virtual {v11}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v14

    check-cast v14, Ljava/net/HttpURLConnection;

    .line 32
    .local v14, "conn":Ljava/net/HttpURLConnection;
    const/4 v15, 0x1

    invoke-virtual {v14, v15}, Ljava/net/HttpURLConnection;->setDoInput(Z)V

    .line 33
    invoke-virtual {v14, v15}, Ljava/net/HttpURLConnection;->setDoOutput(Z)V

    .line 34
    invoke-virtual {v14, v12}, Ljava/net/HttpURLConnection;->setUseCaches(Z)V

    .line 35
    const-string v12, "POST"

    invoke-virtual {v14, v12}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 36
    const-string v12, "Connection"

    const-string v15, "Keep-Alive"

    invoke-virtual {v14, v12, v15}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 37
    const-string v12, "Content-Type"

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_5

    const/16 v16, 0x0

    :try_start_2
    const-string v4, "multipart/form-data; boundary="

    invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v14, v12, v4}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_4

    .line 39
    :try_start_3
    new-instance v4, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v4}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 40
    .local v4, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    const-string v12, "config.cfg"
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    move-object/from16 v15, p0

    :try_start_4
    invoke-virtual {v4, v15, v12}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 41
    .local v12, "rawCfg":Ljava/lang/String;
    if-eqz v12, :cond_3

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v17

    if-nez v17, :cond_3

    .line 42
    move-object/from16 v17, v4

    .end local v4    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .local v17, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4, v12}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 43
    .local v4, "jsonCfg":Lorg/json/JSONObject;
    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v18

    if-eqz v18, :cond_2

    .line 44
    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    .line 45
    .local v0, "fastLogin":Lorg/json/JSONObject;
    move-object/from16 v18, v4

    .end local v4    # "jsonCfg":Lorg/json/JSONObject;
    .local v18, "jsonCfg":Lorg/json/JSONObject;
    const-string v4, "token_session"
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1

    move-object/from16 v19, v5

    .end local v5    # "inputStream":Ljava/io/InputStream;
    .local v19, "inputStream":Ljava/io/InputStream;
    :try_start_5
    const-string v5, ""

    invoke-virtual {v0, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 46
    .local v4, "token":Ljava/lang/String;
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_1

    .line 47
    const-string v5, "Authorization"

    move-object/from16 v20, v0

    .end local v0    # "fastLogin":Lorg/json/JSONObject;
    .local v20, "fastLogin":Lorg/json/JSONObject;
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Bearer "

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v14, v5, v0}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0

    goto :goto_2

    .line 46
    .end local v20    # "fastLogin":Lorg/json/JSONObject;
    .restart local v0    # "fastLogin":Lorg/json/JSONObject;
    :cond_1
    move-object/from16 v20, v0

    .end local v0    # "fastLogin":Lorg/json/JSONObject;
    .restart local v20    # "fastLogin":Lorg/json/JSONObject;
    goto :goto_2

    .line 51
    .end local v4    # "token":Ljava/lang/String;
    .end local v12    # "rawCfg":Ljava/lang/String;
    .end local v17    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v18    # "jsonCfg":Lorg/json/JSONObject;
    .end local v20    # "fastLogin":Lorg/json/JSONObject;
    :catch_0
    move-exception v0

    goto :goto_2

    .line 43
    .end local v19    # "inputStream":Ljava/io/InputStream;
    .local v4, "jsonCfg":Lorg/json/JSONObject;
    .restart local v5    # "inputStream":Ljava/io/InputStream;
    .restart local v12    # "rawCfg":Ljava/lang/String;
    .restart local v17    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    :cond_2
    move-object/from16 v18, v4

    move-object/from16 v19, v5

    .end local v4    # "jsonCfg":Lorg/json/JSONObject;
    .end local v5    # "inputStream":Ljava/io/InputStream;
    .restart local v18    # "jsonCfg":Lorg/json/JSONObject;
    .restart local v19    # "inputStream":Ljava/io/InputStream;
    goto :goto_2

    .line 41
    .end local v17    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v18    # "jsonCfg":Lorg/json/JSONObject;
    .end local v19    # "inputStream":Ljava/io/InputStream;
    .local v4, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .restart local v5    # "inputStream":Ljava/io/InputStream;
    :cond_3
    move-object/from16 v17, v4

    move-object/from16 v19, v5

    .end local v4    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v5    # "inputStream":Ljava/io/InputStream;
    .restart local v17    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .restart local v19    # "inputStream":Ljava/io/InputStream;
    goto :goto_2

    .line 51
    .end local v12    # "rawCfg":Ljava/lang/String;
    .end local v17    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v19    # "inputStream":Ljava/io/InputStream;
    .restart local v5    # "inputStream":Ljava/io/InputStream;
    :catch_1
    move-exception v0

    goto :goto_1

    :catch_2
    move-exception v0

    move-object/from16 v15, p0

    :goto_1
    move-object/from16 v19, v5

    .end local v5    # "inputStream":Ljava/io/InputStream;
    .restart local v19    # "inputStream":Ljava/io/InputStream;
    :goto_2
    nop

    .line 52
    :try_start_6
    new-instance v0, Ljava/io/DataOutputStream;

    invoke-virtual {v14}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v4

    invoke-direct {v0, v4}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 54
    .local v0, "dos":Ljava/io/DataOutputStream;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/io/DataOutputStream;->writeBytes(Ljava/lang/String;)V

    .line 55
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Content-Disposition: form-data; name=\"image\"; filename=\"profile.jpg\""

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/io/DataOutputStream;->writeBytes(Ljava/lang/String;)V

    .line 56
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Content-Type: image/jpeg"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/io/DataOutputStream;->writeBytes(Ljava/lang/String;)V

    .line 57
    invoke-virtual {v0, v1}, Ljava/io/DataOutputStream;->writeBytes(Ljava/lang/String;)V

    .line 59
    invoke-virtual {v0, v9}, Ljava/io/DataOutputStream;->write([B)V

    .line 60
    invoke-virtual {v0, v1}, Ljava/io/DataOutputStream;->writeBytes(Ljava/lang/String;)V

    .line 62
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/io/DataOutputStream;->writeBytes(Ljava/lang/String;)V

    .line 63
    invoke-virtual {v0}, Ljava/io/DataOutputStream;->flush()V

    .line 64
    invoke-virtual {v0}, Ljava/io/DataOutputStream;->close()V

    .line 66
    invoke-virtual {v14}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v4

    .line 67
    .local v4, "serverResponseCode":I
    const/16 v5, 0xc8

    if-ne v4, v5, :cond_4

    .line 68
    invoke-virtual {v14}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v5

    .line 69
    .local v5, "is":Ljava/io/InputStream;
    invoke-static {v5}, Lcom/LinkaMaterialProject/linkaMaterial/UploadTask;->convertStreamToString(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object v6
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_3

    return-object v6

    .line 71
    .end local v5    # "is":Ljava/io/InputStream;
    :cond_4
    return-object v16

    .line 74
    .end local v0    # "dos":Ljava/io/DataOutputStream;
    .end local v4    # "serverResponseCode":I
    .end local v7    # "byteBuffer":Ljava/io/ByteArrayOutputStream;
    .end local v8    # "buffer":[B
    .end local v9    # "rawImageBytes":[B
    .end local v10    # "len":I
    .end local v11    # "url":Ljava/net/URL;
    .end local v14    # "conn":Ljava/net/HttpURLConnection;
    .end local v19    # "inputStream":Ljava/io/InputStream;
    :catch_3
    move-exception v0

    goto :goto_4

    :catch_4
    move-exception v0

    move-object/from16 v15, p0

    goto :goto_4

    :catch_5
    move-exception v0

    move-object/from16 v15, p0

    goto :goto_3

    :catch_6
    move-exception v0

    move-object/from16 v15, p0

    move-object/from16 v13, p2

    :goto_3
    const/16 v16, 0x0

    .line 75
    .local v0, "e":Ljava/lang/Exception;
    :goto_4
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 76
    return-object v16
.end method
