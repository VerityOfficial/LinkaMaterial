.class public Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;
.super Landroid/app/Activity;
.source "feedFinder.java"


# instance fields
.field private btnChat:Landroid/widget/ImageButton;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnNewer:Landroid/widget/Button;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;

.field private btnSend:Landroid/widget/Button;

.field private edtUrl:Landroid/widget/EditText;

.field private url:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetedtUrl(Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->edtUrl:Landroid/widget/EditText;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 1

    .line 17
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 25
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->url:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 12
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 28
    const-string v0, "url"

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 29
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->activity_feed_finder:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->setContentView(I)V

    .line 30
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->btnHome:Landroid/widget/ImageButton;

    .line 31
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->btnChat:Landroid/widget/ImageButton;

    .line 32
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->btnProfile:Landroid/widget/ImageButton;

    .line 33
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->btnOptions:Landroid/widget/ImageButton;

    .line 34
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->listFederations:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ListView;

    .line 35
    .local v1, "listView":Landroid/widget/ListView;
    sget v2, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtUrl:I

    invoke-virtual {p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/EditText;

    iput-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->edtUrl:Landroid/widget/EditText;

    .line 36
    sget v2, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnSend:I

    invoke-virtual {p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->btnSend:Landroid/widget/Button;

    .line 37
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 39
    .local v2, "itemList":Ljava/util/List;, "Ljava/util/List<Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;>;"
    :try_start_0
    new-instance v3, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v3}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 40
    .local v3, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v4, Lorg/json/JSONObject;

    const-string v5, "config.cfg"

    invoke-virtual {v3, p0, v5}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 41
    .local v4, "jsonCfg":Lorg/json/JSONObject;
    const-string v5, "SERVER"

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    .line 42
    .local v5, "server":Lorg/json/JSONObject;
    invoke-virtual {v5, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v6

    iput-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->url:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 45
    .end local v3    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v4    # "jsonCfg":Lorg/json/JSONObject;
    .end local v5    # "server":Lorg/json/JSONObject;
    goto :goto_0

    .line 43
    :catch_0
    move-exception v3

    .line 44
    .local v3, "e":Ljava/lang/Exception;
    invoke-virtual {v3}, Ljava/lang/Exception;->printStackTrace()V

    .line 46
    .end local v3    # "e":Ljava/lang/Exception;
    :goto_0
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->url:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "/view-index"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4}, Lorg/json/JSONObject;-><init>()V

    const-string v5, "get"

    invoke-static {v3, v5, v4, p0}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    .line 48
    .local v3, "response":Ljava/lang/String;
    :try_start_1
    new-instance v4, Lorg/json/JSONArray;

    invoke-direct {v4, v3}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    .line 49
    .local v4, "jsonArray":Lorg/json/JSONArray;
    const/4 v5, 0x0

    .local v5, "i":I
    :goto_1
    invoke-virtual {v4}, Lorg/json/JSONArray;->length()I

    move-result v6

    if-ge v5, v6, :cond_0

    .line 50
    invoke-virtual {v4, v5}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v6

    .line 51
    .local v6, "obj":Lorg/json/JSONObject;
    new-instance v7, Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;

    const-string v8, "cover_image"

    .line 52
    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v9, "description"

    .line 53
    invoke-virtual {v6, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "name"

    .line 54
    invoke-virtual {v6, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 55
    invoke-virtual {v6, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-direct {v7, v8, v9, v10, v11}, Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 51
    invoke-interface {v2, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 49
    nop

    .end local v6    # "obj":Lorg/json/JSONObject;
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 58
    .end local v5    # "i":I
    :cond_0
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;

    invoke-direct {v0, p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;-><init>(Landroid/content/Context;Ljava/util/List;)V

    .line 59
    .local v0, "adapter":Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;
    invoke-virtual {v1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_1

    .line 62
    .end local v0    # "adapter":Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;
    .end local v4    # "jsonArray":Lorg/json/JSONArray;
    goto :goto_2

    .line 60
    :catch_1
    move-exception v0

    .line 61
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 63
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_2
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->btnSend:Landroid/widget/Button;

    new-instance v4, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder$1;

    invoke-direct {v4, p0}, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;)V

    invoke-virtual {v0, v4}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 71
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->btnChat:Landroid/widget/ImageButton;

    new-instance v4, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder$2;

    invoke-direct {v4, p0}, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;)V

    invoke-virtual {v0, v4}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 78
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->btnOptions:Landroid/widget/ImageButton;

    new-instance v4, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder$3;

    invoke-direct {v4, p0}, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;)V

    invoke-virtual {v0, v4}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 85
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;->btnProfile:Landroid/widget/ImageButton;

    new-instance v4, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder$4;

    invoke-direct {v4, p0}, Lcom/LinkaMaterialProject/linkaMaterial/feedFinder$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/feedFinder;)V

    invoke-virtual {v0, v4}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 92
    return-void
.end method
