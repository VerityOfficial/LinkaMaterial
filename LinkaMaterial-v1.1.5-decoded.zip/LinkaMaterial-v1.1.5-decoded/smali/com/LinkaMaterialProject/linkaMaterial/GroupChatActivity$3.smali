.class Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$3;
.super Ljava/lang/Object;
.source "GroupChatActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    .line 86
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 89
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity-IA;)V

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Void;

    invoke-virtual {v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$FetchMessagesTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 90
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity$3;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;->-$$Nest$fgetautoUpdateHandler(Lcom/LinkaMaterialProject/linkaMaterial/GroupChatActivity;)Landroid/os/Handler;

    move-result-object v0

    const-wide/16 v1, 0x7d0

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 91
    return-void
.end method
