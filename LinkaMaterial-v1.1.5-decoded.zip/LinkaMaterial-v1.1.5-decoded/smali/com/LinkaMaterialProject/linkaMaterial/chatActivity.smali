.class public Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;
.super Landroid/app/Activity;
.source "chatActivity.java"


# instance fields
.field private adapter:Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;

.field private btnChat:Landroid/widget/ImageButton;

.field private btnGlobalChat:Landroid/widget/Button;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnNewChat:Landroid/widget/Button;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;

.field private friendsList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;",
            ">;"
        }
    .end annotation
.end field

.field private lvFriends:Landroid/widget/ListView;

.field private myUsername:Ljava/lang/String;

.field private url:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetfriendsList(Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;)Ljava/util/List;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->friendsList:Ljava/util/List;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 1

    .line 15
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 25
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->url:Ljava/lang/String;

    .line 26
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->myUsername:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 16
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 29
    move-object/from16 v1, p0

    const-string v2, "group_name"

    const-string v3, "friends"

    const-string v4, "groups"

    const-string v5, "post"

    const-string v6, "username"

    invoke-super/range {p0 .. p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 30
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->activity_chat:I

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->setContentView(I)V

    .line 31
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnGlobalChat:I

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->btnGlobalChat:Landroid/widget/Button;

    .line 32
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->btnHome:Landroid/widget/ImageButton;

    .line 33
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->btnChat:Landroid/widget/ImageButton;

    .line 34
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->btnOptions:Landroid/widget/ImageButton;

    .line 35
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->btnProfile:Landroid/widget/ImageButton;

    .line 36
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->lvFriends:I

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    iput-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->lvFriends:Landroid/widget/ListView;

    .line 37
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnNewChat:I

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->btnNewChat:Landroid/widget/Button;

    .line 38
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->friendsList:Ljava/util/List;

    .line 40
    :try_start_0
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v0}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 41
    .local v0, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v7, Lorg/json/JSONObject;

    const-string v8, "config.cfg"

    invoke-virtual {v0, v1, v8}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 42
    .local v7, "jsonCfg":Lorg/json/JSONObject;
    const-string v8, "FAST_LOGIN"

    invoke-virtual {v7, v8}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v8

    .line 43
    .local v8, "fastLogin":Lorg/json/JSONObject;
    const-string v9, "SERVER"

    invoke-virtual {v7, v9}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v9

    .line 44
    .local v9, "server":Lorg/json/JSONObject;
    const-string v10, "url"

    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    iput-object v10, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->url:Ljava/lang/String;

    .line 45
    invoke-virtual {v8, v6}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    iput-object v10, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->myUsername:Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 48
    .end local v0    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v7    # "jsonCfg":Lorg/json/JSONObject;
    .end local v8    # "fastLogin":Lorg/json/JSONObject;
    .end local v9    # "server":Lorg/json/JSONObject;
    goto :goto_0

    .line 46
    :catch_0
    move-exception v0

    .line 47
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 50
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    :try_start_1
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 51
    .local v0, "jsonPayload":Lorg/json/JSONObject;
    iget-object v7, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->myUsername:Ljava/lang/String;

    invoke-virtual {v0, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 52
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v7, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->url:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, "/friends"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v5, v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    .line 53
    .local v6, "response":Ljava/lang/String;
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v8, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->url:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, "/my-groups"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7, v5, v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v5
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_1

    .line 54
    .local v5, "responseGroups":Ljava/lang/String;
    const-string v7, ""

    if-eqz v5, :cond_1

    :try_start_2
    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_1

    .line 55
    new-instance v8, Lorg/json/JSONObject;

    invoke-direct {v8, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 56
    .local v8, "jsonGroupsObj":Lorg/json/JSONObject;
    invoke-virtual {v8, v4}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_1

    .line 57
    invoke-virtual {v8, v4}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    .line 58
    .local v4, "groupsArray":Lorg/json/JSONArray;
    const/4 v9, 0x0

    .local v9, "i":I
    :goto_1
    invoke-virtual {v4}, Lorg/json/JSONArray;->length()I

    move-result v10

    if-ge v9, v10, :cond_1

    .line 59
    invoke-virtual {v4, v9}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v10

    .line 60
    .local v10, "groupObj":Lorg/json/JSONObject;
    invoke-virtual {v10, v2}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v11

    if-eqz v11, :cond_0

    const-string v11, "Group NONAME"

    goto :goto_2

    :cond_0
    invoke-virtual {v10, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    .line 61
    .local v11, "groupName":Ljava/lang/String;
    :goto_2
    const-string v12, "group_id"

    invoke-virtual {v10, v12}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v12

    .line 62
    .local v12, "id":I
    const-string v13, "permissions"

    invoke-virtual {v10, v13, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 63
    .local v13, "permissions":Ljava/lang/String;
    iget-object v14, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->friendsList:Ljava/util/List;

    new-instance v15, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;

    invoke-direct {v15, v12, v11, v13}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    invoke-interface {v14, v15}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 58
    nop

    .end local v10    # "groupObj":Lorg/json/JSONObject;
    .end local v11    # "groupName":Ljava/lang/String;
    .end local v12    # "id":I
    .end local v13    # "permissions":Ljava/lang/String;
    add-int/lit8 v9, v9, 0x1

    goto :goto_1

    .line 67
    .end local v4    # "groupsArray":Lorg/json/JSONArray;
    .end local v8    # "jsonGroupsObj":Lorg/json/JSONObject;
    .end local v9    # "i":I
    :cond_1
    if-eqz v6, :cond_3

    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_3

    .line 68
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2, v6}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 69
    .local v2, "jsonFriendsObj":Lorg/json/JSONObject;
    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_3

    .line 70
    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    .line 71
    .local v3, "friends":Lorg/json/JSONArray;
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_3
    invoke-virtual {v3}, Lorg/json/JSONArray;->length()I

    move-result v7

    if-ge v4, v7, :cond_3

    .line 72
    invoke-virtual {v3, v4}, Lorg/json/JSONArray;->getJSONArray(I)Lorg/json/JSONArray;

    move-result-object v7

    .line 73
    .local v7, "pair":Lorg/json/JSONArray;
    const/4 v8, 0x0

    invoke-virtual {v7, v8}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v9

    iget-object v10, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->myUsername:Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_2

    const/4 v8, 0x1

    invoke-virtual {v7, v8}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v8

    goto :goto_4

    :cond_2
    invoke-virtual {v7, v8}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v8

    .line 74
    .local v8, "friend":Ljava/lang/String;
    :goto_4
    iget-object v9, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->friendsList:Ljava/util/List;

    new-instance v10, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;

    invoke-direct {v10, v8}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;-><init>(Ljava/lang/String;)V

    invoke-interface {v9, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_2
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_2} :catch_1

    .line 71
    nop

    .end local v7    # "pair":Lorg/json/JSONArray;
    .end local v8    # "friend":Ljava/lang/String;
    add-int/lit8 v4, v4, 0x1

    goto :goto_3

    .line 80
    .end local v0    # "jsonPayload":Lorg/json/JSONObject;
    .end local v2    # "jsonFriendsObj":Lorg/json/JSONObject;
    .end local v3    # "friends":Lorg/json/JSONArray;
    .end local v4    # "i":I
    .end local v5    # "responseGroups":Ljava/lang/String;
    .end local v6    # "response":Ljava/lang/String;
    :cond_3
    goto :goto_5

    .line 78
    :catch_1
    move-exception v0

    .line 79
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 81
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_5
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;

    iget-object v2, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->friendsList:Ljava/util/List;

    invoke-direct {v0, v1, v2}, Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;-><init>(Landroid/content/Context;Ljava/util/List;)V

    iput-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->adapter:Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;

    .line 82
    iget-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->lvFriends:Landroid/widget/ListView;

    iget-object v2, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->adapter:Lcom/LinkaMaterialProject/linkaMaterial/FriendsAdapter;

    invoke-virtual {v0, v2}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 83
    iget-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->lvFriends:Landroid/widget/ListView;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$1;

    invoke-direct {v2, v1}, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 98
    iget-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->btnNewChat:Landroid/widget/Button;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$2;

    invoke-direct {v2, v1}, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 105
    iget-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->btnGlobalChat:Landroid/widget/Button;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$3;

    invoke-direct {v2, v1}, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 112
    iget-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->btnHome:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$4;

    invoke-direct {v2, v1}, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 119
    iget-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->btnOptions:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$5;

    invoke-direct {v2, v1}, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$5;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 126
    iget-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;->btnProfile:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$6;

    invoke-direct {v2, v1}, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity$6;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 133
    return-void
.end method
