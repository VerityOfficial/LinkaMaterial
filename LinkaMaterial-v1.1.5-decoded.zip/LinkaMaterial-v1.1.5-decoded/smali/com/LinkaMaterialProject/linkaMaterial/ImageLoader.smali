.class public Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;
.super Ljava/lang/Object;
.source "ImageLoader.java"


# instance fields
.field private final mainHandler:Landroid/os/Handler;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;->mainHandler:Landroid/os/Handler;

    return-void
.end method

.method private calculateInSampleSize(Landroid/graphics/BitmapFactory$Options;II)I
    .locals 6
    .param p1, "options"    # Landroid/graphics/BitmapFactory$Options;
    .param p2, "reqWidth"    # I
    .param p3, "reqHeight"    # I

    .line 55
    iget v0, p1, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    .line 56
    .local v0, "height":I
    iget v1, p1, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    .line 57
    .local v1, "width":I
    const/4 v2, 0x1

    .line 59
    .local v2, "inSampleSize":I
    if-gt v0, p3, :cond_0

    if-le v1, p2, :cond_1

    .line 60
    :cond_0
    div-int/lit8 v3, v0, 0x2

    .line 61
    .local v3, "halfHeight":I
    div-int/lit8 v4, v1, 0x2

    .line 63
    .local v4, "halfWidth":I
    :goto_0
    div-int v5, v3, v2

    if-lt v5, p3, :cond_1

    div-int v5, v4, v2

    if-lt v5, p2, :cond_1

    .line 64
    mul-int/lit8 v2, v2, 0x2

    goto :goto_0

    .line 67
    .end local v3    # "halfHeight":I
    .end local v4    # "halfWidth":I
    :cond_1
    return v2
.end method

.method private decodeSampledBitmapFromByteArray([BII)Landroid/graphics/Bitmap;
    .locals 5
    .param p1, "data"    # [B
    .param p2, "reqWidth"    # I
    .param p3, "reqHeight"    # I

    .line 24
    const/4 v0, 0x0

    if-eqz p1, :cond_1

    array-length v1, p1

    if-nez v1, :cond_0

    goto :goto_0

    .line 30
    :cond_0
    :try_start_0
    new-instance v1, Landroid/graphics/BitmapFactory$Options;

    invoke-direct {v1}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    .line 31
    .local v1, "options":Landroid/graphics/BitmapFactory$Options;
    const/4 v2, 0x1

    iput-boolean v2, v1, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    .line 32
    array-length v3, p1

    const/4 v4, 0x0

    invoke-static {p1, v4, v3, v1}, Landroid/graphics/BitmapFactory;->decodeByteArray([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    .line 35
    invoke-direct {p0, v1, p2, p3}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;->calculateInSampleSize(Landroid/graphics/BitmapFactory$Options;II)I

    move-result v3

    iput v3, v1, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    .line 39
    iput-boolean v4, v1, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    .line 40
    sget-object v3, Landroid/graphics/Bitmap$Config;->RGB_565:Landroid/graphics/Bitmap$Config;

    iput-object v3, v1, Landroid/graphics/BitmapFactory$Options;->inPreferredConfig:Landroid/graphics/Bitmap$Config;

    .line 41
    iput-boolean v2, v1, Landroid/graphics/BitmapFactory$Options;->inPurgeable:Z

    .line 42
    iput-boolean v2, v1, Landroid/graphics/BitmapFactory$Options;->inInputShareable:Z

    .line 44
    array-length v2, p1

    invoke-static {p1, v4, v2, v1}, Landroid/graphics/BitmapFactory;->decodeByteArray([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 49
    .end local v1    # "options":Landroid/graphics/BitmapFactory$Options;
    :catch_0
    move-exception v1

    .line 50
    .local v1, "e":Ljava/lang/Exception;
    return-object v0

    .line 45
    .end local v1    # "e":Ljava/lang/Exception;
    :catch_1
    move-exception v1

    .line 47
    .local v1, "e":Ljava/lang/OutOfMemoryError;
    invoke-static {}, Ljava/lang/System;->gc()V

    .line 48
    return-object v0

    .line 25
    .end local v1    # "e":Ljava/lang/OutOfMemoryError;
    :cond_1
    :goto_0
    return-object v0
.end method


# virtual methods
.method public LoadImageUrl(Ljava/lang/String;Landroid/widget/ImageView;)V
    .locals 2
    .param p1, "imageUrl"    # Ljava/lang/String;
    .param p2, "targetView"    # Landroid/widget/ImageView;

    .line 99
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$2;

    invoke-direct {v1, p0, p1, p2}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;Ljava/lang/String;Landroid/widget/ImageView;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 104
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 105
    return-void
.end method

.method public processImageData(Ljava/lang/String;Landroid/widget/ImageView;)V
    .locals 5
    .param p1, "imageUrl"    # Ljava/lang/String;
    .param p2, "targetView"    # Landroid/widget/ImageView;

    .line 71
    if-eqz p2, :cond_2

    if-eqz p1, :cond_2

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_2

    const-string v0, "null"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 75
    :cond_0
    invoke-virtual {p2}, Landroid/widget/ImageView;->getContext()Landroid/content/Context;

    move-result-object v0

    .line 76
    .local v0, "appContext":Landroid/content/Context;
    const-string v1, "GET"

    invoke-static {p1, v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestBytes(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)[B

    move-result-object v1

    .line 78
    .local v1, "rawBytes":[B
    if-eqz v1, :cond_1

    array-length v2, v1

    if-lez v2, :cond_1

    .line 80
    const/16 v2, 0x90

    invoke-direct {p0, v1, v2, v2}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;->decodeSampledBitmapFromByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 82
    .local v2, "decodedBitmap":Landroid/graphics/Bitmap;
    if-eqz v2, :cond_1

    .line 83
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;->mainHandler:Landroid/os/Handler;

    new-instance v4, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$1;

    invoke-direct {v4, p0, p2, v2}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;Landroid/widget/ImageView;Landroid/graphics/Bitmap;)V

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 96
    .end local v2    # "decodedBitmap":Landroid/graphics/Bitmap;
    :cond_1
    return-void

    .line 72
    .end local v0    # "appContext":Landroid/content/Context;
    .end local v1    # "rawBytes":[B
    :cond_2
    :goto_0
    return-void
.end method

.method public viewProfilePicture(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;)V
    .locals 2
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "username"    # Ljava/lang/String;
    .param p3, "targetImageView"    # Landroid/widget/ImageView;

    .line 108
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$3;

    invoke-direct {v1, p0, p1, p2, p3}, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 143
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 144
    return-void
.end method
