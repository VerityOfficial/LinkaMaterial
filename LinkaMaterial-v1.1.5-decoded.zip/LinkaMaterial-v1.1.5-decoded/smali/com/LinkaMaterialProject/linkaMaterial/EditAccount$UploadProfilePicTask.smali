.class Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$UploadProfilePicTask;
.super Landroid/os/AsyncTask;
.source "EditAccount.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "UploadProfilePicTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Landroid/net/Uri;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;


# direct methods
.method private constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;)V
    .locals 0

    .line 108
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$UploadProfilePicTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;Lcom/LinkaMaterialProject/linkaMaterial/EditAccount-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$UploadProfilePicTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;)V

    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 108
    check-cast p1, [Landroid/net/Uri;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$UploadProfilePicTask;->doInBackground([Landroid/net/Uri;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Landroid/net/Uri;)Ljava/lang/String;
    .locals 3
    .param p1, "uris"    # [Landroid/net/Uri;

    .line 111
    const/4 v0, 0x0

    aget-object v0, p1, v0

    .line 112
    .local v0, "selectedImageUri":Landroid/net/Uri;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$UploadProfilePicTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/upload-profile"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 113
    .local v1, "fullUrl":Ljava/lang/String;
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$UploadProfilePicTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;

    invoke-static {v2, v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/UploadTask;->uploadProfilePicture(Landroid/content/Context;Landroid/net/Uri;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    return-object v2
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 108
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$UploadProfilePicTask;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 3
    .param p1, "result"    # Ljava/lang/String;

    .line 118
    nop

    .line 121
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/EditAccount$UploadProfilePicTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/EditAccount;

    .line 118
    const/4 v1, 0x0

    if-eqz p1, :cond_0

    .line 119
    const-string v2, "Profile picture updated!"

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 121
    :cond_0
    const-string v2, "Error in update pfp"

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 123
    :goto_0
    return-void
.end method
