.class Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$1;
.super Ljava/lang/Object;
.source "AddGroupMember.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;

    .line 65
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 13
    .param p2, "view"    # Landroid/view/View;
    .param p3, "position"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 68
    .local p1, "parent":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    const-string v0, "post"

    const-string v1, "group_id"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->-$$Nest$fgetfriendsList(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;)Ljava/util/List;

    move-result-object v2

    move/from16 v3, p3

    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;

    .line 69
    .local v2, "clickedItem":Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;
    invoke-virtual {v2}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->getUsername()Ljava/lang/String;

    move-result-object v4

    .line 71
    .local v4, "friendName":Ljava/lang/String;
    :try_start_0
    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5}, Lorg/json/JSONObject;-><init>()V

    .line 72
    .local v5, "jsonInvite":Lorg/json/JSONObject;
    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;

    invoke-virtual {v6}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->getIntent()Landroid/content/Intent;

    move-result-object v6

    .line 73
    .local v6, "intentId":Landroid/content/Intent;
    const/4 v7, -0x1

    invoke-virtual {v6, v1, v7}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v7

    .line 74
    .local v7, "group_id":I
    const-string v8, "username"

    iget-object v9, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;

    invoke-static {v9}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->-$$Nest$fgetmyUsername(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v5, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 75
    const-string v8, "acess_limit"

    const/4 v9, 0x1

    invoke-virtual {v5, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 76
    const-string v8, "expire_at"

    const-string v9, "never expire"

    invoke-virtual {v5, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 77
    invoke-virtual {v5, v1, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 78
    new-instance v1, Lorg/json/JSONObject;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v9, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;

    invoke-static {v9}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, "/generate-invite"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    iget-object v9, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;

    invoke-static {v8, v0, v5, v9}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v1, v8}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 79
    .local v1, "responseInvite":Lorg/json/JSONObject;
    const-string v8, "code"

    const-string v9, ""

    invoke-virtual {v1, v8, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 80
    .local v8, "code":Ljava/lang/String;
    new-instance v9, Lorg/json/JSONObject;

    invoke-direct {v9}, Lorg/json/JSONObject;-><init>()V

    .line 81
    .local v9, "jsonMessage":Lorg/json/JSONObject;
    const-string v10, "receiver"

    invoke-virtual {v9, v10, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 82
    const-string v10, "sender"

    iget-object v11, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;

    invoke-static {v11}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->-$$Nest$fgetmyUsername(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v9, v10, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 83
    const-string v10, "message"

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "[INVITE]"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v9, v10, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 84
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v11, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;

    invoke-static {v11}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, "/send-message"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    iget-object v11, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;

    invoke-static {v10, v0, v9, v11}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 87
    nop

    .end local v1    # "responseInvite":Lorg/json/JSONObject;
    .end local v5    # "jsonInvite":Lorg/json/JSONObject;
    .end local v6    # "intentId":Landroid/content/Intent;
    .end local v7    # "group_id":I
    .end local v8    # "code":Ljava/lang/String;
    .end local v9    # "jsonMessage":Lorg/json/JSONObject;
    goto :goto_0

    .line 85
    :catch_0
    move-exception v0

    .line 86
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 88
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    invoke-virtual {v2}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->getType()I

    move-result v0

    if-nez v0, :cond_0

    .line 89
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;

    const-class v5, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-direct {v0, v1, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 90
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "friend"

    invoke-virtual {v2}, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->getUsername()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v1, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 91
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/AddGroupMember;->startActivity(Landroid/content/Intent;)V

    .line 93
    .end local v0    # "intent":Landroid/content/Intent;
    :cond_0
    return-void
.end method
