.class public final Lcom/LinkaMaterialProject/linkaMaterial/R$dimen;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "dimen"
.end annotation


# static fields
.field public static app_bar_height:I = 0x7f020000

.field public static home_action_height:I = 0x7f020001

.field public static home_tab_height:I = 0x7f020002

.field public static navigation_bar_height:I = 0x7f020003

.field public static navigation_icon_padding_vertical:I = 0x7f020004


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
