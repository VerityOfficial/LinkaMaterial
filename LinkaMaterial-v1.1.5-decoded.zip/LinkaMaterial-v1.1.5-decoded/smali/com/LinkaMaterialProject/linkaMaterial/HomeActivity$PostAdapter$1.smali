.class Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$1;
.super Ljava/lang/Object;
.source "HomeActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;->getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;

.field final synthetic val$position:I


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;I)V
    .locals 0
    .param p1, "this$1"    # Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 239
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;

    iput p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$1;->val$position:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 242
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;

    iget-object v1, v1, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    const-class v2, Lcom/LinkaMaterialProject/linkaMaterial/ViewProfile;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 243
    .local v0, "intent":Landroid/content/Intent;
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;->-$$Nest$fgetlist(Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;)Ljava/util/ArrayList;

    move-result-object v1

    iget v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$1;->val$position:I

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lorg/json/JSONObject;

    .line 244
    .local v1, "post":Lorg/json/JSONObject;
    const-string v2, "user"

    const-string v3, "entity404"

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "username"

    invoke-virtual {v1, v3, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 245
    .local v2, "usernameProfile":Ljava/lang/String;
    const-string v3, "usernameProfile"

    invoke-virtual {v0, v3, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 246
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;

    iget-object v3, v3, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity$PostAdapter;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;

    invoke-virtual {v3, v0}, Lcom/LinkaMaterialProject/linkaMaterial/HomeActivity;->startActivity(Landroid/content/Intent;)V

    .line 247
    return-void
.end method
