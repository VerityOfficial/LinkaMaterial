.class Lcom/LinkaMaterialProject/linkaMaterial/newPost$UploadImageTask;
.super Landroid/os/AsyncTask;
.source "newPost.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/newPost;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "UploadImageTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Landroid/net/Uri;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;


# direct methods
.method private constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/newPost;)V
    .locals 0

    .line 70
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$UploadImageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/newPost;Lcom/LinkaMaterialProject/linkaMaterial/newPost-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/newPost$UploadImageTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/newPost;)V

    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 70
    check-cast p1, [Landroid/net/Uri;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/newPost$UploadImageTask;->doInBackground([Landroid/net/Uri;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Landroid/net/Uri;)Ljava/lang/String;
    .locals 8
    .param p1, "uris"    # [Landroid/net/Uri;

    .line 73
    const/4 v0, 0x0

    aget-object v1, p1, v0

    .line 75
    .local v1, "selectedImageUri":Landroid/net/Uri;
    :try_start_0
    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v2}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 76
    .local v2, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$UploadImageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    const-string v4, "config.cfg"

    invoke-virtual {v2, v3, v4}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 77
    .local v3, "rawCfg":Ljava/lang/String;
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 78
    .local v4, "jsonCfg":Lorg/json/JSONObject;
    const-string v5, "SERVER"

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 79
    .local v5, "server":Lorg/json/JSONObject;
    const-string v6, "http://linkaProject.pythonanywhere.com"

    if-eqz v5, :cond_0

    :try_start_1
    const-string v7, "url"

    invoke-virtual {v5, v7, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 81
    .local v6, "url":Ljava/lang/String;
    :cond_0
    const-string v7, "/"

    invoke-virtual {v6, v7}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_1

    .line 82
    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v7

    add-int/lit8 v7, v7, -0x1

    invoke-virtual {v6, v0, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    move-object v6, v0

    .line 85
    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v7, "/upload-image"

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 86
    .local v0, "fullUrl":Ljava/lang/String;
    iget-object v7, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$UploadImageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    invoke-static {v7, v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/UploadTask;->uploadProfilePicture(Landroid/content/Context;Landroid/net/Uri;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    return-object v7

    .line 87
    .end local v0    # "fullUrl":Ljava/lang/String;
    .end local v2    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v3    # "rawCfg":Ljava/lang/String;
    .end local v4    # "jsonCfg":Lorg/json/JSONObject;
    .end local v5    # "server":Lorg/json/JSONObject;
    .end local v6    # "url":Ljava/lang/String;
    :catch_0
    move-exception v0

    .line 88
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 90
    .end local v0    # "e":Ljava/lang/Exception;
    const/4 v0, 0x0

    return-object v0
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 70
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/newPost$UploadImageTask;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 6
    .param p1, "result"    # Ljava/lang/String;

    .line 95
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$UploadImageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->-$$Nest$fgetbtnImage(Lcom/LinkaMaterialProject/linkaMaterial/newPost;)Landroid/widget/Button;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 96
    const/4 v0, 0x0

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1

    .line 98
    :try_start_0
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 99
    .local v1, "jsonResponse":Lorg/json/JSONObject;
    const-string v2, "image_url"

    const-string v3, ""

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 101
    .local v2, "imageUrl":Ljava/lang/String;
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 105
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$UploadImageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    .line 101
    if-nez v3, :cond_0

    .line 102
    :try_start_1
    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->-$$Nest$fgettextPost(Lcom/LinkaMaterialProject/linkaMaterial/newPost;)Landroid/widget/EditText;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\n[IMAGE]"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/EditText;->append(Ljava/lang/CharSequence;)V

    .line 103
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$UploadImageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    const-string v4, "Image uploaded!"

    invoke-static {v3, v4, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 105
    :cond_0
    const-string v3, "Invalid response format"

    invoke-static {v4, v3, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/Toast;->show()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    .line 107
    .end local v1    # "jsonResponse":Lorg/json/JSONObject;
    .end local v2    # "imageUrl":Ljava/lang/String;
    :catch_0
    move-exception v1

    .line 108
    .local v1, "e":Ljava/lang/Exception;
    invoke-virtual {v1}, Ljava/lang/Exception;->printStackTrace()V

    .line 109
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$UploadImageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    const-string v3, "Error parsing server response"

    invoke-static {v2, v3, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 110
    .end local v1    # "e":Ljava/lang/Exception;
    :goto_0
    goto :goto_1

    .line 112
    :cond_1
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$UploadImageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    const-string v2, "Error in upload image"

    invoke-static {v1, v2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 114
    :goto_1
    return-void
.end method
