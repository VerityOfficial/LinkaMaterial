.class public final synthetic Lcom/LinkaMaterialProject/linkaMaterial/ChannelAdapter-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
