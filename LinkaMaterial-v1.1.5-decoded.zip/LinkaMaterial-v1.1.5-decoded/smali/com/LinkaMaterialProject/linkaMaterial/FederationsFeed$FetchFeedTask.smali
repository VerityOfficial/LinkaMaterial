.class Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$FetchFeedTask;
.super Landroid/os/AsyncTask;
.source "FederationsFeed.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "FetchFeedTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/String;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field private requestedUrl:Ljava/lang/String;

.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;


# direct methods
.method private constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;)V
    .locals 0

    .line 241
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$FetchFeedTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$FetchFeedTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;)V

    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 241
    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$FetchFeedTask;->doInBackground([Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .param p1, "urls"    # [Ljava/lang/String;

    .line 247
    const/4 v0, 0x0

    aget-object v0, p1, v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$FetchFeedTask;->requestedUrl:Ljava/lang/String;

    .line 249
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Requesting feed at URL: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$FetchFeedTask;->requestedUrl:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "MATERIAL_FEED"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 254
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$FetchFeedTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$FetchFeedTask;->requestedUrl:Ljava/lang/String;

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const-string v3, "GET"

    invoke-virtual {v0, v1, v3, v2}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 241
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$FetchFeedTask;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 8
    .param p1, "result"    # Ljava/lang/String;

    .line 263
    const-string v0, "data"

    const-string v1, "feed"

    const-string v2, "posts"

    const/4 v3, 0x0

    if-eqz p1, :cond_9

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    if-nez v4, :cond_0

    goto/16 :goto_4

    .line 272
    :cond_0
    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    .line 274
    .local v4, "trimmed":Ljava/lang/String;
    const-string v5, "<"

    invoke-virtual {v4, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    .line 284
    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$FetchFeedTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;

    .line 274
    if-eqz v5, :cond_1

    .line 275
    const-string v0, "Error: Server returned HTML"

    const/4 v1, 0x1

    invoke-static {v6, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    .line 279
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 280
    return-void

    .line 284
    :cond_1
    :try_start_0
    invoke-static {v6}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->-$$Nest$fgetpostsList(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;)Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->clear()V

    .line 286
    const/4 v5, 0x0

    .line 288
    .local v5, "jsonArray":Lorg/json/JSONArray;
    const-string v6, "["

    invoke-virtual {v4, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_2

    .line 289
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0, v4}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v5, v0

    goto :goto_0

    .line 290
    :cond_2
    const-string v6, "{"

    invoke-virtual {v4, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_5

    .line 291
    new-instance v6, Lorg/json/JSONObject;

    invoke-direct {v6, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 293
    .local v6, "jsonObject":Lorg/json/JSONObject;
    invoke-virtual {v6, v2}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_3

    .line 294
    invoke-virtual {v6, v2}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    move-object v5, v0

    goto :goto_0

    .line 295
    :cond_3
    invoke-virtual {v6, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4

    .line 296
    invoke-virtual {v6, v1}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    move-object v5, v0

    goto :goto_0

    .line 297
    :cond_4
    invoke-virtual {v6, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_5

    .line 298
    invoke-virtual {v6, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    move-object v5, v0

    .line 302
    .end local v6    # "jsonObject":Lorg/json/JSONObject;
    :cond_5
    :goto_0
    if-eqz v5, :cond_8

    .line 303
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_1
    invoke-virtual {v5}, Lorg/json/JSONArray;->length()I

    move-result v1

    if-ge v0, v1, :cond_7

    .line 304
    invoke-virtual {v5, v0}, Lorg/json/JSONArray;->opt(I)Ljava/lang/Object;

    move-result-object v1

    instance-of v1, v1, Lorg/json/JSONObject;

    if-eqz v1, :cond_6

    .line 305
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$FetchFeedTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->-$$Nest$fgetpostsList(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v5, v0}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 303
    :cond_6
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 309
    .end local v0    # "i":I
    :cond_7
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$FetchFeedTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->-$$Nest$fgetpostAdapter(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;)Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;

    move-result-object v0

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;->notifyDataSetChanged()V

    goto :goto_2

    .line 311
    :cond_8
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$FetchFeedTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;

    const-string v1, "Error: Incompatible JSON structure"

    invoke-static {v0, v1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    .line 315
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 323
    .end local v5    # "jsonArray":Lorg/json/JSONArray;
    :goto_2
    goto :goto_3

    .line 317
    :catch_0
    move-exception v0

    .line 318
    .local v0, "e":Lorg/json/JSONException;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "JSONException while processing posts: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 321
    invoke-virtual {v0}, Lorg/json/JSONException;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 318
    const-string v2, "MATERIAL_FEED"

    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 324
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_3
    return-void

    .line 264
    .end local v4    # "trimmed":Ljava/lang/String;
    :cond_9
    :goto_4
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$FetchFeedTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;

    const-string v1, "Error: Server did not respond"

    invoke-static {v0, v1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    .line 268
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 269
    return-void
.end method
