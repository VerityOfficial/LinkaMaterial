.class Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6$1;
.super Ljava/lang/Object;
.source "GenerateInvite.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;

.field final synthetic val$novasList:Ljava/util/List;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;Ljava/util/List;)V
    .locals 0
    .param p1, "this$1"    # Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 172
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6$1;->val$novasList:Ljava/util/List;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 175
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;

    iget-object v0, v0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->-$$Nest$fgetinviteList(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 176
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;

    iget-object v0, v0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->-$$Nest$fgetinviteList(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)Ljava/util/List;

    move-result-object v0

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6$1;->val$novasList:Ljava/util/List;

    invoke-interface {v0, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 177
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;

    iget-object v0, v0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->-$$Nest$fgetadapter(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter;

    move-result-object v0

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter;->notifyDataSetChanged()V

    .line 178
    return-void
.end method
