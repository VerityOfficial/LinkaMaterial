.class Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;
.super Landroid/os/AsyncTask;
.source "DmExternalChat.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "SendMessageTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/Void;",
        "Ljava/lang/Void;",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field private messageToSend:Ljava/lang/String;

.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;


# direct methods
.method public constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;Ljava/lang/String;)V
    .locals 0
    .param p2, "message"    # Ljava/lang/String;

    .line 165
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    .line 166
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;->messageToSend:Ljava/lang/String;

    .line 167
    return-void
.end method


# virtual methods
.method protected varargs doInBackground([Ljava/lang/Void;)Ljava/lang/Boolean;
    .locals 11
    .param p1, "params"    # [Ljava/lang/Void;

    .line 171
    const/4 v0, 0x0

    :try_start_0
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_2

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->-$$Nest$fgetother_user(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->-$$Nest$fgetother_user(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    goto/16 :goto_1

    .line 174
    :cond_0
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->-$$Nest$fgetother_user(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "@"

    const-string v3, ""

    invoke-virtual {v1, v2, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 175
    .local v1, "cleanOtherUser":Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/send-request"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 176
    .local v2, "fullUrl":Ljava/lang/String;
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    .line 177
    .local v3, "jsonResponse":Lorg/json/JSONObject;
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4}, Lorg/json/JSONObject;-><init>()V

    .line 178
    .local v4, "json_chat":Lorg/json/JSONObject;
    const-string v5, "sender"

    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-static {v6}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 179
    const-string v5, "receiver"

    invoke-virtual {v4, v5, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 180
    const-string v5, "message"

    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;->messageToSend:Ljava/lang/String;

    invoke-virtual {v4, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 181
    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-virtual {v5}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->getIntent()Landroid/content/Intent;

    move-result-object v5

    const-string v6, "urlDestiny"

    invoke-virtual {v5, v6}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 182
    .local v5, "urlDestiny":Ljava/lang/String;
    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-virtual {v6}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->getIntent()Landroid/content/Intent;

    move-result-object v6

    const-string v7, "destiny"

    invoke-virtual {v6, v7}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 183
    .local v6, "destiny":Ljava/lang/String;
    const-string v7, "url"

    invoke-virtual {v3, v7, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 184
    const-string v7, "route"

    const-string v8, "/view"

    invoke-virtual {v3, v7, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 185
    const-string v7, "payload"

    invoke-virtual {v3, v7, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 186
    new-instance v7, Lorg/json/JSONObject;

    invoke-direct {v7}, Lorg/json/JSONObject;-><init>()V

    .line 187
    .local v7, "jsonHeaders":Lorg/json/JSONObject;
    const-string v8, "Authorization"

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "Bearer "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    iget-object v10, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-static {v10}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->-$$Nest$fgettoken_session(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 188
    const-string v8, "headers"

    invoke-virtual {v3, v8, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 189
    const-string v8, "post"

    iget-object v9, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-static {v2, v8, v3, v9}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v8

    .line 190
    .local v8, "response":Ljava/lang/String;
    if-eqz v8, :cond_1

    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_1

    const/4 v9, 0x1

    goto :goto_0

    :cond_1
    const/4 v9, 0x0

    :goto_0
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 172
    .end local v1    # "cleanOtherUser":Ljava/lang/String;
    .end local v2    # "fullUrl":Ljava/lang/String;
    .end local v3    # "jsonResponse":Lorg/json/JSONObject;
    .end local v4    # "json_chat":Lorg/json/JSONObject;
    .end local v5    # "urlDestiny":Ljava/lang/String;
    .end local v6    # "destiny":Ljava/lang/String;
    .end local v7    # "jsonHeaders":Lorg/json/JSONObject;
    .end local v8    # "response":Ljava/lang/String;
    :cond_2
    :goto_1
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 191
    :catch_0
    move-exception v1

    .line 192
    .local v1, "e":Ljava/lang/Exception;
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0
.end method

.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 163
    check-cast p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;->doInBackground([Ljava/lang/Void;)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method

.method protected onPostExecute(Ljava/lang/Boolean;)V
    .locals 4
    .param p1, "success"    # Ljava/lang/Boolean;

    .line 197
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 198
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    const/4 v3, 0x0

    invoke-direct {v0, v2, v3}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat-IA;)V

    new-array v1, v1, [Ljava/lang/Void;

    invoke-virtual {v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$FetchMessagesTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    goto :goto_0

    .line 200
    :cond_0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    const-string v2, "Error in mesage sending"

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 202
    :goto_0
    return-void
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 163
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$SendMessageTask;->onPostExecute(Ljava/lang/Boolean;)V

    return-void
.end method
