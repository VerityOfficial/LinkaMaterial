.class Lcom/LinkaMaterialProject/linkaMaterial/newPost$1;
.super Ljava/lang/Object;
.source "newPost.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/newPost;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/newPost;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    .line 32
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 5
    .param p1, "v"    # Landroid/view/View;

    .line 35
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->-$$Nest$fgettextPost(Lcom/LinkaMaterialProject/linkaMaterial/newPost;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 36
    .local v0, "postContent":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    .line 40
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    .line 36
    const/4 v3, 0x0

    if-eqz v1, :cond_0

    .line 37
    const-string v1, "write something!"

    invoke-static {v2, v1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 38
    return-void

    .line 40
    :cond_0
    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->-$$Nest$fgetbtnSend(Lcom/LinkaMaterialProject/linkaMaterial/newPost;)Landroid/widget/Button;

    move-result-object v1

    invoke-virtual {v1, v3}, Landroid/widget/Button;->setEnabled(Z)V

    .line 41
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/newPost$SendPostTask;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    const/4 v4, 0x0

    invoke-direct {v1, v2, v4}, Lcom/LinkaMaterialProject/linkaMaterial/newPost$SendPostTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/newPost;Lcom/LinkaMaterialProject/linkaMaterial/newPost-IA;)V

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/String;

    aput-object v0, v2, v3

    invoke-virtual {v1, v2}, Lcom/LinkaMaterialProject/linkaMaterial/newPost$SendPostTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 42
    return-void
.end method
