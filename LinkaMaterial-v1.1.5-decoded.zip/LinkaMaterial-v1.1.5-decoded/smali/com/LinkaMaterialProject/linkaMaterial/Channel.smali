.class public Lcom/LinkaMaterialProject/linkaMaterial/Channel;
.super Ljava/lang/Object;
.source "Channel.java"


# instance fields
.field private description:Ljava/lang/String;

.field private name:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "description"    # Ljava/lang/String;

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/Channel;->name:Ljava/lang/String;

    .line 7
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/Channel;->description:Ljava/lang/String;

    .line 8
    return-void
.end method


# virtual methods
.method public getDescription()Ljava/lang/String;
    .locals 1

    .line 13
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/Channel;->description:Ljava/lang/String;

    return-object v0
.end method

.method public getName()Ljava/lang/String;
    .locals 1

    .line 10
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/Channel;->name:Ljava/lang/String;

    return-object v0
.end method
