.class public Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;
.super Landroid/app/Activity;
.source "FederationsFeed.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;,
        Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$FetchFeedTask;
    }
.end annotation


# static fields
.field private static final IMAGE_PATTERN:Ljava/util/regex/Pattern;


# instance fields
.field private baseUrl:Ljava/lang/String;

.field private btnChat:Landroid/widget/ImageButton;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;

.field private currentUrl:Ljava/lang/String;

.field private listViewPosts:Landroid/widget/ListView;

.field private newPost:Landroid/widget/Button;

.field private postAdapter:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;

.field private postsList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lorg/json/JSONObject;",
            ">;"
        }
    .end annotation
.end field

.field private username:Ljava/lang/String;


# direct methods
.method public static synthetic $r8$lambda$3bBZJIijvLFQ-X23UX568LnDGwY(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->lambda$onCreate$3(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$GnVZJb4w8J0tBtys8Eb68dsten0(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->lambda$onCreate$2(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$QRJyY5JyupF12Q24ZrgbeAQAutw(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->lambda$onCreate$0(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$hvBJcLXrH_qrz2akw0oSXzTdWYM(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->lambda$onCreate$1(Landroid/view/View;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$fgetpostAdapter(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;)Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->postAdapter:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetpostsList(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;)Ljava/util/ArrayList;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->postsList:Ljava/util/ArrayList;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mextractImageUrl(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->extractImageUrl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mremoveImageMarkers(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->removeImageMarkers(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 2

    .line 58
    const-string v0, "\\[IMAGE\\]\\s*\\(?((?:https?://)[^\\s\\)]+)\\)?"

    const/4 v1, 0x2

    invoke-static {v0, v1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;I)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->IMAGE_PATTERN:Ljava/util/regex/Pattern;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 34
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 46
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->username:Ljava/lang/String;

    .line 47
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->currentUrl:Ljava/lang/String;

    .line 48
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->baseUrl:Ljava/lang/String;

    return-void
.end method

.method private extractImageUrl(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p1, "text"    # Ljava/lang/String;

    .line 209
    const-string v0, ""

    if-eqz p1, :cond_2

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    .line 213
    :cond_0
    sget-object v1, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->IMAGE_PATTERN:Ljava/util/regex/Pattern;

    invoke-virtual {v1, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    .line 215
    .local v1, "matcher":Ljava/util/regex/Matcher;
    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v2

    if-nez v2, :cond_1

    .line 216
    return-object v0

    .line 219
    :cond_1
    const/4 v0, 0x1

    invoke-virtual {v1, v0}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->sanitizarUrlImagem(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 210
    .end local v1    # "matcher":Ljava/util/regex/Matcher;
    :cond_2
    :goto_0
    return-object v0
.end method

.method private formatUrl(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p1, "rawUrl"    # Ljava/lang/String;

    .line 179
    if-eqz p1, :cond_3

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_1

    .line 183
    :cond_0
    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 185
    .local v0, "formatted":Ljava/lang/String;
    const-string v1, "http://"

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_1

    .line 186
    const-string v2, "https://"

    invoke-virtual {v0, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_1

    .line 187
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 190
    :cond_1
    :goto_0
    const-string v1, "/"

    invoke-virtual {v0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2

    .line 191
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    const/4 v2, 0x0

    invoke-virtual {v0, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    .line 194
    :cond_2
    return-object v0

    .line 180
    .end local v0    # "formatted":Ljava/lang/String;
    :cond_3
    :goto_1
    const-string v0, ""

    return-object v0
.end method

.method private synthetic lambda$onCreate$0(Landroid/view/View;)V
    .locals 2
    .param p1, "v"    # Landroid/view/View;

    .line 119
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/LinkaMaterialProject/linkaMaterial/chatActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private synthetic lambda$onCreate$1(Landroid/view/View;)V
    .locals 2
    .param p1, "v"    # Landroid/view/View;

    .line 128
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/LinkaMaterialProject/linkaMaterial/optionActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private synthetic lambda$onCreate$2(Landroid/view/View;)V
    .locals 2
    .param p1, "v"    # Landroid/view/View;

    .line 137
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/LinkaMaterialProject/linkaMaterial/profile;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private synthetic lambda$onCreate$3(Landroid/view/View;)V
    .locals 2
    .param p1, "v"    # Landroid/view/View;

    .line 146
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private removeImageMarkers(Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .param p1, "text"    # Ljava/lang/String;

    .line 226
    const-string v0, ""

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    .line 230
    :cond_0
    sget-object v1, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->IMAGE_PATTERN:Ljava/util/regex/Pattern;

    .line 231
    invoke-virtual {v1, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    .line 232
    invoke-virtual {v1, v0}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 233
    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 230
    return-object v0

    .line 227
    :cond_1
    :goto_0
    return-object v0
.end method

.method private sanitizarUrlImagem(Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .param p1, "rawUrl"    # Ljava/lang/String;

    .line 198
    if-eqz p1, :cond_1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 202
    :cond_0
    const-string v0, "&amp;"

    const-string v1, "&"

    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 199
    :cond_1
    :goto_0
    const-string v0, ""

    return-object v0
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 8
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 65
    const-string v0, "server"

    const-string v1, "SERVER"

    const-string v2, "url"

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 66
    sget v3, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->activity_home:I

    invoke-virtual {p0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->setContentView(I)V

    .line 68
    new-instance v3, Lcom/LinkaMaterialProject/linkaMaterial/AppConfig;

    invoke-direct {v3, p0}, Lcom/LinkaMaterialProject/linkaMaterial/AppConfig;-><init>(Landroid/content/Context;)V

    .line 69
    .local v3, "config":Lcom/LinkaMaterialProject/linkaMaterial/AppConfig;
    invoke-virtual {v3}, Lcom/LinkaMaterialProject/linkaMaterial/AppConfig;->getUsername()Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->username:Ljava/lang/String;

    .line 72
    :try_start_0
    new-instance v4, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v4}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 73
    .local v4, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v5, Lorg/json/JSONObject;

    const-string v6, "config.cfg"

    .line 74
    invoke-virtual {v4, p0, v6}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 80
    .local v5, "jsonCfg":Lorg/json/JSONObject;
    const/4 v6, 0x0

    .line 82
    .local v6, "server":Lorg/json/JSONObject;
    invoke-virtual {v5, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_0

    .line 83
    invoke-virtual {v5, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    move-object v6, v0

    goto :goto_0

    .line 84
    :cond_0
    invoke-virtual {v5, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 85
    invoke-virtual {v5, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    move-object v6, v0

    .line 88
    :cond_1
    :goto_0
    if-eqz v6, :cond_2

    .line 89
    const-string v0, ""

    invoke-virtual {v6, v2, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->baseUrl:Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 96
    .end local v4    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v5    # "jsonCfg":Lorg/json/JSONObject;
    .end local v6    # "server":Lorg/json/JSONObject;
    :cond_2
    goto :goto_1

    .line 91
    :catch_0
    move-exception v0

    .line 92
    .local v0, "e":Lorg/json/JSONException;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Error parsing config.cfg: "

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 94
    invoke-virtual {v0}, Lorg/json/JSONException;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 92
    const-string v4, "MATERIAL_FEED"

    invoke-static {v4, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 98
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_1
    invoke-virtual {p0}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->getIntent()Landroid/content/Intent;

    move-result-object v0

    .line 100
    .local v0, "intent":Landroid/content/Intent;
    if-eqz v0, :cond_3

    .line 101
    invoke-virtual {v0, v2}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_3

    .line 102
    invoke-virtual {v0, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_3

    .line 103
    invoke-virtual {v0, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_3

    .line 105
    invoke-virtual {v0, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->currentUrl:Ljava/lang/String;

    goto :goto_2

    .line 107
    :cond_3
    invoke-virtual {v3}, Lcom/LinkaMaterialProject/linkaMaterial/AppConfig;->getUrl()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->currentUrl:Ljava/lang/String;

    .line 110
    :goto_2
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->currentUrl:Ljava/lang/String;

    invoke-direct {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->formatUrl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->currentUrl:Ljava/lang/String;

    .line 112
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->newPost:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->newPost:Landroid/widget/Button;

    .line 113
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->btnHome:Landroid/widget/ImageButton;

    .line 114
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->btnChat:Landroid/widget/ImageButton;

    .line 115
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->btnProfile:Landroid/widget/ImageButton;

    .line 116
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->btnOptions:Landroid/widget/ImageButton;

    .line 118
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->btnChat:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$$ExternalSyntheticLambda0;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$$ExternalSyntheticLambda0;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 127
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->btnOptions:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$$ExternalSyntheticLambda1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 136
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->btnProfile:Landroid/widget/ImageButton;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$$ExternalSyntheticLambda2;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$$ExternalSyntheticLambda2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 145
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->newPost:Landroid/widget/Button;

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$$ExternalSyntheticLambda3;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$$ExternalSyntheticLambda3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 154
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->listViewPosts:I

    invoke-virtual {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ListView;

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->listViewPosts:Landroid/widget/ListView;

    .line 156
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->postsList:Ljava/util/ArrayList;

    .line 157
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->postsList:Ljava/util/ArrayList;

    invoke-direct {v1, p0, p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;Landroid/content/Context;Ljava/util/ArrayList;)V

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->postAdapter:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;

    .line 158
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->listViewPosts:Landroid/widget/ListView;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->postAdapter:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$PostAdapter;

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 159
    return-void
.end method

.method protected onDestroy()V
    .locals 0

    .line 238
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    .line 239
    return-void
.end method

.method protected onResume()V
    .locals 4

    .line 163
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 165
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->currentUrl:Ljava/lang/String;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->currentUrl:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 166
    :cond_0
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/AppConfig;

    invoke-direct {v0, p0}, Lcom/LinkaMaterialProject/linkaMaterial/AppConfig;-><init>(Landroid/content/Context;)V

    .line 167
    .local v0, "config":Lcom/LinkaMaterialProject/linkaMaterial/AppConfig;
    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/AppConfig;->getUrl()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->formatUrl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->currentUrl:Ljava/lang/String;

    .line 170
    .end local v0    # "config":Lcom/LinkaMaterialProject/linkaMaterial/AppConfig;
    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Executing FetchFeedTask for: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->currentUrl:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "MATERIAL_FEED"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 175
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$FetchFeedTask;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$FetchFeedTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed-IA;)V

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->currentUrl:Ljava/lang/String;

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/String;

    const/4 v3, 0x0

    aput-object v1, v2, v3

    invoke-virtual {v0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$FetchFeedTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 176
    return-void
.end method

.method public requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;
    .locals 12
    .param p1, "urlParam"    # Ljava/lang/String;
    .param p2, "method"    # Ljava/lang/String;
    .param p3, "json_body"    # Lorg/json/JSONObject;

    .line 555
    const-string v0, ""

    const-string v1, "MATERIAL_HTTP"

    const/4 v2, 0x0

    .line 558
    .local v2, "connection":Ljava/net/HttpURLConnection;
    :try_start_0
    new-instance v3, Ljava/net/URL;

    invoke-direct {v3, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 559
    .local v3, "url":Ljava/net/URL;
    invoke-virtual {v3}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v4

    check-cast v4, Ljava/net/HttpURLConnection;

    move-object v2, v4

    .line 561
    const/4 v4, 0x1

    invoke-static {v4}, Ljava/net/HttpURLConnection;->setFollowRedirects(Z)V

    .line 562
    invoke-virtual {v2, v4}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    .line 564
    invoke-virtual {p2}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v5

    move-object p2, v5

    .line 565
    invoke-virtual {v2, p2}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 566
    const/16 v5, 0x2710

    invoke-virtual {v2, v5}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    .line 567
    invoke-virtual {v2, v5}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    .line 569
    const-string v5, "Content-Type"

    const-string v6, "application/json"

    invoke-virtual {v2, v5, v6}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 574
    const-string v5, "User-Agent"

    const-string v6, "Mozilla/5.0 (Android) Linka Material"

    invoke-virtual {v2, v5, v6}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 579
    const-string v5, "POST"

    invoke-virtual {p2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const-string v6, "UTF-8"

    if-nez v5, :cond_0

    :try_start_1
    const-string v5, "PUT"

    invoke-virtual {p2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1

    .line 580
    :cond_0
    invoke-virtual {v2, v4}, Ljava/net/HttpURLConnection;->setDoOutput(Z)V

    .line 582
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v4

    .line 583
    .local v4, "os":Ljava/io/OutputStream;
    invoke-virtual {p3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/io/OutputStream;->write([B)V

    .line 584
    invoke-virtual {v4}, Ljava/io/OutputStream;->flush()V

    .line 585
    invoke-virtual {v4}, Ljava/io/OutputStream;->close()V

    .line 588
    .end local v4    # "os":Ljava/io/OutputStream;
    :cond_1
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v4

    .line 592
    .local v4, "responseCode":I
    const/16 v5, 0x12c

    const/16 v7, 0xc8

    if-lt v4, v7, :cond_2

    if-ge v4, v5, :cond_2

    .line 593
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v8

    .local v8, "inputStream":Ljava/io/InputStream;
    goto :goto_0

    .line 595
    .end local v8    # "inputStream":Ljava/io/InputStream;
    :cond_2
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->getErrorStream()Ljava/io/InputStream;

    move-result-object v8
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 598
    .restart local v8    # "inputStream":Ljava/io/InputStream;
    :goto_0
    if-nez v8, :cond_4

    .line 599
    nop

    .line 634
    if-eqz v2, :cond_3

    .line 635
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 599
    :cond_3
    return-object v0

    .line 602
    :cond_4
    :try_start_2
    new-instance v9, Ljava/io/BufferedReader;

    new-instance v10, Ljava/io/InputStreamReader;

    invoke-direct {v10, v8, v6}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/lang/String;)V

    invoke-direct {v9, v10}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 609
    .local v9, "in":Ljava/io/BufferedReader;
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 612
    .local v6, "response":Ljava/lang/StringBuilder;
    :goto_1
    invoke-virtual {v9}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v10

    move-object v11, v10

    .local v11, "line":Ljava/lang/String;
    if-eqz v10, :cond_5

    .line 613
    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    .line 616
    :cond_5
    invoke-virtual {v9}, Ljava/io/BufferedReader;->close()V

    .line 618
    if-lt v4, v7, :cond_6

    if-lt v4, v5, :cond_7

    .line 619
    :cond_6
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "HTTP "

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, ": "

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v1, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 625
    :cond_7
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 634
    if-eqz v2, :cond_8

    .line 635
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 625
    :cond_8
    return-object v0

    .line 634
    .end local v3    # "url":Ljava/net/URL;
    .end local v4    # "responseCode":I
    .end local v6    # "response":Ljava/lang/StringBuilder;
    .end local v8    # "inputStream":Ljava/io/InputStream;
    .end local v9    # "in":Ljava/io/BufferedReader;
    .end local v11    # "line":Ljava/lang/String;
    :catchall_0
    move-exception v0

    goto :goto_2

    .line 627
    :catch_0
    move-exception v3

    .line 628
    .local v3, "e":Ljava/lang/Exception;
    :try_start_3
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Connection exception: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 630
    invoke-virtual {v3}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 628
    invoke-static {v1, v4, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 634
    nop

    .end local v3    # "e":Ljava/lang/Exception;
    if-eqz v2, :cond_9

    .line 635
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 639
    :cond_9
    return-object v0

    .line 634
    :goto_2
    if-eqz v2, :cond_a

    .line 635
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 637
    :cond_a
    goto :goto_4

    :goto_3
    throw v0

    :goto_4
    goto :goto_3
.end method
