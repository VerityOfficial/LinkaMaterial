.class public Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;
.super Landroid/app/Activity;
.source "ChangeServer.java"


# instance fields
.field private btnChat:Landroid/widget/ImageButton;

.field private btnHome:Landroid/widget/ImageButton;

.field private btnOptions:Landroid/widget/ImageButton;

.field private btnProfile:Landroid/widget/ImageButton;

.field private edtServer:Landroid/widget/EditText;

.field private sendButton:Landroid/widget/Button;


# direct methods
.method static bridge synthetic -$$Nest$fgetedtServer(Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->edtServer:Landroid/widget/EditText;

    return-object p0
.end method

.method public constructor <init>()V
    .locals 0

    .line 32
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 2
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 41
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 42
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->activity_change_server:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->setContentView(I)V

    .line 43
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtServer:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->edtServer:Landroid/widget/EditText;

    .line 44
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->sendButton:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->sendButton:Landroid/widget/Button;

    .line 45
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnHome:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->btnHome:Landroid/widget/ImageButton;

    .line 46
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnChat:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->btnChat:Landroid/widget/ImageButton;

    .line 47
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnOptions:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->btnOptions:Landroid/widget/ImageButton;

    .line 48
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnProfile:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->btnProfile:Landroid/widget/ImageButton;

    .line 49
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->sendButton:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer$1;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 60
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->btnHome:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer$2;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 68
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->btnOptions:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer$3;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 76
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->btnProfile:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer$4;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 83
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;->btnChat:Landroid/widget/ImageButton;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer$5;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer$5;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChangeServer;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 90
    return-void
.end method
