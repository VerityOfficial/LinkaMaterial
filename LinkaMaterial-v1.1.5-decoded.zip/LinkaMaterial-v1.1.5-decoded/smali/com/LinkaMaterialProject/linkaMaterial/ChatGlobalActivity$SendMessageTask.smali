.class Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$SendMessageTask;
.super Landroid/os/AsyncTask;
.source "ChatGlobalActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "SendMessageTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/Void;",
        "Ljava/lang/Void;",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field private messageToSend:Ljava/lang/String;

.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;


# direct methods
.method public constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;Ljava/lang/String;)V
    .locals 0
    .param p2, "message"    # Ljava/lang/String;

    .line 125
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    .line 126
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$SendMessageTask;->messageToSend:Ljava/lang/String;

    .line 127
    return-void
.end method


# virtual methods
.method protected varargs doInBackground([Ljava/lang/Void;)Ljava/lang/Boolean;
    .locals 5
    .param p1, "params"    # [Ljava/lang/Void;

    .line 131
    const/4 v0, 0x0

    :try_start_0
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    .line 132
    .local v1, "json_chat":Lorg/json/JSONObject;
    const-string v2, "sender"

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 133
    const-string v2, "message"

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$SendMessageTask;->messageToSend:Ljava/lang/String;

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 134
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/send-global-message"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "post"

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    invoke-static {v2, v3, v1, v0, v4}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;ILandroid/content/Context;)Ljava/lang/String;

    .line 135
    const/4 v2, 0x1

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 136
    .end local v1    # "json_chat":Lorg/json/JSONObject;
    :catch_0
    move-exception v1

    .line 137
    .local v1, "e":Ljava/lang/Exception;
    const-string v2, "MATERIAL_DEBUG"

    const-string v3, "Error sending message"

    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 138
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0
.end method

.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 123
    check-cast p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$SendMessageTask;->doInBackground([Ljava/lang/Void;)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method

.method protected onPostExecute(Ljava/lang/Boolean;)V
    .locals 4
    .param p1, "success"    # Ljava/lang/Boolean;

    .line 143
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 144
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$FetchMessagesTask;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    const/4 v3, 0x0

    invoke-direct {v0, v2, v3}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$FetchMessagesTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity-IA;)V

    new-array v1, v1, [Ljava/lang/Void;

    invoke-virtual {v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$FetchMessagesTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    goto :goto_0

    .line 146
    :cond_0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity;

    const-string v2, "Erro ao enviar mensagem"

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 148
    :goto_0
    return-void
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 123
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/ChatGlobalActivity$SendMessageTask;->onPostExecute(Ljava/lang/Boolean;)V

    return-void
.end method
