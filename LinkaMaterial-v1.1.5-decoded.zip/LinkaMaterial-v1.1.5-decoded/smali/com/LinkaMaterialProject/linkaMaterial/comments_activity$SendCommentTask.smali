.class Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$SendCommentTask;
.super Landroid/os/AsyncTask;
.source "comments_activity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "SendCommentTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/String;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;


# direct methods
.method private constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)V
    .locals 0

    .line 85
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$SendCommentTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;Lcom/LinkaMaterialProject/linkaMaterial/comments_activity-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$SendCommentTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)V

    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 85
    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$SendCommentTask;->doInBackground([Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/String;)Ljava/lang/String;
    .locals 5
    .param p1, "params"    # [Ljava/lang/String;

    .line 89
    const/4 v0, 0x0

    :try_start_0
    aget-object v0, p1, v0

    .line 90
    .local v0, "jsonPayload":Ljava/lang/String;
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 92
    .local v1, "commentJson":Lorg/json/JSONObject;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$SendCommentTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->-$$Nest$fgetbaseUrl(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/comments"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "post"

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$SendCommentTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-static {v2, v3, v1, v4}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v2

    .line 93
    .end local v0    # "jsonPayload":Ljava/lang/String;
    .end local v1    # "commentJson":Lorg/json/JSONObject;
    :catch_0
    move-exception v0

    .line 94
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 95
    const/4 v1, 0x0

    return-object v1
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 85
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$SendCommentTask;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .locals 5
    .param p1, "response"    # Ljava/lang/String;

    .line 101
    const/4 v0, 0x1

    if-eqz p1, :cond_0

    const-string v1, "sucess"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 102
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$SendCommentTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->-$$Nest$fgetcommentEdt(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)Landroid/widget/EditText;

    move-result-object v1

    const-string v2, ""

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 103
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$SendCommentTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    const-string v2, "Enviado com sucesso!"

    const/4 v3, 0x0

    invoke-static {v1, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 105
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$FetchCommentsTask;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$SendCommentTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    const/4 v4, 0x0

    invoke-direct {v1, v2, v4}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$FetchCommentsTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;Lcom/LinkaMaterialProject/linkaMaterial/comments_activity-IA;)V

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$SendCommentTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;->-$$Nest$fgetpostId(Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;)Ljava/lang/String;

    move-result-object v2

    new-array v0, v0, [Ljava/lang/String;

    aput-object v2, v0, v3

    invoke-virtual {v1, v0}, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$FetchCommentsTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    goto :goto_0

    .line 107
    :cond_0
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/comments_activity$SendCommentTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/comments_activity;

    const-string v2, "Erro ao enviar (Verifique se o usu\u00e1rio bate com a sess\u00e3o)"

    invoke-static {v1, v2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 109
    :goto_0
    return-void
.end method
