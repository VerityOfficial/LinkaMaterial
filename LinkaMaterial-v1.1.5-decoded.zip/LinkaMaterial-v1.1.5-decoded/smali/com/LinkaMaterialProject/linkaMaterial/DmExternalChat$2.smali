.class Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$2;
.super Ljava/lang/Object;
.source "DmExternalChat.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    .line 85
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 88
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;->finish()V

    .line 89
    return-void
.end method
