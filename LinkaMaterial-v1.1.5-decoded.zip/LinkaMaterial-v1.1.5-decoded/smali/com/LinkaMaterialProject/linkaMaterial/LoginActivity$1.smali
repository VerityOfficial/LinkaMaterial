.class Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;
.super Ljava/lang/Object;
.source "LoginActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    .line 58
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 11

    .line 61
    const-string v0, ""

    const-string v1, "Lendo configura\u00e7\u00f5es de arquivo em background..."

    const-string v2, "LinkaMaterialLogin"

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 62
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v1}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 63
    .local v1, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    const-string v4, "config.cfg"

    invoke-static {v3, v4}, Lcom/LinkaMaterialProject/linkaMaterial/config;->configFileExists(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_0

    .line 64
    const-string v3, "Arquivo config.cfg n\u00e3o existe. Criando padr\u00e3o..."

    invoke-static {v2, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 65
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-virtual {v1, v3, v4}, Lcom/LinkaMaterialProject/linkaMaterial/config;->createDefaultConfig(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    .line 68
    :cond_0
    const-string v3, ""

    .line 69
    .local v3, "fastUsername":Ljava/lang/String;
    const-string v5, ""

    .line 72
    .local v5, "fastPassword":Ljava/lang/String;
    :try_start_0
    iget-object v6, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-virtual {v1, v6, v4}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 73
    .local v4, "jsonString":Ljava/lang/String;
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Conte\u00fado do config.cfg: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v2, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 75
    new-instance v6, Lorg/json/JSONObject;

    invoke-direct {v6, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 76
    .local v6, "jsonCfg":Lorg/json/JSONObject;
    const-string v7, "SERVER"

    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v7

    .line 77
    .local v7, "server":Lorg/json/JSONObject;
    if-eqz v7, :cond_1

    .line 78
    iget-object v8, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    const-string v9, "url"

    iget-object v10, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-static {v10}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->-$$Nest$fgetserverUrl(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v7, v9, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v8, v9}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->-$$Nest$fputserverUrl(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;Ljava/lang/String;)V

    .line 79
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "URL do servidor carregada da config: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    iget-object v9, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    invoke-static {v9}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->-$$Nest$fgetserverUrl(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v2, v8}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 81
    :cond_1
    const-string v8, "FAST_LOGIN"

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v8

    .line 82
    .local v8, "fastLogin":Lorg/json/JSONObject;
    if-eqz v8, :cond_2

    .line 83
    const-string v9, "username"

    invoke-virtual {v8, v9, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    move-object v3, v9

    .line 84
    const-string v9, "password"

    invoke-virtual {v8, v9, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    move-object v5, v0

    .line 88
    .end local v4    # "jsonString":Ljava/lang/String;
    .end local v6    # "jsonCfg":Lorg/json/JSONObject;
    .end local v7    # "server":Lorg/json/JSONObject;
    .end local v8    # "fastLogin":Lorg/json/JSONObject;
    :cond_2
    goto :goto_0

    .line 86
    :catch_0
    move-exception v0

    .line 87
    .local v0, "e":Lorg/json/JSONException;
    const-string v4, "Erro ao processar JSON da configura\u00e7\u00e3o:"

    invoke-static {v2, v4, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 90
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    move-object v0, v3

    .line 91
    .local v0, "finalUser":Ljava/lang/String;
    move-object v2, v5

    .line 93
    .local v2, "finalPass":Ljava/lang/String;
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;

    new-instance v6, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1$1;

    invoke-direct {v6, p0, v0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v4, v6}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 102
    return-void
.end method
