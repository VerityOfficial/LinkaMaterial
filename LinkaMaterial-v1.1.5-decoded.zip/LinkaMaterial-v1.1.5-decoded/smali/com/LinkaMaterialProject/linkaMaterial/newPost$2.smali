.class Lcom/LinkaMaterialProject/linkaMaterial/newPost$2;
.super Ljava/lang/Object;
.source "newPost.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/newPost;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/newPost;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    .line 45
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 48
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/newPost$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/newPost;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/newPost;->-$$Nest$mopenGallery(Lcom/LinkaMaterialProject/linkaMaterial/newPost;)V

    .line 49
    return-void
.end method
