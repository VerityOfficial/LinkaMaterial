.class Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1$1;
.super Ljava/lang/Object;
.source "GenerateInvite.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$2:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1;

.field final synthetic val$msg:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$2"    # Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 120
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1$1;->this$2:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1$1;->val$msg:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 123
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1$1;->this$2:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1;

    iget-object v0, v0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1;->this$1:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;

    iget-object v0, v0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1$1;->val$msg:Ljava/lang/String;

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 124
    return-void
.end method
