.class Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$2;
.super Ljava/lang/Object;
.source "ChannelsGroupActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    .line 90
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 93
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/ChannelsGroupActivity;->finish()V

    .line 94
    return-void
.end method
