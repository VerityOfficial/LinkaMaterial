.class public Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;
.super Landroid/widget/BaseAdapter;
.source "FederationsAdapter.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$ViewHolder;
    }
.end annotation


# instance fields
.field private context:Landroid/content/Context;

.field private executorService:Ljava/util/concurrent/ExecutorService;

.field private inflater:Landroid/view/LayoutInflater;

.field private items:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static bridge synthetic -$$Nest$fgetcontext(Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;)Landroid/content/Context;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;->context:Landroid/content/Context;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mdownloadBitmap(Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;Ljava/lang/String;)Landroid/graphics/Bitmap;
    .locals 0

    invoke-direct {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;->downloadBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object p0

    return-object p0
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/util/List;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;",
            ">;)V"
        }
    .end annotation

    .line 28
    .local p2, "items":Ljava/util/List;, "Ljava/util/List<Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;>;"
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 29
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;->context:Landroid/content/Context;

    .line 30
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;->items:Ljava/util/List;

    .line 31
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;->inflater:Landroid/view/LayoutInflater;

    .line 32
    const/4 v0, 0x4

    invoke-static {v0}, Ljava/util/concurrent/Executors;->newFixedThreadPool(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;->executorService:Ljava/util/concurrent/ExecutorService;

    .line 33
    return-void
.end method

.method private downloadBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;
    .locals 4
    .param p1, "urlString"    # Ljava/lang/String;

    .line 110
    :try_start_0
    new-instance v0, Ljava/net/URL;

    invoke-direct {v0, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 111
    .local v0, "url":Ljava/net/URL;
    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v1

    check-cast v1, Ljava/net/HttpURLConnection;

    .line 112
    .local v1, "connection":Ljava/net/HttpURLConnection;
    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Ljava/net/HttpURLConnection;->setDoInput(Z)V

    .line 113
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->connect()V

    .line 114
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v2

    .line 115
    .local v2, "input":Ljava/io/InputStream;
    invoke-static {v2}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v3

    .line 116
    .end local v0    # "url":Ljava/net/URL;
    .end local v1    # "connection":Ljava/net/HttpURLConnection;
    .end local v2    # "input":Ljava/io/InputStream;
    :catch_0
    move-exception v0

    .line 117
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 118
    const/4 v1, 0x0

    return-object v1
.end method


# virtual methods
.method public getCount()I
    .locals 1

    .line 36
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;->items:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    return v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .locals 1
    .param p1, "position"    # I

    .line 40
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;->items:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public getItemId(I)J
    .locals 2
    .param p1, "position"    # I

    .line 44
    int-to-long v0, p1

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 7
    .param p1, "position"    # I
    .param p2, "convertView"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 53
    const/4 v0, 0x0

    if-nez p2, :cond_0

    .line 54
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;->inflater:Landroid/view/LayoutInflater;

    sget v2, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->item_federations:I

    invoke-virtual {v1, v2, p3, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    .line 55
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$ViewHolder;

    invoke-direct {v1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$ViewHolder;-><init>()V

    .line 56
    .local v1, "holder":Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$ViewHolder;
    sget v2, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->coverFederation:I

    invoke-virtual {p2, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    iput-object v2, v1, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$ViewHolder;->coverFederation:Landroid/widget/ImageView;

    .line 57
    sget v2, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnFederation:I

    invoke-virtual {p2, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, v1, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$ViewHolder;->btnFederation:Landroid/widget/Button;

    .line 58
    invoke-virtual {p2, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    goto :goto_0

    .line 60
    .end local v1    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$ViewHolder;
    :cond_0
    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$ViewHolder;

    .line 62
    .restart local v1    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$ViewHolder;
    :goto_0
    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;->items:Ljava/util/List;

    invoke-interface {v2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;

    .line 63
    .local v2, "item":Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;
    iget-object v3, v1, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$ViewHolder;->btnFederation:Landroid/widget/Button;

    invoke-virtual {v2}, Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 64
    iget-object v3, v1, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$ViewHolder;->btnFederation:Landroid/widget/Button;

    new-instance v4, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$1;

    invoke-direct {v4, p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;)V

    invoke-virtual {v3, v4}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 78
    invoke-virtual {v2}, Lcom/LinkaMaterialProject/linkaMaterial/FederationItem;->getCoverImage()Ljava/lang/String;

    move-result-object v3

    .line 79
    .local v3, "imageSrc":Ljava/lang/String;
    iget-object v4, v1, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$ViewHolder;->coverFederation:Landroid/widget/ImageView;

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 80
    if-eqz v3, :cond_1

    const-string v4, "data:image"

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1

    .line 82
    :try_start_0
    const-string v4, ","

    invoke-virtual {v3, v4}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v4

    add-int/lit8 v4, v4, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    .line 83
    .local v4, "cleanBase64":Ljava/lang/String;
    invoke-static {v4, v0}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v5

    .line 84
    .local v5, "decodedBytes":[B
    array-length v6, v5

    invoke-static {v5, v0, v6}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object v0

    .line 85
    .local v0, "bitmap":Landroid/graphics/Bitmap;
    iget-object v6, v1, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$ViewHolder;->coverFederation:Landroid/widget/ImageView;

    invoke-virtual {v6, v0}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .end local v0    # "bitmap":Landroid/graphics/Bitmap;
    .end local v4    # "cleanBase64":Ljava/lang/String;
    .end local v5    # "decodedBytes":[B
    goto :goto_1

    .line 86
    :catch_0
    move-exception v0

    .line 87
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 88
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_1
    goto :goto_2

    .line 89
    :cond_1
    if-eqz v3, :cond_3

    const-string v0, "http://"

    invoke-virtual {v3, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_2

    const-string v0, "https://"

    invoke-virtual {v3, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_3

    .line 90
    :cond_2
    iget-object v0, v1, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$ViewHolder;->coverFederation:Landroid/widget/ImageView;

    .line 91
    .local v0, "targetImageView":Landroid/widget/ImageView;
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;->executorService:Ljava/util/concurrent/ExecutorService;

    new-instance v5, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2;

    invoke-direct {v5, p0, v3, v0}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsAdapter;Ljava/lang/String;Landroid/widget/ImageView;)V

    invoke-interface {v4, v5}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 106
    .end local v0    # "targetImageView":Landroid/widget/ImageView;
    :cond_3
    :goto_2
    return-object p2
.end method
