.class public Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;
.super Landroid/app/Activity;
.source "LoginActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;
    }
.end annotation


# static fields
.field private static final TAG:Ljava/lang/String; = "LinkaMaterialLogin"


# instance fields
.field private btnLogin:Landroid/widget/Button;

.field private btnServer:Landroid/widget/Button;

.field private currentLoginTask:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;

.field private edtPassword:Landroid/widget/EditText;

.field private edtUsername:Landroid/widget/EditText;

.field private serverUrl:Ljava/lang/String;

.field private txtGoToSignup:Landroid/widget/TextView;


# direct methods
.method static bridge synthetic -$$Nest$fgetedtPassword(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->edtPassword:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetedtUsername(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->edtUsername:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetserverUrl(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->serverUrl:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fputserverUrl(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->serverUrl:Ljava/lang/String;

    return-void
.end method

.method static bridge synthetic -$$Nest$mexecuteLogin(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->executeLogin(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 23
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 32
    const-string v0, "http://192.168.240.1:5000"

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->serverUrl:Ljava/lang/String;

    return-void
.end method

.method private executeLogin(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4
    .param p1, "username"    # Ljava/lang/String;
    .param p2, "password"    # Ljava/lang/String;

    .line 36
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->currentLoginTask:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;

    const/4 v1, 0x1

    const-string v2, "LinkaMaterialLogin"

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->currentLoginTask:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->getStatus()Landroid/os/AsyncTask$Status;

    move-result-object v0

    sget-object v3, Landroid/os/AsyncTask$Status;->RUNNING:Landroid/os/AsyncTask$Status;

    if-ne v0, v3, :cond_0

    .line 37
    const-string v0, "Cancelando LoginTask anterior em execu\u00e7\u00e3o."

    invoke-static {v2, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 38
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->currentLoginTask:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;

    invoke-virtual {v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->cancel(Z)Z

    .line 40
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Iniciando nova LoginTask para o usu\u00e1rio: "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 41
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;

    const/4 v2, 0x0

    invoke-direct {v0, p0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity-IA;)V

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->currentLoginTask:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;

    .line 42
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->currentLoginTask:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/String;

    const/4 v3, 0x0

    aput-object p1, v2, v3

    aput-object p2, v2, v1

    invoke-virtual {v0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 43
    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 47
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 48
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->activity_login:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->setContentView(I)V

    .line 50
    const-string v0, "http.keepAlive"

    const-string v1, "false"

    invoke-static {v0, v1}, Ljava/lang/System;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 52
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnServer:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->btnServer:Landroid/widget/Button;

    .line 53
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtUsername:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->edtUsername:Landroid/widget/EditText;

    .line 54
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->edtPassword:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->edtPassword:Landroid/widget/EditText;

    .line 55
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnLogin:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->btnLogin:Landroid/widget/Button;

    .line 56
    sget v0, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->txtGoToSignup:I

    invoke-virtual {p0, v0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->txtGoToSignup:Landroid/widget/TextView;

    .line 58
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 103
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 105
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->btnServer:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$2;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 113
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->btnLogin:Landroid/widget/Button;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$3;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$3;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 126
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->txtGoToSignup:Landroid/widget/TextView;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$4;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$4;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 133
    return-void
.end method

.method protected onDestroy()V
    .locals 2

    .line 137
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    .line 138
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->currentLoginTask:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;

    if-eqz v0, :cond_0

    .line 139
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->currentLoginTask:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->cancel(Z)Z

    .line 140
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity;->currentLoginTask:Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/LoginActivity$LoginTask;->dismissDialogSafely()V

    .line 142
    :cond_0
    return-void
.end method
