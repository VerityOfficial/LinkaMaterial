.class public Lcom/LinkaMaterialProject/linkaMaterial/notificationsParser;
.super Ljava/lang/Object;
.source "notificationsParser.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static parseJson(Ljava/lang/String;)Ljava/util/List;
    .locals 15
    .param p0, "jsonRaw"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;",
            ">;"
        }
    .end annotation

    .line 12
    const-string v1, ""

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v2, v0

    .line 14
    .local v2, "messageList":Ljava/util/List;, "Ljava/util/List<Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;>;"
    if-eqz p0, :cond_3

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto/16 :goto_4

    .line 20
    :cond_0
    :try_start_0
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    move-object v3, v0

    .line 23
    .local v3, "trimmedJson":Ljava/lang/String;
    const-string v0, "["

    invoke-virtual {v3, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 24
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0, v3}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v4, v0

    .local v0, "array":Lorg/json/JSONArray;
    goto :goto_0

    .line 26
    .end local v0    # "array":Lorg/json/JSONArray;
    :cond_1
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 27
    .local v0, "jsonObject":Lorg/json/JSONObject;
    const-string v4, "notifications"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    .line 30
    .end local v0    # "jsonObject":Lorg/json/JSONObject;
    .local v4, "array":Lorg/json/JSONArray;
    :goto_0
    const/4 v0, 0x0

    move v5, v0

    .local v5, "i":I
    :goto_1
    invoke-virtual {v4}, Lorg/json/JSONArray;->length()I

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-ge v5, v0, :cond_2

    .line 32
    :try_start_1
    invoke-virtual {v4, v5}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v0

    .line 35
    .local v0, "obj":Lorg/json/JSONObject;
    const-string v6, "id"

    add-int/lit8 v7, v5, 0x1

    invoke-virtual {v0, v6, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v6

    move v8, v6

    .line 36
    .local v8, "id":I
    const-string v6, "content"

    const-string v7, "message"

    invoke-virtual {v0, v7, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 37
    .local v9, "content":Ljava/lang/String;
    const-string v6, "datetime"

    const-string v7, "date"

    invoke-virtual {v0, v7, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 38
    .local v10, "datetime":Ljava/lang/String;
    const-string v6, "fromUser"

    const-string v7, "from_user"

    const-string v11, "Linka Material"

    invoke-virtual {v0, v7, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    .line 39
    .local v11, "fromUser":Ljava/lang/String;
    const-string v6, "receiver"

    invoke-virtual {v0, v6, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 40
    .local v12, "receiver":Ljava/lang/String;
    const-string v6, "read"

    const/4 v7, 0x0

    invoke-virtual {v0, v6, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v13

    .line 41
    .local v13, "read":I
    const-string v6, "type"

    const-string v7, "notification"

    invoke-virtual {v0, v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    .line 43
    .local v14, "type":Ljava/lang/String;
    new-instance v7, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;

    invoke-direct/range {v7 .. v14}, Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V

    .line 44
    .local v7, "message":Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;
    invoke-interface {v2, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 47
    .end local v0    # "obj":Lorg/json/JSONObject;
    .end local v7    # "message":Lcom/LinkaMaterialProject/linkaMaterial/NotificationMessage;
    .end local v8    # "id":I
    .end local v9    # "content":Ljava/lang/String;
    .end local v10    # "datetime":Ljava/lang/String;
    .end local v11    # "fromUser":Ljava/lang/String;
    .end local v12    # "receiver":Ljava/lang/String;
    .end local v13    # "read":I
    .end local v14    # "type":Ljava/lang/String;
    goto :goto_2

    .line 45
    :catch_0
    move-exception v0

    .line 46
    .local v0, "e":Ljava/lang/Exception;
    :try_start_2
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 30
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_2
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 51
    .end local v3    # "trimmedJson":Ljava/lang/String;
    .end local v4    # "array":Lorg/json/JSONArray;
    .end local v5    # "i":I
    :cond_2
    goto :goto_3

    .line 49
    :catch_1
    move-exception v0

    .line 50
    .restart local v0    # "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 53
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_3
    return-object v2

    .line 15
    :cond_3
    :goto_4
    return-object v2
.end method
