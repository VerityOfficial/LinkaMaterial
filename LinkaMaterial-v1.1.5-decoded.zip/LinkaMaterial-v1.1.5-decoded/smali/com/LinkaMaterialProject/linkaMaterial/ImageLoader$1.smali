.class Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$1;
.super Ljava/lang/Object;
.source "ImageLoader.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;->processImageData(Ljava/lang/String;Landroid/widget/ImageView;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;

.field final synthetic val$decodedBitmap:Landroid/graphics/Bitmap;

.field final synthetic val$targetView:Landroid/widget/ImageView;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;Landroid/widget/ImageView;Landroid/graphics/Bitmap;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 83
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$1;->val$targetView:Landroid/widget/ImageView;

    iput-object p3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$1;->val$decodedBitmap:Landroid/graphics/Bitmap;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 87
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$1;->val$targetView:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 88
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$1;->val$targetView:Landroid/widget/ImageView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 90
    :cond_0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$1;->val$targetView:Landroid/widget/ImageView;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$1;->val$decodedBitmap:Landroid/graphics/Bitmap;

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 91
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ImageLoader$1;->val$targetView:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->requestLayout()V

    .line 92
    return-void
.end method
