.class public Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;
.super Landroid/widget/BaseAdapter;
.source "InboxAdapter.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$ViewHolder;
    }
.end annotation


# instance fields
.field private context:Landroid/content/Context;

.field private inflater:Landroid/view/LayoutInflater;

.field private itemList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;",
            ">;"
        }
    .end annotation
.end field

.field private url:Ljava/lang/String;

.field private username:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgetcontext(Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;)Landroid/content/Context;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->context:Landroid/content/Context;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetitemList(Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;)Ljava/util/List;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->itemList:Ljava/util/List;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->url:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->username:Ljava/lang/String;

    return-object p0
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/util/List;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;",
            ">;)V"
        }
    .end annotation

    .line 20
    .local p2, "itemList":Ljava/util/List;, "Ljava/util/List<Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;>;"
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 18
    const-string v0, ""

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->url:Ljava/lang/String;

    .line 19
    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->username:Ljava/lang/String;

    .line 21
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->context:Landroid/content/Context;

    .line 22
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->itemList:Ljava/util/List;

    .line 23
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->inflater:Landroid/view/LayoutInflater;

    .line 24
    return-void
.end method


# virtual methods
.method public getCount()I
    .locals 1

    .line 27
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->itemList:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    return v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .locals 1
    .param p1, "position"    # I

    .line 31
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->itemList:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public getItemId(I)J
    .locals 2
    .param p1, "position"    # I

    .line 35
    int-to-long v0, p1

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 5
    .param p1, "position"    # I
    .param p2, "convertView"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 48
    :try_start_0
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/config;

    invoke-direct {v0}, Lcom/LinkaMaterialProject/linkaMaterial/config;-><init>()V

    .line 49
    .local v0, "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    new-instance v1, Lorg/json/JSONObject;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->context:Landroid/content/Context;

    const-string v3, "config.cfg"

    invoke-virtual {v0, v2, v3}, Lcom/LinkaMaterialProject/linkaMaterial/config;->loadCfgAsJson(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 50
    .local v1, "jsonCfg":Lorg/json/JSONObject;
    const-string v2, "FAST_LOGIN"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    .line 51
    .local v2, "fastLogin":Lorg/json/JSONObject;
    const-string v3, "SERVER"

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    .line 52
    .local v3, "server":Lorg/json/JSONObject;
    const-string v4, "url"

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->url:Ljava/lang/String;

    .line 53
    const-string v4, "username"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->username:Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 56
    .end local v0    # "cfg":Lcom/LinkaMaterialProject/linkaMaterial/config;
    .end local v1    # "jsonCfg":Lorg/json/JSONObject;
    .end local v2    # "fastLogin":Lorg/json/JSONObject;
    .end local v3    # "server":Lorg/json/JSONObject;
    goto :goto_0

    .line 54
    :catch_0
    move-exception v0

    .line 55
    .local v0, "e":Lorg/json/JSONException;
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 57
    .end local v0    # "e":Lorg/json/JSONException;
    :goto_0
    if-nez p2, :cond_0

    .line 58
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->inflater:Landroid/view/LayoutInflater;

    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$layout;->item_inbox:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    .line 59
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$ViewHolder;

    invoke-direct {v0}, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$ViewHolder;-><init>()V

    .line 60
    .local v0, "holder":Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$ViewHolder;
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->imgAvatar:I

    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    iput-object v1, v0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$ViewHolder;->imgAvatar:Landroid/widget/ImageView;

    .line 61
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->username:I

    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, v0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$ViewHolder;->txtUsername:Landroid/widget/TextView;

    .line 62
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->message:I

    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, v0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$ViewHolder;->txtMessage:Landroid/widget/TextView;

    .line 63
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnAccept:I

    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, v0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$ViewHolder;->btnAccept:Landroid/widget/Button;

    .line 64
    sget v1, Lcom/LinkaMaterialProject/linkaMaterial/R$id;->btnDenied:I

    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, v0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$ViewHolder;->btnDenied:Landroid/widget/Button;

    .line 65
    invoke-virtual {p2, v0}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    goto :goto_1

    .line 67
    .end local v0    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$ViewHolder;
    :cond_0
    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$ViewHolder;

    .line 69
    .restart local v0    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$ViewHolder;
    :goto_1
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->itemList:Ljava/util/List;

    invoke-interface {v1, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;

    .line 70
    .local v1, "item":Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;
    iget-object v2, v0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$ViewHolder;->txtUsername:Landroid/widget/TextView;

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;->getUsername()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 71
    iget-object v2, v0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$ViewHolder;->txtMessage:Landroid/widget/TextView;

    invoke-virtual {v1}, Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 72
    iget-object v2, v0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$ViewHolder;->btnAccept:Landroid/widget/Button;

    new-instance v3, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$1;

    invoke-direct {v3, p0, v1, p1}, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;I)V

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 88
    iget-object v2, v0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$ViewHolder;->btnDenied:Landroid/widget/Button;

    new-instance v3, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$2;

    invoke-direct {v3, p0, v1, p1}, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;I)V

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 104
    return-object p2
.end method
