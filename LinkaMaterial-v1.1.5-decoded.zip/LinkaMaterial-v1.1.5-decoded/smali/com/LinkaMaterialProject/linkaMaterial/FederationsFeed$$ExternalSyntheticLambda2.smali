.class public final synthetic Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;"
    method = "lambda$onCreate$2"
    proto = "(Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "7bbc1d7254613ffaa026de47d975f73968361ef3e5d7b818ce0a83a33039c6b8"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;


# direct methods
.method public synthetic constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$$ExternalSyntheticLambda2;->f$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed$$ExternalSyntheticLambda2;->f$0:Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;

    invoke-static {v0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;->$r8$lambda$GnVZJb4w8J0tBtys8Eb68dsten0(Lcom/LinkaMaterialProject/linkaMaterial/FederationsFeed;Landroid/view/View;)V

    return-void
.end method
