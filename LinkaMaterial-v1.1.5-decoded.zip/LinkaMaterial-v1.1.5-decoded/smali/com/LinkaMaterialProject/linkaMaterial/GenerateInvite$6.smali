.class Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;
.super Ljava/lang/Object;
.source "GenerateInvite.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->carregarConvites()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    .line 142
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 11

    .line 146
    const-string v0, ""

    :try_start_0
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    .line 147
    .local v1, "jsonInvite":Lorg/json/JSONObject;
    const-string v2, "username"

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 149
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/view-invites"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "post"

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    invoke-static {v2, v3, v1, v4}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    .line 151
    .local v2, "response":Ljava/lang/String;
    if-eqz v2, :cond_2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2

    .line 152
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 153
    .local v3, "jsonResponse":Lorg/json/JSONObject;
    const-string v4, "status"

    invoke-virtual {v3, v4, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 155
    .local v4, "status":Ljava/lang/String;
    const-string v5, "success"

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2

    .line 156
    const-string v5, "invites"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v5

    .line 158
    .local v5, "invitesArray":Lorg/json/JSONArray;
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 160
    .local v6, "novasList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    if-eqz v5, :cond_1

    .line 161
    const/4 v7, 0x0

    .local v7, "i":I
    :goto_0
    invoke-virtual {v5}, Lorg/json/JSONArray;->length()I

    move-result v8

    if-ge v7, v8, :cond_1

    .line 162
    invoke-virtual {v5, v7}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v8

    .line 163
    .local v8, "item":Lorg/json/JSONObject;
    if-eqz v8, :cond_0

    .line 164
    const-string v9, "invite_code"

    const-string v10, "code"

    invoke-virtual {v8, v10, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 165
    .local v9, "code":Ljava/lang/String;
    invoke-virtual {v9, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_0

    .line 166
    invoke-interface {v6, v9}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 161
    .end local v8    # "item":Lorg/json/JSONObject;
    .end local v9    # "code":Ljava/lang/String;
    :cond_0
    add-int/lit8 v7, v7, 0x1

    goto :goto_0

    .line 172
    .end local v7    # "i":I
    :cond_1
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->-$$Nest$fgethandler(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)Landroid/os/Handler;

    move-result-object v0

    new-instance v7, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6$1;

    invoke-direct {v7, p0, v6}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$6;Ljava/util/List;)V

    invoke-virtual {v0, v7}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 184
    .end local v1    # "jsonInvite":Lorg/json/JSONObject;
    .end local v2    # "response":Ljava/lang/String;
    .end local v3    # "jsonResponse":Lorg/json/JSONObject;
    .end local v4    # "status":Ljava/lang/String;
    .end local v5    # "invitesArray":Lorg/json/JSONArray;
    .end local v6    # "novasList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    :cond_2
    goto :goto_1

    .line 182
    :catch_0
    move-exception v0

    .line 183
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 185
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_1
    return-void
.end method
