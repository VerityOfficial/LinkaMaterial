.class public Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;
.super Ljava/lang/Object;
.source "InboxItem.java"


# instance fields
.field private message:Ljava/lang/String;

.field private username:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "username"    # Ljava/lang/String;
    .param p2, "message"    # Ljava/lang/String;

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;->username:Ljava/lang/String;

    .line 7
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;->message:Ljava/lang/String;

    .line 8
    return-void
.end method


# virtual methods
.method public getMessage()Ljava/lang/String;
    .locals 1

    .line 13
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;->message:Ljava/lang/String;

    return-object v0
.end method

.method public getUsername()Ljava/lang/String;
    .locals 1

    .line 10
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;->username:Ljava/lang/String;

    return-object v0
.end method
