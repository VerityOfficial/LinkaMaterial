.class Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$1;
.super Ljava/lang/Object;
.source "ExternalChat.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;

    .line 61
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 6
    .param p1, "v"    # Landroid/view/View;

    .line 65
    const-string v0, "urlDestiny"

    const-string v1, "destiny"

    :try_start_0
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 66
    .local v2, "jsonAdd":Lorg/json/JSONObject;
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->-$$Nest$fgetedtUsername(Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;)Landroid/widget/EditText;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v2, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 67
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->-$$Nest$fgetedtUrl(Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;)Landroid/widget/EditText;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v2, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 68
    const-string v3, "username"

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 69
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "/add-external-contact"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "post"

    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;

    invoke-static {v3, v4, v2, v5}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 72
    nop

    .end local v2    # "jsonAdd":Lorg/json/JSONObject;
    goto :goto_0

    .line 70
    :catch_0
    move-exception v2

    .line 71
    .local v2, "e":Ljava/lang/Exception;
    invoke-virtual {v2}, Ljava/lang/Exception;->printStackTrace()V

    .line 73
    .end local v2    # "e":Ljava/lang/Exception;
    :goto_0
    new-instance v2, Landroid/content/Intent;

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;

    const-class v4, Lcom/LinkaMaterialProject/linkaMaterial/DmExternalChat;

    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 74
    .local v2, "intent":Landroid/content/Intent;
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->-$$Nest$fgetedtUsername(Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;)Landroid/widget/EditText;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-virtual {v2, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/CharSequence;)Landroid/content/Intent;

    .line 75
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->-$$Nest$fgetedtUrl(Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;)Landroid/widget/EditText;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v2, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/CharSequence;)Landroid/content/Intent;

    .line 76
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;

    invoke-virtual {v0, v2}, Lcom/LinkaMaterialProject/linkaMaterial/ExternalChat;->startActivity(Landroid/content/Intent;)V

    .line 77
    return-void
.end method
