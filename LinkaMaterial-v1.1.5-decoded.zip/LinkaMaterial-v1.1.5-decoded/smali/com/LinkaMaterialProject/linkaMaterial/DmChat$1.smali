.class Lcom/LinkaMaterialProject/linkaMaterial/DmChat$1;
.super Ljava/lang/Object;
.source "DmChat.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    .line 71
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 74
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->-$$Nest$fgetedtInputMessage(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 75
    .local v0, "text_message":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_0

    .line 76
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->-$$Nest$fgetedtInputMessage(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Landroid/widget/EditText;

    move-result-object v1

    const-string v2, ""

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 77
    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-direct {v1, v2, v0}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;Ljava/lang/String;)V

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Void;

    invoke-virtual {v1, v2}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 79
    :cond_0
    return-void
.end method
