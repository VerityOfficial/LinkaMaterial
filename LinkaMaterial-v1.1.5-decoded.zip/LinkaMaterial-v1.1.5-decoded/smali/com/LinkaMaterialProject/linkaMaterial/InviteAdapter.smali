.class public Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter;
.super Landroid/widget/BaseAdapter;
.source "InviteAdapter.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter$ViewHolder;
    }
.end annotation


# instance fields
.field private context:Landroid/content/Context;

.field private inflater:Landroid/view/LayoutInflater;

.field private inviteList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/util/List;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 17
    .local p2, "inviteList":Ljava/util/List;, "Ljava/util/List<Ljava/lang/String;>;"
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 18
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter;->context:Landroid/content/Context;

    .line 19
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter;->inviteList:Ljava/util/List;

    .line 20
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    iput-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter;->inflater:Landroid/view/LayoutInflater;

    .line 21
    return-void
.end method


# virtual methods
.method public getCount()I
    .locals 1

    .line 25
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter;->inviteList:Ljava/util/List;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter;->inviteList:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .locals 1
    .param p1, "position"    # I

    .line 30
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter;->inviteList:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public getItemId(I)J
    .locals 2
    .param p1, "position"    # I

    .line 35
    int-to-long v0, p1

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 3
    .param p1, "position"    # I
    .param p2, "convertView"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 46
    if-nez p2, :cond_0

    .line 47
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter;->inflater:Landroid/view/LayoutInflater;

    const v1, 0x1090003

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    .line 49
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter$ViewHolder;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter$ViewHolder;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter-IA;)V

    .line 50
    .local v0, "holder":Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter$ViewHolder;
    const v1, 0x1020014

    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, v0, Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter$ViewHolder;->txtInviteCode:Landroid/widget/TextView;

    .line 52
    invoke-virtual {p2, v0}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    goto :goto_0

    .line 54
    .end local v0    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter$ViewHolder;
    :cond_0
    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter$ViewHolder;

    .line 57
    .restart local v0    # "holder":Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter$ViewHolder;
    :goto_0
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter;->inviteList:Ljava/util/List;

    invoke-interface {v1, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 58
    .local v1, "inviteCode":Ljava/lang/String;
    iget-object v2, v0, Lcom/LinkaMaterialProject/linkaMaterial/InviteAdapter$ViewHolder;->txtInviteCode:Landroid/widget/TextView;

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 60
    return-object p2
.end method
