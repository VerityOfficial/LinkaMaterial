.class Lcom/LinkaMaterialProject/linkaMaterial/request$2$1;
.super Ljava/lang/Object;
.source "request.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/request$2;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/request$2;

.field final synthetic val$result:[B


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/request$2;[B)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/request$2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 54
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$2$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/request$2;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$2$1;->val$result:[B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 57
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$2$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/request$2;

    iget-object v0, v0, Lcom/LinkaMaterialProject/linkaMaterial/request$2;->val$callback:Lcom/LinkaMaterialProject/linkaMaterial/request$RequestBytesCallback;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$2$1;->val$result:[B

    invoke-interface {v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/request$RequestBytesCallback;->onSuccess([B)V

    .line 58
    return-void
.end method
