.class Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;
.super Ljava/lang/Object;
.source "GenerateInvite.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    .line 95
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 98
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)Ljava/lang/String;

    move-result-object v0

    const-string v1, ""

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 103
    :cond_0
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1;

    invoke-direct {v1, p0}, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 132
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 133
    return-void

    .line 99
    :cond_1
    :goto_0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite$5;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/GenerateInvite;

    const-string v1, "Erro de configura\u00e7\u00e3o!"

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 100
    return-void
.end method
