.class Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6;
.super Ljava/lang/Object;
.source "ViewPicture.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->saveImageInSd()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;

    .line 90
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    .line 94
    :try_start_0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->-$$Nest$fgetimageView(Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;)Landroid/widget/ImageView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    check-cast v0, Landroid/graphics/drawable/BitmapDrawable;

    .line 95
    .local v0, "drawable":Landroid/graphics/drawable/BitmapDrawable;
    invoke-virtual {v0}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    move-result-object v1

    .line 97
    .local v1, "bitmap":Landroid/graphics/Bitmap;
    if-eqz v1, :cond_0

    .line 98
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "material_"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 100
    .local v2, "titulo":Ljava/lang/String;
    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;

    .line 101
    invoke-virtual {v3}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    const-string v4, "Image saved in gallery"

    .line 100
    invoke-static {v3, v1, v2, v4}, Landroid/provider/MediaStore$Images$Media;->insertImage(Landroid/content/ContentResolver;Landroid/graphics/Bitmap;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 107
    .local v3, "savedUrl":Ljava/lang/String;
    iget-object v4, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;

    invoke-static {v4}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->-$$Nest$fgethandler(Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;)Landroid/os/Handler;

    move-result-object v4

    new-instance v5, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6$1;

    invoke-direct {v5, p0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6$1;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6;Ljava/lang/String;)V

    invoke-virtual {v4, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 126
    .end local v0    # "drawable":Landroid/graphics/drawable/BitmapDrawable;
    .end local v1    # "bitmap":Landroid/graphics/Bitmap;
    .end local v2    # "titulo":Ljava/lang/String;
    .end local v3    # "savedUrl":Ljava/lang/String;
    :cond_0
    goto :goto_0

    .line 118
    :catch_0
    move-exception v0

    .line 119
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 120
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;->-$$Nest$fgethandler(Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture;)Landroid/os/Handler;

    move-result-object v1

    new-instance v2, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6$2;

    invoke-direct {v2, p0}, Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6$2;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/ViewPicture$6;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 127
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_0
    return-void
.end method
