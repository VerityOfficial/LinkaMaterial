.class Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;
.super Landroid/os/AsyncTask;
.source "DmChat.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/DmChat;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "SendMessageTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/Void;",
        "Ljava/lang/Void;",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field private messageToSend:Ljava/lang/String;

.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;


# direct methods
.method public constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;Ljava/lang/String;)V
    .locals 0
    .param p2, "message"    # Ljava/lang/String;

    .line 154
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    .line 155
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;->messageToSend:Ljava/lang/String;

    .line 156
    return-void
.end method


# virtual methods
.method protected varargs doInBackground([Ljava/lang/Void;)Ljava/lang/Boolean;
    .locals 6
    .param p1, "params"    # [Ljava/lang/Void;

    .line 160
    const/4 v0, 0x0

    :try_start_0
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_2

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->-$$Nest$fgetother_user(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->-$$Nest$fgetother_user(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_1

    .line 163
    :cond_0
    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->-$$Nest$fgetother_user(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "@"

    const-string v3, ""

    invoke-virtual {v1, v2, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 164
    .local v1, "cleanOtherUser":Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/send-message"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 165
    .local v2, "fullUrl":Ljava/lang/String;
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    .line 166
    .local v3, "json_chat":Lorg/json/JSONObject;
    const-string v4, "sender"

    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v5}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 167
    const-string v4, "receiver"

    invoke-virtual {v3, v4, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 168
    const-string v4, "message"

    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;->messageToSend:Ljava/lang/String;

    invoke-virtual {v3, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 169
    const-string v4, "post"

    iget-object v5, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    invoke-static {v2, v4, v3, v5}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    .line 170
    .local v4, "response":Ljava/lang/String;
    if-eqz v4, :cond_1

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_1

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    :goto_0
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 161
    .end local v1    # "cleanOtherUser":Ljava/lang/String;
    .end local v2    # "fullUrl":Ljava/lang/String;
    .end local v3    # "json_chat":Lorg/json/JSONObject;
    .end local v4    # "response":Ljava/lang/String;
    :cond_2
    :goto_1
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 171
    :catch_0
    move-exception v1

    .line 172
    .local v1, "e":Ljava/lang/Exception;
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0
.end method

.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 152
    check-cast p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;->doInBackground([Ljava/lang/Void;)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method

.method protected onPostExecute(Ljava/lang/Boolean;)V
    .locals 4
    .param p1, "success"    # Ljava/lang/Boolean;

    .line 177
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 178
    new-instance v0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    const/4 v3, 0x0

    invoke-direct {v0, v2, v3}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;-><init>(Lcom/LinkaMaterialProject/linkaMaterial/DmChat;Lcom/LinkaMaterialProject/linkaMaterial/DmChat-IA;)V

    new-array v1, v1, [Ljava/lang/Void;

    invoke-virtual {v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$FetchMessagesTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    goto :goto_0

    .line 180
    :cond_0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/DmChat;

    const-string v2, "Error in mesage sending"

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 182
    :goto_0
    return-void
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 0

    .line 152
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p0, p1}, Lcom/LinkaMaterialProject/linkaMaterial/DmChat$SendMessageTask;->onPostExecute(Ljava/lang/Boolean;)V

    return-void
.end method
