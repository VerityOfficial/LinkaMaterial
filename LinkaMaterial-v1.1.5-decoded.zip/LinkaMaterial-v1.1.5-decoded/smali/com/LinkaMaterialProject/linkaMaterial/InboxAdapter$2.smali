.class Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$2;
.super Ljava/lang/Object;
.source "InboxAdapter.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;

.field final synthetic val$item:Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;

.field final synthetic val$position:I


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;I)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 88
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$2;->val$item:Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;

    iput p3, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$2;->val$position:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 92
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 93
    .local v0, "jsonDenied":Lorg/json/JSONObject;
    const-string v1, "receiver"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->-$$Nest$fgetusername(Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 94
    const-string v1, "remittee"

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$2;->val$item:Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;

    invoke-virtual {v2}, Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;->getUsername()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 95
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;

    invoke-static {v2}, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->-$$Nest$fgeturl(Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/denied"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "post"

    iget-object v3, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;

    invoke-static {v3}, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->-$$Nest$fgetcontext(Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;)Landroid/content/Context;

    move-result-object v3

    invoke-static {v1, v2, v0, v3}, Lcom/LinkaMaterialProject/linkaMaterial/request;->requestHTTP(Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Landroid/content/Context;)Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 98
    nop

    .end local v0    # "jsonDenied":Lorg/json/JSONObject;
    goto :goto_0

    .line 96
    :catch_0
    move-exception v0

    .line 97
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 99
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_0
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->-$$Nest$fgetcontext(Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;)Landroid/content/Context;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Denied "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$2;->val$item:Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;

    invoke-virtual {v2}, Lcom/LinkaMaterialProject/linkaMaterial/InboxItem;->getUsername()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 100
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;

    invoke-static {v0}, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->-$$Nest$fgetitemList(Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;)Ljava/util/List;

    move-result-object v0

    iget v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$2;->val$position:I

    invoke-interface {v0, v1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 101
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$2;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;

    invoke-virtual {v0}, Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;->notifyDataSetChanged()V

    .line 102
    return-void
.end method
