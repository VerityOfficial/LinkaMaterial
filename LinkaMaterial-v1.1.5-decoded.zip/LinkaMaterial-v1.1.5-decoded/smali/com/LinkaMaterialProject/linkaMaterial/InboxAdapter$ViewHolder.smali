.class Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter$ViewHolder;
.super Ljava/lang/Object;
.source "InboxAdapter.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/LinkaMaterialProject/linkaMaterial/InboxAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "ViewHolder"
.end annotation


# instance fields
.field btnAccept:Landroid/widget/Button;

.field btnDenied:Landroid/widget/Button;

.field imgAvatar:Landroid/widget/ImageView;

.field txtMessage:Landroid/widget/TextView;

.field txtUsername:Landroid/widget/TextView;


# direct methods
.method constructor <init>()V
    .locals 0

    .line 37
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
