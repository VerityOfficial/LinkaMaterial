.class public Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;
.super Ljava/lang/Object;
.source "FriendItem.java"


# instance fields
.field private groupName:Ljava/lang/String;

.field private id:I

.field private permissions:Ljava/lang/String;

.field private type:I

.field private username:Ljava/lang/String;


# direct methods
.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;)V
    .locals 1
    .param p1, "id"    # I
    .param p2, "groupName"    # Ljava/lang/String;
    .param p3, "permissions"    # Ljava/lang/String;

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    iput p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->id:I

    .line 14
    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->groupName:Ljava/lang/String;

    .line 15
    iput-object p3, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->permissions:Ljava/lang/String;

    .line 16
    const/4 v0, 0x1

    iput v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->type:I

    .line 17
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 1
    .param p1, "username"    # Ljava/lang/String;

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->username:Ljava/lang/String;

    .line 10
    const/4 v0, 0x0

    iput v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->type:I

    .line 11
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Z)V
    .locals 1
    .param p1, "headerTitle"    # Ljava/lang/String;
    .param p2, "isHeader"    # Z

    .line 18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 19
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->groupName:Ljava/lang/String;

    .line 20
    const/4 v0, 0x2

    iput v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->type:I

    .line 21
    return-void
.end method


# virtual methods
.method public getGroupName()Ljava/lang/String;
    .locals 1

    .line 24
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->groupName:Ljava/lang/String;

    return-object v0
.end method

.method public getId()I
    .locals 1

    .line 22
    iget v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->id:I

    return v0
.end method

.method public getPermissions()Ljava/lang/String;
    .locals 1

    .line 25
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->permissions:Ljava/lang/String;

    return-object v0
.end method

.method public getType()I
    .locals 1

    .line 26
    iget v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->type:I

    return v0
.end method

.method public getUsername()Ljava/lang/String;
    .locals 1

    .line 23
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/FriendItem;->username:Ljava/lang/String;

    return-object v0
.end method
