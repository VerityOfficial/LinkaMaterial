.class Lcom/LinkaMaterialProject/linkaMaterial/request$1$1;
.super Ljava/lang/Object;
.source "request.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/LinkaMaterialProject/linkaMaterial/request$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/LinkaMaterialProject/linkaMaterial/request$1;

.field final synthetic val$result:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/LinkaMaterialProject/linkaMaterial/request$1;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lcom/LinkaMaterialProject/linkaMaterial/request$1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 27
    iput-object p1, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/request$1;

    iput-object p2, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1$1;->val$result:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 30
    iget-object v0, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1$1;->this$0:Lcom/LinkaMaterialProject/linkaMaterial/request$1;

    iget-object v0, v0, Lcom/LinkaMaterialProject/linkaMaterial/request$1;->val$callback:Lcom/LinkaMaterialProject/linkaMaterial/request$RequestCallback;

    iget-object v1, p0, Lcom/LinkaMaterialProject/linkaMaterial/request$1$1;->val$result:Ljava/lang/String;

    invoke-interface {v0, v1}, Lcom/LinkaMaterialProject/linkaMaterial/request$RequestCallback;->onSuccess(Ljava/lang/String;)V

    .line 31
    return-void
.end method
