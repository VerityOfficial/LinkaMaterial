.class public final Lkotlin/ULong;
.super Ljava/lang/Object;
.source "ULong.kt"

# interfaces
.implements Ljava/lang/Comparable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlin/ULong$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Comparable<",
        "Lkotlin/ULong;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000l\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0000\n\u0002\u0010\t\n\u0002\u0008\u0005\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u00082\n\u0002\u0018\u0002\n\u0002\u0008\u0012\n\u0002\u0010\u0005\n\u0002\u0008\u0003\n\u0002\u0010\n\n\u0002\u0008\u0010\n\u0002\u0010\u0007\n\u0002\u0008\u0003\n\u0002\u0010\u0006\n\u0002\u0008\u0003\n\u0002\u0010\u000e\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0002\u0010\u0000\n\u0002\u0008\u0003\u0008\u0087@\u0018\u0000 {2\u0008\u0012\u0004\u0012\u00020\u00000\u0001:\u0001{B\u0011\u0008\u0001\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u0018\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0087\n\u00a2\u0006\u0004\u0008\u000c\u0010\rJ\u0018\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000eH\u0087\n\u00a2\u0006\u0004\u0008\u000f\u0010\u0010J\u0018\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0011H\u0087\n\u00a2\u0006\u0004\u0008\u0012\u0010\u0013J\u0018\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0000H\u0097\n\u00a2\u0006\u0004\u0008\u0014\u0010\u0015J\u0018\u0010\u0016\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u000bH\u0087\n\u00a2\u0006\u0004\u0008\u0017\u0010\u0018J\u0018\u0010\u0016\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u000eH\u0087\n\u00a2\u0006\u0004\u0008\u0019\u0010\u001aJ\u0018\u0010\u0016\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0011H\u0087\n\u00a2\u0006\u0004\u0008\u001b\u0010\u001cJ\u0018\u0010\u0016\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008\u001d\u0010\u001eJ\u0018\u0010\u001f\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u000bH\u0087\n\u00a2\u0006\u0004\u0008 \u0010\u0018J\u0018\u0010\u001f\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u000eH\u0087\n\u00a2\u0006\u0004\u0008!\u0010\u001aJ\u0018\u0010\u001f\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0011H\u0087\n\u00a2\u0006\u0004\u0008\"\u0010\u001cJ\u0018\u0010\u001f\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008#\u0010\u001eJ\u0018\u0010$\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u000bH\u0087\n\u00a2\u0006\u0004\u0008%\u0010\u0018J\u0018\u0010$\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u000eH\u0087\n\u00a2\u0006\u0004\u0008&\u0010\u001aJ\u0018\u0010$\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0011H\u0087\n\u00a2\u0006\u0004\u0008\'\u0010\u001cJ\u0018\u0010$\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008(\u0010\u001eJ\u0018\u0010)\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u000bH\u0087\n\u00a2\u0006\u0004\u0008*\u0010\u0018J\u0018\u0010)\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u000eH\u0087\n\u00a2\u0006\u0004\u0008+\u0010\u001aJ\u0018\u0010)\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0011H\u0087\n\u00a2\u0006\u0004\u0008,\u0010\u001cJ\u0018\u0010)\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008-\u0010\u001eJ\u0018\u0010.\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u000bH\u0087\n\u00a2\u0006\u0004\u0008/\u0010\u0018J\u0018\u0010.\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u000eH\u0087\n\u00a2\u0006\u0004\u00080\u0010\u001aJ\u0018\u0010.\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0011H\u0087\n\u00a2\u0006\u0004\u00081\u0010\u001cJ\u0018\u0010.\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u00082\u0010\u001eJ\u0018\u00103\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u000bH\u0087\u0008\u00a2\u0006\u0004\u00084\u0010\u0018J\u0018\u00103\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u000eH\u0087\u0008\u00a2\u0006\u0004\u00085\u0010\u001aJ\u0018\u00103\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0011H\u0087\u0008\u00a2\u0006\u0004\u00086\u0010\u001cJ\u0018\u00103\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0000H\u0087\u0008\u00a2\u0006\u0004\u00087\u0010\u001eJ\u0018\u00108\u001a\u00020\u000b2\u0006\u0010\n\u001a\u00020\u000bH\u0087\u0008\u00a2\u0006\u0004\u00089\u0010:J\u0018\u00108\u001a\u00020\u000e2\u0006\u0010\n\u001a\u00020\u000eH\u0087\u0008\u00a2\u0006\u0004\u0008;\u0010<J\u0018\u00108\u001a\u00020\u00112\u0006\u0010\n\u001a\u00020\u0011H\u0087\u0008\u00a2\u0006\u0004\u0008=\u0010\u0013J\u0018\u00108\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0000H\u0087\u0008\u00a2\u0006\u0004\u0008>\u0010\u001eJ\u0010\u0010?\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008@\u0010\u0005J\u0010\u0010A\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008B\u0010\u0005J\u0018\u0010C\u001a\u00020D2\u0006\u0010\n\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008E\u0010FJ\u0018\u0010G\u001a\u00020D2\u0006\u0010\n\u001a\u00020\u0000H\u0087\n\u00a2\u0006\u0004\u0008H\u0010FJ\u0018\u0010I\u001a\u00020\u00002\u0006\u0010J\u001a\u00020\tH\u0087\u000c\u00a2\u0006\u0004\u0008K\u0010\u001cJ\u0018\u0010L\u001a\u00020\u00002\u0006\u0010J\u001a\u00020\tH\u0087\u000c\u00a2\u0006\u0004\u0008M\u0010\u001cJ\u0018\u0010N\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0000H\u0087\u000c\u00a2\u0006\u0004\u0008O\u0010\u001eJ\u0018\u0010P\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0000H\u0087\u000c\u00a2\u0006\u0004\u0008Q\u0010\u001eJ\u0018\u0010R\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0000H\u0087\u000c\u00a2\u0006\u0004\u0008S\u0010\u001eJ\u0010\u0010T\u001a\u00020\u0000H\u0087\u0008\u00a2\u0006\u0004\u0008U\u0010\u0005J\u0010\u0010V\u001a\u00020WH\u0087\u0008\u00a2\u0006\u0004\u0008X\u0010YJ\u0010\u0010Z\u001a\u00020[H\u0087\u0008\u00a2\u0006\u0004\u0008\\\u0010]J\u0010\u0010^\u001a\u00020\tH\u0087\u0008\u00a2\u0006\u0004\u0008_\u0010`J\u0010\u0010a\u001a\u00020\u0003H\u0087\u0008\u00a2\u0006\u0004\u0008b\u0010\u0005J\u0010\u0010c\u001a\u00020\u000bH\u0087\u0008\u00a2\u0006\u0004\u0008d\u0010YJ\u0010\u0010e\u001a\u00020\u000eH\u0087\u0008\u00a2\u0006\u0004\u0008f\u0010]J\u0010\u0010g\u001a\u00020\u0011H\u0087\u0008\u00a2\u0006\u0004\u0008h\u0010`J\u0010\u0010i\u001a\u00020\u0000H\u0087\u0008\u00a2\u0006\u0004\u0008j\u0010\u0005J\u0010\u0010k\u001a\u00020lH\u0087\u0008\u00a2\u0006\u0004\u0008m\u0010nJ\u0010\u0010o\u001a\u00020pH\u0087\u0008\u00a2\u0006\u0004\u0008q\u0010rJ\u000f\u0010s\u001a\u00020tH\u0016\u00a2\u0006\u0004\u0008u\u0010vJ\u0013\u0010w\u001a\u00020x2\u0008\u0010\n\u001a\u0004\u0018\u00010yH\u00d6\u0003J\t\u0010z\u001a\u00020\tH\u00d6\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0000X\u0081\u0004\u00a2\u0006\u0008\n\u0000\u0012\u0004\u0008\u0006\u0010\u0007\u0088\u0001\u0002\u0092\u0001\u00020\u0003\u00a8\u0006|"
    }
    d2 = {
        "Lkotlin/ULong;",
        "",
        "data",
        "",
        "constructor-impl",
        "(J)J",
        "getData$annotations",
        "()V",
        "compareTo",
        "",
        "other",
        "Lkotlin/UByte;",
        "compareTo-7apg3OU",
        "(JB)I",
        "Lkotlin/UShort;",
        "compareTo-xj2QHRw",
        "(JS)I",
        "Lkotlin/UInt;",
        "compareTo-WZ4Q5Ns",
        "(JI)I",
        "compareTo-VKZWuLQ",
        "(JJ)I",
        "plus",
        "plus-7apg3OU",
        "(JB)J",
        "plus-xj2QHRw",
        "(JS)J",
        "plus-WZ4Q5Ns",
        "(JI)J",
        "plus-VKZWuLQ",
        "(JJ)J",
        "minus",
        "minus-7apg3OU",
        "minus-xj2QHRw",
        "minus-WZ4Q5Ns",
        "minus-VKZWuLQ",
        "times",
        "times-7apg3OU",
        "times-xj2QHRw",
        "times-WZ4Q5Ns",
        "times-VKZWuLQ",
        "div",
        "div-7apg3OU",
        "div-xj2QHRw",
        "div-WZ4Q5Ns",
        "div-VKZWuLQ",
        "rem",
        "rem-7apg3OU",
        "rem-xj2QHRw",
        "rem-WZ4Q5Ns",
        "rem-VKZWuLQ",
        "floorDiv",
        "floorDiv-7apg3OU",
        "floorDiv-xj2QHRw",
        "floorDiv-WZ4Q5Ns",
        "floorDiv-VKZWuLQ",
        "mod",
        "mod-7apg3OU",
        "(JB)B",
        "mod-xj2QHRw",
        "(JS)S",
        "mod-WZ4Q5Ns",
        "mod-VKZWuLQ",
        "inc",
        "inc-s-VKNKU",
        "dec",
        "dec-s-VKNKU",
        "rangeTo",
        "Lkotlin/ranges/ULongRange;",
        "rangeTo-VKZWuLQ",
        "(JJ)Lkotlin/ranges/ULongRange;",
        "rangeUntil",
        "rangeUntil-VKZWuLQ",
        "shl",
        "bitCount",
        "shl-s-VKNKU",
        "shr",
        "shr-s-VKNKU",
        "and",
        "and-VKZWuLQ",
        "or",
        "or-VKZWuLQ",
        "xor",
        "xor-VKZWuLQ",
        "inv",
        "inv-s-VKNKU",
        "toByte",
        "",
        "toByte-impl",
        "(J)B",
        "toShort",
        "",
        "toShort-impl",
        "(J)S",
        "toInt",
        "toInt-impl",
        "(J)I",
        "toLong",
        "toLong-impl",
        "toUByte",
        "toUByte-w2LRezQ",
        "toUShort",
        "toUShort-Mh2AYeg",
        "toUInt",
        "toUInt-pVg5ArA",
        "toULong",
        "toULong-s-VKNKU",
        "toFloat",
        "",
        "toFloat-impl",
        "(J)F",
        "toDouble",
        "",
        "toDouble-impl",
        "(J)D",
        "toString",
        "",
        "toString-impl",
        "(J)Ljava/lang/String;",
        "equals",
        "",
        "",
        "hashCode",
        "Companion",
        "kotlin-stdlib"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/jvm/JvmInline;
.end annotation


# static fields
.field public static final Companion:Lkotlin/ULong$Companion;

.field public static final MAX_VALUE:J = -0x1L

.field public static final MIN_VALUE:J = 0x0L

.field public static final SIZE_BITS:I = 0x40

.field public static final SIZE_BYTES:I = 0x8


# instance fields
.field private final data:J


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lkotlin/ULong$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lkotlin/ULong$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lkotlin/ULong;->Companion:Lkotlin/ULong$Companion;

    return-void
.end method

.method private synthetic constructor <init>(J)V
    .locals 0
    .param p1, "data"    # J

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lkotlin/ULong;->data:J

    return-void
.end method

.method private static final and-VKZWuLQ(JJ)J
    .locals 2
    .param p0, "arg0"    # J
    .param p2, "other"    # J

    .line 270
    and-long v0, p0, p2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method public static final synthetic box-impl(J)Lkotlin/ULong;
    .locals 1

    new-instance v0, Lkotlin/ULong;

    invoke-direct {v0, p0, p1}, Lkotlin/ULong;-><init>(J)V

    return-object v0
.end method

.method private static final compareTo-7apg3OU(JB)I
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # B

    .line 46
    int-to-long v0, p2

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {p0, p1, v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport5;->m(JJ)I

    move-result v0

    return v0
.end method

.method private compareTo-VKZWuLQ(J)I
    .locals 2
    .param p1, "other"    # J

    .line 69
    invoke-virtual {p0}, Lkotlin/ULong;->unbox-impl()J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Lkotlin/UnsignedKt;->ulongCompare(JJ)I

    move-result v0

    .line 71
    return v0
.end method

.method private static compareTo-VKZWuLQ(JJ)I
    .locals 1
    .param p0, "arg0"    # J
    .param p2, "other"    # J

    .line 71
    invoke-static {p0, p1, p2, p3}, Lkotlin/UnsignedKt;->ulongCompare(JJ)I

    move-result v0

    return v0
.end method

.method private static final compareTo-WZ4Q5Ns(JI)I
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # I

    .line 62
    int-to-long v0, p2

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {p0, p1, v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport5;->m(JJ)I

    move-result v0

    return v0
.end method

.method private static final compareTo-xj2QHRw(JS)I
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # S

    .line 54
    int-to-long v0, p2

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {p0, p1, v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport5;->m(JJ)I

    move-result v0

    return v0
.end method

.method public static constructor-impl(J)J
    .locals 0

    return-wide p0
.end method

.method private static final dec-s-VKNKU(J)J
    .locals 2
    .param p0, "arg0"    # J

    .line 234
    const-wide/16 v0, -0x1

    add-long/2addr v0, p0

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final div-7apg3OU(JB)J
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # B

    .line 114
    int-to-long v0, p2

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {p0, p1, v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport4;->m(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final div-VKZWuLQ(JJ)J
    .locals 2
    .param p0, "arg0"    # J
    .param p2, "other"    # J

    .line 123
    invoke-static {p0, p1, p2, p3}, Lkotlin/UnsignedKt;->ulongDivide-eb3DHEI(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final div-WZ4Q5Ns(JI)J
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # I

    .line 120
    int-to-long v0, p2

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {p0, p1, v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport4;->m(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final div-xj2QHRw(JS)J
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # S

    .line 117
    int-to-long v0, p2

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {p0, p1, v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport4;->m(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method public static equals-impl(JLjava/lang/Object;)Z
    .locals 4

    instance-of v0, p2, Lkotlin/ULong;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    move-object v0, p2

    check-cast v0, Lkotlin/ULong;

    invoke-virtual {v0}, Lkotlin/ULong;->unbox-impl()J

    move-result-wide v2

    cmp-long v0, p0, v2

    if-eqz v0, :cond_1

    return v1

    :cond_1
    const/4 v0, 0x1

    return v0
.end method

.method public static final equals-impl0(JJ)Z
    .locals 1

    cmp-long v0, p0, p2

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private static final floorDiv-7apg3OU(JB)J
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # B

    .line 160
    int-to-long v0, p2

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {p0, p1, v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport4;->m(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final floorDiv-VKZWuLQ(JJ)J
    .locals 2
    .param p0, "arg0"    # J
    .param p2, "other"    # J

    .line 181
    invoke-static {p0, p1, p2, p3}, Lkotlin/UByte$$ExternalSyntheticBackport4;->m(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final floorDiv-WZ4Q5Ns(JI)J
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # I

    .line 174
    int-to-long v0, p2

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {p0, p1, v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport4;->m(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final floorDiv-xj2QHRw(JS)J
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # S

    .line 167
    int-to-long v0, p2

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {p0, p1, v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport4;->m(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method public static synthetic getData$annotations()V
    .locals 0

    return-void
.end method

.method public static hashCode-impl(J)I
    .locals 1

    invoke-static {p0, p1}, Lkotlin/ULong$$ExternalSyntheticBackport0;->m(J)I

    move-result v0

    return v0
.end method

.method private static final inc-s-VKNKU(J)J
    .locals 2
    .param p0, "arg0"    # J

    .line 226
    const-wide/16 v0, 0x1

    add-long/2addr v0, p0

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final inv-s-VKNKU(J)J
    .locals 2
    .param p0, "arg0"    # J

    .line 279
    const-wide/16 v0, -0x1

    xor-long/2addr v0, p0

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final minus-7apg3OU(JB)J
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # B

    .line 88
    int-to-long v0, p2

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    sub-long v0, p0, v0

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final minus-VKZWuLQ(JJ)J
    .locals 2
    .param p0, "arg0"    # J
    .param p2, "other"    # J

    .line 97
    sub-long v0, p0, p2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final minus-WZ4Q5Ns(JI)J
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # I

    .line 94
    int-to-long v0, p2

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    sub-long v0, p0, v0

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final minus-xj2QHRw(JS)J
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # S

    .line 91
    int-to-long v0, p2

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    sub-long v0, p0, v0

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final mod-7apg3OU(JB)B
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # B

    .line 191
    int-to-long v0, p2

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {p0, p1, v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport2;->m(JJ)J

    move-result-wide v0

    long-to-int v1, v0

    int-to-byte v0, v1

    invoke-static {v0}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v0

    return v0
.end method

.method private static final mod-VKZWuLQ(JJ)J
    .locals 2
    .param p0, "arg0"    # J
    .param p2, "other"    # J

    .line 218
    invoke-static {p0, p1, p2, p3}, Lkotlin/UByte$$ExternalSyntheticBackport2;->m(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final mod-WZ4Q5Ns(JI)I
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # I

    .line 209
    int-to-long v0, p2

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {p0, p1, v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport2;->m(JJ)J

    move-result-wide v0

    long-to-int v1, v0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final mod-xj2QHRw(JS)S
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # S

    .line 200
    int-to-long v0, p2

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {p0, p1, v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport2;->m(JJ)J

    move-result-wide v0

    long-to-int v1, v0

    int-to-short v0, v1

    invoke-static {v0}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v0

    return v0
.end method

.method private static final or-VKZWuLQ(JJ)J
    .locals 2
    .param p0, "arg0"    # J
    .param p2, "other"    # J

    .line 273
    or-long v0, p0, p2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final plus-7apg3OU(JB)J
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # B

    .line 75
    int-to-long v0, p2

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    add-long/2addr v0, p0

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final plus-VKZWuLQ(JJ)J
    .locals 2
    .param p0, "arg0"    # J
    .param p2, "other"    # J

    .line 84
    add-long v0, p0, p2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final plus-WZ4Q5Ns(JI)J
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # I

    .line 81
    int-to-long v0, p2

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    add-long/2addr v0, p0

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final plus-xj2QHRw(JS)J
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # S

    .line 78
    int-to-long v0, p2

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    add-long/2addr v0, p0

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final rangeTo-VKZWuLQ(JJ)Lkotlin/ranges/ULongRange;
    .locals 6
    .param p0, "arg0"    # J
    .param p2, "other"    # J

    .line 238
    new-instance v0, Lkotlin/ranges/ULongRange;

    const/4 v5, 0x0

    move-wide v1, p0

    move-wide v3, p2

    .end local p0    # "arg0":J
    .end local p2    # "other":J
    .local v1, "arg0":J
    .local v3, "other":J
    invoke-direct/range {v0 .. v5}, Lkotlin/ranges/ULongRange;-><init>(JJLkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v0
.end method

.method private static final rangeUntil-VKZWuLQ(JJ)Lkotlin/ranges/ULongRange;
    .locals 1
    .param p0, "arg0"    # J
    .param p2, "other"    # J

    .line 248
    invoke-static {p0, p1, p2, p3}, Lkotlin/ranges/URangesKt;->until-eb3DHEI(JJ)Lkotlin/ranges/ULongRange;

    move-result-object v0

    return-object v0
.end method

.method private static final rem-7apg3OU(JB)J
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # B

    .line 131
    int-to-long v0, p2

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {p0, p1, v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport2;->m(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final rem-VKZWuLQ(JJ)J
    .locals 2
    .param p0, "arg0"    # J
    .param p2, "other"    # J

    .line 152
    invoke-static {p0, p1, p2, p3}, Lkotlin/UnsignedKt;->ulongRemainder-eb3DHEI(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final rem-WZ4Q5Ns(JI)J
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # I

    .line 145
    int-to-long v0, p2

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {p0, p1, v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport2;->m(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final rem-xj2QHRw(JS)J
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # S

    .line 138
    int-to-long v0, p2

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {p0, p1, v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport2;->m(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final shl-s-VKNKU(JI)J
    .locals 2
    .param p0, "arg0"    # J
    .param p2, "bitCount"    # I

    .line 257
    shl-long v0, p0, p2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final shr-s-VKNKU(JI)J
    .locals 2
    .param p0, "arg0"    # J
    .param p2, "bitCount"    # I

    .line 266
    ushr-long v0, p0, p2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final times-7apg3OU(JB)J
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # B

    .line 101
    int-to-long v0, p2

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    mul-long v0, v0, p0

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final times-VKZWuLQ(JJ)J
    .locals 2
    .param p0, "arg0"    # J
    .param p2, "other"    # J

    .line 110
    mul-long v0, p0, p2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final times-WZ4Q5Ns(JI)J
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # I

    .line 107
    int-to-long v0, p2

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    mul-long v0, v0, p0

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final times-xj2QHRw(JS)J
    .locals 4
    .param p0, "arg0"    # J
    .param p2, "other"    # S

    .line 104
    int-to-long v0, p2

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    mul-long v0, v0, p0

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final toByte-impl(J)B
    .locals 1
    .param p0, "arg0"    # J

    .line 291
    long-to-int v0, p0

    int-to-byte v0, v0

    return v0
.end method

.method private static final toDouble-impl(J)D
    .locals 2
    .param p0, "arg0"    # J

    .line 376
    invoke-static {p0, p1}, Lkotlin/UnsignedKt;->ulongToDouble(J)D

    move-result-wide v0

    return-wide v0
.end method

.method private static final toFloat-impl(J)F
    .locals 2
    .param p0, "arg0"    # J

    .line 367
    invoke-static {p0, p1}, Lkotlin/UnsignedKt;->ulongToDouble(J)D

    move-result-wide v0

    double-to-float v0, v0

    return v0
.end method

.method private static final toInt-impl(J)I
    .locals 1
    .param p0, "arg0"    # J

    .line 313
    long-to-int v0, p0

    return v0
.end method

.method private static final toLong-impl(J)J
    .locals 0
    .param p0, "arg0"    # J

    .line 323
    return-wide p0
.end method

.method private static final toShort-impl(J)S
    .locals 1
    .param p0, "arg0"    # J

    .line 302
    long-to-int v0, p0

    int-to-short v0, v0

    return v0
.end method

.method public static toString-impl(J)Ljava/lang/String;
    .locals 1
    .param p0, "arg0"    # J

    .line 378
    const/16 v0, 0xa

    invoke-static {p0, p1, v0}, Lkotlin/UnsignedKt;->ulongToString(JI)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final toUByte-w2LRezQ(J)B
    .locals 1
    .param p0, "arg0"    # J

    .line 334
    long-to-int v0, p0

    int-to-byte v0, v0

    invoke-static {v0}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v0

    return v0
.end method

.method private static final toUInt-pVg5ArA(J)I
    .locals 1
    .param p0, "arg0"    # J

    .line 354
    long-to-int v0, p0

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final toULong-s-VKNKU(J)J
    .locals 0
    .param p0, "arg0"    # J

    .line 357
    return-wide p0
.end method

.method private static final toUShort-Mh2AYeg(J)S
    .locals 1
    .param p0, "arg0"    # J

    .line 344
    long-to-int v0, p0

    int-to-short v0, v0

    invoke-static {v0}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v0

    return v0
.end method

.method private static final xor-VKZWuLQ(JJ)J
    .locals 2
    .param p0, "arg0"    # J
    .param p2, "other"    # J

    .line 276
    xor-long v0, p0, p2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method


# virtual methods
.method public bridge synthetic compareTo(Ljava/lang/Object;)I
    .locals 4
    .param p1, "other"    # Ljava/lang/Object;

    .line 14
    move-object v0, p1

    check-cast v0, Lkotlin/ULong;

    invoke-virtual {v0}, Lkotlin/ULong;->unbox-impl()J

    move-result-wide v0

    invoke-virtual {p0}, Lkotlin/ULong;->unbox-impl()J

    move-result-wide v2

    invoke-static {v2, v3, v0, v1}, Lkotlin/UnsignedKt;->ulongCompare(JJ)I

    move-result v0

    return v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 2

    iget-wide v0, p0, Lkotlin/ULong;->data:J

    invoke-static {v0, v1, p1}, Lkotlin/ULong;->equals-impl(JLjava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public hashCode()I
    .locals 2

    iget-wide v0, p0, Lkotlin/ULong;->data:J

    invoke-static {v0, v1}, Lkotlin/ULong;->hashCode-impl(J)I

    move-result v0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 378
    iget-wide v0, p0, Lkotlin/ULong;->data:J

    invoke-static {v0, v1}, Lkotlin/ULong;->toString-impl(J)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final synthetic unbox-impl()J
    .locals 2

    iget-wide v0, p0, Lkotlin/ULong;->data:J

    return-wide v0
.end method
