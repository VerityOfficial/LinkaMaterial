.class public final synthetic Lkotlin/UByte$$ExternalSyntheticBackport6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"


# direct methods
.method public static synthetic m(II)I
    .locals 1

    .line 0
    const/high16 v0, -0x80000000

    xor-int/2addr p0, v0

    xor-int/2addr p1, v0

    invoke-static {p0, p1}, Lkotlin/UByte$$ExternalSyntheticBackport3;->m(II)I

    move-result p0

    return p0
.end method
