package com.LinkaMaterialProject.linkaMaterial;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;
import android.content.Intent;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
public class optionActivity extends Activity{
    private Button btnInbox;
    private Button btnFriends;
    private Button btnChangeServer;
    private ImageButton btnHome;
    private ImageButton btnChat;
    private ImageButton btnProfile;
    private ImageButton btnOptions;
    private Button btnGenerateInvite;
    @Override
    public void onCreate(Bundle savedInstanceState){        
        super.onCreate(savedInstanceState);        
        setContentView(R.layout.activity_options);
        btnInbox = (Button) findViewById(R.id.btnInbox);
        btnFriends = (Button) findViewById(R.id.btnFriends);
        btnChangeServer = (Button) findViewById(R.id.btnChangeServer);
        btnHome = (ImageButton) findViewById(R.id.btnHome);
        btnChat = (ImageButton) findViewById(R.id.btnChat);
        btnOptions = (ImageButton) findViewById(R.id.btnOptions);
        btnProfile = (ImageButton) findViewById(R.id.btnProfile);
        btnGenerateInvite = (Button) findViewById(R.id.btnGenerateInvite);
        btnGenerateInvite.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(optionActivity.this, GenerateInvite.class);
                startActivity(intent);
            }
        });
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(optionActivity.this, HomeActivity.class);
                startActivity(intent);
            }
        });
        btnChat.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(optionActivity.this, chatActivity.class);
                startActivity(intent);
            }
        });
        btnProfile.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(optionActivity.this, profile.class);
                startActivity(intent);
            }
        });
        btnFriends.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(optionActivity.this, addFriendActivity.class);
                startActivity(intent);
            }
        });
        btnInbox.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(optionActivity.this, InboxActivity.class);
                startActivity(intent);
            }
        });
        btnChangeServer.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(optionActivity.this, ChangeServer.class);
                startActivity(intent);
            }
        });
    }
}
