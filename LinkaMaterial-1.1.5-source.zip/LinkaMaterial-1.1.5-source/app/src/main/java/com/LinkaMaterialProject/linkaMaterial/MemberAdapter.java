package com.LinkaMaterialProject.linkaMaterial;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

public class MemberAdapter extends BaseAdapter {

    private final Context context;
    private final List<Member> memberList;
    private final LayoutInflater inflater;

    public MemberAdapter(Context context, List<Member> memberList) {
        this.context = context;
        this.memberList = memberList;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return memberList != null ? memberList.size() : 0;
    }

    @Override
    public Object getItem(int position) {
        return memberList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    static class ViewHolder {
        ImageView imgAvatar;
        TextView txtUsername;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.card_member, parent, false);
            holder = new ViewHolder();
            holder.imgAvatar = (ImageView) convertView.findViewById(R.id.ImgAvatar);
            holder.txtUsername = (TextView) convertView.findViewById(R.id.txtUsername);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Member member = memberList.get(position);

        holder.txtUsername.setText("@" + member.getUsername());

        // Verificação corrigida para usar o ImageView da classe Member
        if (member.getAvatarImageView() != null && member.getAvatarImageView().getDrawable() != null) {
            holder.imgAvatar.setImageDrawable(member.getAvatarImageView().getDrawable());
        }

        return convertView;
    }
}